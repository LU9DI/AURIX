"""AURIX: a local-first open-source AI engineering agent."""

__version__ = "0.63.0"
