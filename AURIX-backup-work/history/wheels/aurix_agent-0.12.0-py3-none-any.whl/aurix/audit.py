"""Combine proposal triage and explicitly approved verification into one audit result."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from aurix.tools.review import review_proposal
from aurix.tools.verification import verify_proposal


def audit_proposal(
    workspace: str | Path,
    proposal_id: str,
    *,
    confirm_verify: bool = False,
    suite: str = "pytest",
    timeout_seconds: int = 120,
) -> dict[str, Any]:
    """Review a proposal and optionally verify it in a disposable Git worktree.

    The heuristic review never authorizes applying the patch. Verification is
    opt-in because repository tests are executable code and are not OS-sandboxed.
    """
    review = review_proposal(workspace, proposal_id)
    result: dict[str, Any] = {
        "schema_version": 1,
        "proposal_id": proposal_id,
        "status": "reviewed_verification_not_run",
        "review": review,
        "verification": {
            "status": "not_run",
            "reason": "Explicit confirmation required" if not confirm_verify else "pending",
        },
        "application": {"performed": False, "permitted_by_review": False},
        "limitations": [
            "Heuristic review is not proof of security or correctness.",
            "Verification executes repository code and is not an OS sandbox.",
            "Passing tests do not authorize patch application.",
        ],
    }
    if confirm_verify:
        verification = verify_proposal(
            workspace, proposal_id, confirm=True, suite=suite, timeout_seconds=timeout_seconds
        )
        result["verification"] = verification
        result["status"] = (
            "audit_passed" if review["risk_level"] == "low" and verification["status"] == "verified_pass"
            else "audit_needs_attention"
        )
    return result
