"""Explicitly approved, bounded test execution for trusted workspaces.

This runner is defense-in-depth, NOT an OS sandbox. Tests can execute arbitrary
Python code and must only be run on repositories the operator trusts.
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Literal

TestSuite = Literal["pytest", "ruff"]
_MAX_OUTPUT_CHARS = 20_000


def _safe_environment() -> dict[str, str]:
    """Pass only basic runtime variables; drop common credentials and app config."""
    keep = {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "TMPDIR", "LANG", "LC_ALL"}
    env = {key: value for key, value in os.environ.items() if key.upper() in keep}
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PIP_NO_INPUT"] = "1"
    return env


def run_test_suite(
    workspace: Path | str,
    suite: TestSuite = "pytest",
    *,
    confirm: bool = False,
    timeout_seconds: int = 120,
) -> dict[str, object]:
    """Run a fixed test command after explicit approval, with bounded output/time.

    Only the two fixed commands are allowed; model-provided arguments are never
    executed. This is not a sandbox and does not block network or filesystem use.
    """
    if not confirm:
        raise PermissionError("Explicit confirmation is required to execute tests")
    if suite not in {"pytest", "ruff"}:
        raise ValueError("Unsupported test suite; choose 'pytest' or 'ruff'")
    root = Path(workspace).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Workspace must be a directory")
    timeout = max(1, min(int(timeout_seconds), 120))
    command = ([sys.executable, "-m", "pytest", "-q"] if suite == "pytest"
               else [sys.executable, "-m", "ruff", "check", "."])
    started = time.perf_counter()
    try:
        result = subprocess.run(
            command,
            cwd=root,
            env=_safe_environment(),
            shell=False,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        return {
            "suite": suite,
            "command": command,
            "returncode": result.returncode,
            "passed": result.returncode == 0,
            "timed_out": False,
            "duration_ms": round((time.perf_counter() - started) * 1000, 2),
            "stdout": result.stdout[-_MAX_OUTPUT_CHARS:],
            "stderr": result.stderr[-_MAX_OUTPUT_CHARS:],
            "output_truncated": len(result.stdout) > _MAX_OUTPUT_CHARS or len(result.stderr) > _MAX_OUTPUT_CHARS,
            "security_note": "Trusted workspace only; this runner is not a sandbox.",
        }
    except subprocess.TimeoutExpired as exc:
        def tail(value: str | bytes | None) -> str:
            if value is None:
                return ""
            if isinstance(value, bytes):
                value = value.decode("utf-8", errors="replace")
            return value[-_MAX_OUTPUT_CHARS:]
        return {
            "suite": suite,
            "command": command,
            "returncode": None,
            "passed": False,
            "timed_out": True,
            "duration_ms": round((time.perf_counter() - started) * 1000, 2),
            "stdout": tail(exc.stdout),
            "stderr": tail(exc.stderr),
            "output_truncated": True,
            "security_note": "Timed out; this runner is not a sandbox.",
        }
