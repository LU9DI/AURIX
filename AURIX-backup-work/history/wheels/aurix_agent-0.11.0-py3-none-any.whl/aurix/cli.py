import argparse
import json
from pathlib import Path

from aurix.config import get_max_steps
from aurix.evaluation.benchmark import load_cases, run_benchmark
from aurix.orchestrator import Orchestrator
from aurix.providers.factory import create_provider
from aurix.tools.workspace import build_workspace_context
from aurix.tools.patches import apply_proposal, revert_proposal
from aurix.tools.execution import run_test_suite
from aurix.tools.verification import verify_proposal
from aurix.diagnostics import run_diagnostics
from aurix.tools.review import review_proposal
from aurix.reports import write_run_report


def main() -> None:
    parser = argparse.ArgumentParser(prog="aurix", description="AURIX local-first engineering agent")
    parser.add_argument("task", nargs="?", help="Task to reason about")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--doctor", action="store_true", help="Run read-only installation/readiness checks")
    parser.add_argument("--probe-provider", action="store_true", help="Make a live model request (may consume compute/API credits)")
    parser.add_argument("--benchmark", help="Run a JSON benchmark file instead of a single task")
    parser.add_argument("--report-run", metavar="PATH", help="Explicitly save a local JSON run report inside the workspace (includes task text)")
    parser.add_argument("--json", action="store_true", help="Print machine-readable output")
    parser.add_argument("--apply-proposal", metavar="ID", help="Apply a reviewed patch proposal")
    parser.add_argument("--confirm-apply", action="store_true", help="Explicitly confirm patch application")
    parser.add_argument("--revert-proposal", metavar="ID", help="Reverse an applied patch proposal")
    parser.add_argument("--confirm-revert", action="store_true", help="Explicitly confirm patch reversal")
    parser.add_argument("--verify-proposal", metavar="ID", help="Test a proposal in a disposable Git worktree")
    parser.add_argument("--review-proposal", metavar="ID", help="Run a deterministic heuristic review of a patch proposal")
    parser.add_argument("--confirm-verify", action="store_true", help="Explicitly confirm proposal verification")
    parser.add_argument("--verify-suite", choices=("pytest", "ruff"), default="pytest", help="Suite for proposal verification")
    parser.add_argument("--run-tests", choices=("pytest", "ruff"), help="Run a fixed test/lint command")
    parser.add_argument("--confirm-run-tests", action="store_true", help="Confirm execution in this trusted workspace")
    parser.add_argument("--test-timeout", type=int, default=120, help="Test timeout in seconds (max 120)")
    args = parser.parse_args()

    if args.probe_provider and not args.doctor:
        parser.error("--probe-provider requires --doctor")
    if args.doctor:
        try:
            provider = create_provider() if args.probe_provider else None
            result = run_diagnostics(args.workspace, probe_provider=args.probe_provider, provider=provider)
        except (ValueError, OSError, RuntimeError) as exc:
            parser.exit(2, f"AURIX diagnostics failed: {type(exc).__name__}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
              f"AURIX doctor: {result['status']}\n" + "\n".join(
                  f"[{item['status']}] {item['name']}: {item['detail']}" for item in result["checks"]))
        return

    if args.run_tests:
        if args.apply_proposal or args.revert_proposal or args.verify_proposal or args.confirm_apply or args.confirm_revert or args.confirm_verify:
            parser.error("Test execution cannot be combined with patch operations or proposal verification")
        try:
            result = run_test_suite(args.workspace, args.run_tests, confirm=args.confirm_run_tests,
                                    timeout_seconds=args.test_timeout)
        except (ValueError, PermissionError, OSError) as exc:
            parser.exit(2, f"AURIX test execution refused/failed: {exc}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
              f"{result['suite']}: {'PASSED' if result['passed'] else 'FAILED'} "
              f"(exit={result['returncode']}, timeout={result['timed_out']})\n"
              f"{result['stdout']}\n{result['stderr']}")
        return
    if args.confirm_run_tests and not args.run_tests:
        parser.error("--confirm-run-tests requires --run-tests")
    operations = [bool(args.apply_proposal), bool(args.revert_proposal), bool(args.verify_proposal), bool(args.review_proposal)]
    if any(operations):
        if sum(operations) > 1:
            parser.error("Choose only one proposal operation")
        if args.apply_proposal and (args.confirm_revert or args.confirm_verify):
            parser.error("Confirmation flag does not match the requested operation")
        if args.revert_proposal and (args.confirm_apply or args.confirm_verify):
            parser.error("Confirmation flag does not match the requested operation")
        if args.verify_proposal and (args.confirm_apply or args.confirm_revert):
            parser.error("Confirmation flag does not match the requested operation")
        if args.review_proposal and (args.confirm_apply or args.confirm_revert or args.confirm_verify):
            parser.error("Review cannot be combined with operation confirmation flags")
        try:
            if args.apply_proposal:
                result = apply_proposal(args.workspace, args.apply_proposal, confirm=args.confirm_apply)
            elif args.revert_proposal:
                result = revert_proposal(args.workspace, args.revert_proposal, confirm=args.confirm_revert)
            elif args.verify_proposal:
                result = verify_proposal(args.workspace, args.verify_proposal, confirm=args.confirm_verify,
                                         suite=args.verify_suite, timeout_seconds=args.test_timeout)
            else:
                result = review_proposal(args.workspace, args.review_proposal)
        except (ValueError, PermissionError, OSError, RuntimeError) as exc:
            parser.exit(2, f"AURIX patch operation refused/failed: {exc}\n")
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif args.verify_proposal:
            test_result = result["test_result"]
            print(f"Proposal {result['proposal_id']}: {result['status']} "
                  f"(suite={result['suite']}, exit={test_result['returncode']}, "
                  f"duration_ms={test_result['duration_ms']})")
            print(str(test_result.get("stdout", "")))
            if test_result.get("stderr"):
                print(str(test_result["stderr"]))
            print(str(result["security_note"]))
        elif args.review_proposal:
            print(f"Proposal {result['proposal_id']}: heuristic risk={result['risk_level']} "
                  f"({result['finding_count']} finding(s)); manual review still required")
            for finding in result["findings"]:
                print(f"[{finding['severity']}] {finding['file']}:{finding['patch_line']} "
                      f"{finding['rule']}: {finding['summary']}")
        else:
            print(f"Proposal {result['proposal_id']}: {result['status']} ({result['files']})")
        return
    if args.confirm_apply or args.confirm_revert or args.confirm_verify:
        parser.error("A confirmation flag requires its matching proposal operation")
    provider = create_provider()
    orchestrator = Orchestrator(provider, max_steps=get_max_steps(), workspace=args.workspace)

    if args.benchmark:
        report = run_benchmark(orchestrator, load_cases(args.benchmark))
        print(json.dumps(report, ensure_ascii=False, indent=2) if args.json else
              f"AURIX benchmark: {report['passed']}/{report['cases']} passed ({report['pass_rate']:.0%})")
        return

    workspace = Path(args.workspace).expanduser().resolve()
    task = args.task or input("AURIX task> ").strip()
    context = build_workspace_context(workspace)
    result = orchestrator.run(task, context)
    report_info = None
    if args.report_run:
        try:
            report_info = write_run_report(args.workspace, args.report_run, task=task, result=result,
                                           provider=type(provider).__name__)
        except (ValueError, PermissionError, OSError) as exc:
            parser.exit(2, f"AURIX report could not be written: {exc}\n")
    if args.json:
        output = {"status": result.status, "steps": result.steps, "message": result.message, "trace": result.trace}
        if report_info is not None:
            output["report"] = report_info
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(f"\nAURIX [{result.status}] after {result.steps} step(s)\n{result.message}")
        print("\nNo autonomous file edits or shell execution are enabled.")
        if report_info is not None:
            print(f"Run report saved: {report_info['path']} (run_id={report_info['run_id']})")


if __name__ == "__main__":
    main()
