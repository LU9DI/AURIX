"""Deterministic lexical retrieval with explicit result and context budgets."""
from __future__ import annotations

import re
from typing import Any

from aurix.memory.base import MemoryStore

_TOKEN_RE = re.compile(r"[^\W_]+", re.UNICODE)


def _tokens(value: str) -> list[str]:
    return [token.casefold() for token in _TOKEN_RE.findall(value) if len(token) > 1]


def retrieve_memories(
    store: MemoryStore,
    query: str,
    *,
    scope: str,
    limit: int = 10,
    candidate_limit: int = 100,
    max_content_chars: int = 4_000,
) -> list[dict[str, Any]]:
    """Rank recent scoped records by lexical overlap, bounded for context use.

    This is lexical retrieval, not embeddings or semantic search. A scope is a
    query filter, not an authorization boundary; callers must enforce access.
    """
    query_tokens = list(dict.fromkeys(_tokens(query)))
    if not query_tokens:
        raise ValueError("memory query must contain at least one token of 2+ characters")
    if not scope.strip():
        raise ValueError("memory scope must not be empty")
    limit = max(1, min(int(limit), 50))
    candidate_limit = max(limit, min(int(candidate_limit), 500))
    max_content_chars = max(100, min(int(max_content_chars), 20_000))

    candidates = store.search("", scope=scope, limit=candidate_limit)
    query_set = set(query_tokens)
    ranked: list[tuple[float, int, dict[str, Any], list[str]]] = []
    query_phrase = " ".join(query_tokens)
    for record in candidates:
        content = str(record.get("content", ""))
        content_tokens = _tokens(content)
        content_set = set(content_tokens)
        matched = [token for token in query_tokens if token in content_set]
        if not matched:
            continue
        # IDF-free overlap score with a modest exact phrase bonus.
        score = len(set(matched)) / len(query_set)
        normalized_content = " ".join(content_tokens)
        if query_phrase and query_phrase in normalized_content:
            score += 0.25
        try:
            recency = int(record.get("id", 0))
        except (TypeError, ValueError):
            recency = 0
        item = dict(record)
        item["content"] = content[:max_content_chars]
        if len(content) > max_content_chars:
            item["content_truncated"] = True
        item["relevance_score"] = round(min(score, 1.25), 4)
        item["matched_terms"] = matched
        ranked.append((score, recency, item, matched))

    ranked.sort(key=lambda entry: (entry[0], entry[1]), reverse=True)
    return [entry[2] for entry in ranked[:limit]]
