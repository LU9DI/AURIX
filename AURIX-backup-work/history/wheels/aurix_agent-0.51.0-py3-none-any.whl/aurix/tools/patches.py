"""Explicitly confirmed application and reversal of AURIX patch proposals.

This is a guardrail, not a sandbox. Only tracked, existing regular files may be
modified; the Git worktree must be clean before application.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path
from typing import Sequence

from aurix.tools.workspace import SENSITIVE_NAMES, safe_path

_PROPOSAL_ID = re.compile(r"^[0-9a-f]{12}$")
_MAX_PATCH_BYTES = 100_000


def _git(workspace: Path, args: Sequence[str], *, patch: str | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args], cwd=workspace, input=patch, text=True,
        capture_output=True, timeout=15, check=False,
    )


def _proposal_path(workspace: Path, proposal_id: str) -> Path:
    if not _PROPOSAL_ID.fullmatch(proposal_id):
        raise ValueError("Invalid proposal ID")
    root = workspace.expanduser().resolve()
    metadata = root / ".aurix"
    proposal_dir = metadata / "proposals"
    if metadata.is_symlink() or proposal_dir.is_symlink():
        raise PermissionError("AURIX proposal directories must not be symlinks")
    path = proposal_dir / f"{proposal_id}.diff"
    # Do not follow symlinks, even if they point back inside the repository.
    if path.is_symlink() or not path.is_file():
        raise FileNotFoundError(f"Patch proposal not found: {proposal_id}")
    if path.stat().st_size > _MAX_PATCH_BYTES:
        raise ValueError("Patch proposal exceeds size limit")
    return path


def _validate_patch(workspace: Path, patch: str) -> list[str]:
    if not patch.strip() or "\x00" in patch:
        raise ValueError("Patch is empty or contains a NUL byte")
    if len(patch.encode("utf-8")) > _MAX_PATCH_BYTES:
        raise ValueError("Patch proposal exceeds size limit")
    forbidden_headers = ("GIT binary patch", "diff --git ", "index ", "new file mode ",
                         "deleted file mode ", "old mode ", "new mode ", "rename from ",
                         "rename to ", "copy from ", "copy to ", "similarity index ")
    if any(line.startswith(forbidden_headers) for line in patch.splitlines()):
        raise PermissionError("Only plain unified diffs are supported; metadata and binary patches are refused")

    lines = patch.splitlines()
    file_pairs: list[tuple[str, str]] = []
    old_path: str | None = None
    for line in lines:
        if line.startswith("--- "):
            old_path = line[4:].split("\t", 1)[0].split(" ", 1)[0]
        elif line.startswith("+++ "):
            new_path = line[4:].split("\t", 1)[0].split(" ", 1)[0]
            if old_path is None:
                raise ValueError("Malformed unified diff: missing old file header")
            file_pairs.append((old_path, new_path))
            old_path = None
    if not file_pairs or not any(line.startswith("@@") for line in lines):
        raise ValueError("Patch must contain file headers and at least one hunk")

    root = workspace.resolve()
    targets: list[str] = []
    for old, new in file_pairs:
        old_rel = old.removeprefix("a/")
        new_rel = new.removeprefix("b/")
        if old == "/dev/null" or new == "/dev/null" or old_rel != new_rel:
            raise PermissionError("Only in-place modifications of existing files are allowed")
        for header_path in (old_rel, new_rel):
            if "\\" in header_path:
                raise PermissionError("Backslashes are not allowed in patch paths")
            if header_path.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", header_path):
                raise PermissionError("Absolute paths are not allowed")
            parts = Path(header_path).parts
            if not header_path or any(part in {"..", ".git", ".aurix"} for part in parts):
                raise PermissionError("Unsafe path in patch")
            if Path(header_path).name.lower() in SENSITIVE_NAMES or Path(header_path).name.lower().startswith(".env."):
                raise PermissionError("Patch may not modify sensitive files")
        target = safe_path(root, new_rel)
        if not target.is_file() or target.is_symlink():
            raise PermissionError("Patch targets must be existing regular files")
        relative = target.relative_to(root).as_posix()
        tracked = _git(root, ["ls-files", "--error-unmatch", "--", relative])
        if tracked.returncode != 0:
            raise PermissionError(f"Patch target is not tracked by Git: {relative}")
        targets.append(relative)
    return targets


def apply_proposal(workspace: Path | str, proposal_id: str, *, confirm: bool = False) -> dict[str, str]:
    """Apply a reviewed proposal only after explicit confirmation and clean-tree checks."""
    if not confirm:
        raise PermissionError("Explicit confirmation is required to apply a patch")
    root = Path(workspace).expanduser().resolve()
    proposal = _proposal_path(root, proposal_id)
    patch = proposal.read_text(encoding="utf-8")
    targets = _validate_patch(root, patch)
    inside = _git(root, ["rev-parse", "--show-toplevel"])
    if inside.returncode != 0 or Path(inside.stdout.strip()).resolve() != root:
        raise ValueError("Workspace must be the Git repository root")
    status = _git(root, ["status", "--porcelain", "--untracked-files=no"])
    if status.returncode != 0:
        raise RuntimeError(status.stderr.strip() or "Could not inspect Git status")
    if status.stdout.strip():
        raise PermissionError("Git worktree has tracked changes; commit or stash them before applying")
    check = _git(root, ["apply", "--check", "--whitespace=error", "-"], patch=patch)
    if check.returncode != 0:
        raise ValueError(f"Patch preflight failed: {check.stderr.strip()[:500]}")
    applied = _git(root, ["apply", "--whitespace=error", "-"], patch=patch)
    if applied.returncode != 0:
        raise RuntimeError(f"Patch application failed: {applied.stderr.strip()[:500]}")
    return {"proposal_id": proposal_id, "status": "applied", "files": ", ".join(targets),
            "reversible_with": f"aurix --revert-proposal {proposal_id} --confirm-revert"}


def revert_proposal(workspace: Path | str, proposal_id: str, *, confirm: bool = False) -> dict[str, str]:
    """Reverse an applied proposal if its exact inverse still applies cleanly."""
    if not confirm:
        raise PermissionError("Explicit confirmation is required to revert a patch")
    root = Path(workspace).expanduser().resolve()
    proposal = _proposal_path(root, proposal_id)
    patch = proposal.read_text(encoding="utf-8")
    _validate_patch(root, patch)
    inside = _git(root, ["rev-parse", "--show-toplevel"])
    if inside.returncode != 0 or Path(inside.stdout.strip()).resolve() != root:
        raise ValueError("Workspace must be the Git repository root")
    status = _git(root, ["status", "--porcelain", "--untracked-files=no"])
    if status.returncode != 0 or not status.stdout.strip():
        raise PermissionError("No tracked changes are available to revert, or Git status failed")
    check = _git(root, ["apply", "--reverse", "--check", "--whitespace=error", "-"], patch=patch)
    if check.returncode != 0:
        raise ValueError("Exact reverse patch no longer applies; refusing to risk unrelated changes")
    result = _git(root, ["apply", "--reverse", "--whitespace=error", "-"], patch=patch)
    if result.returncode != 0:
        raise RuntimeError(f"Patch reversal failed: {result.stderr.strip()[:500]}")
    return {"proposal_id": proposal_id, "status": "reverted", "files": "tracked patch targets"}
