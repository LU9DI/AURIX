# Changelog

## 0.44.0 — Local retrieval and inference efficiency

- Added a dependency-free SQLite knowledge index for text and source files.
- Added BM25-like lexical retrieval with source-path and chunk references.
- Added CLI commands to index, search, and inspect the local index without invoking a model.
- Excluded common internal/build directories and symlinks from indexing.
- This is lexical RAG infrastructure; embeddings, SSM/BitNet model execution, and model-weight training are not implemented by this change.

## 0.43.0 — Continual learning foundation

- Added evidence-gated learning candidates and consent-separated training export.
