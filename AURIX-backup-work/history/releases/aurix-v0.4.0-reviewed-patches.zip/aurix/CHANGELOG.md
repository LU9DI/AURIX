# Changelog

## 0.4.0 — Explicit patch application and reversal

- Added separate CLI commands to apply or reverse a stored proposal only after an explicit confirmation flag.
- Require the workspace to be the Git repository root and the tracked worktree to be clean before applying a patch.
- Restrict patches to in-place modifications of existing tracked regular files.
- Reject binary/metadata diffs, renames, copies, additions/deletions, unsafe paths, symlinks, and sensitive filenames.
- Run `git apply --check` before application and reverse-check before attempting a reversal.
- Added focused tests and updated safety documentation.

This is not a sandbox and does not establish that a patch is semantically correct. Review every diff and inspect the worktree after applying or reverting.
