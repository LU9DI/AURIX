import pytest
from aurix.memory.sqlite import SQLiteMemory


def test_memory_add_and_search(tmp_path):
    memory = SQLiteMemory(tmp_path / "memory.db")
    record_id = memory.add("repo:demo", "Fix the flaky authentication test", {"source": "test"})
    results = memory.search("authentication", scope="repo:demo")
    assert results[0]["id"] == record_id
    assert results[0]["metadata"]["source"] == "test"


def test_memory_rejects_empty_values(tmp_path):
    memory = SQLiteMemory(tmp_path / "memory.db")
    with pytest.raises(ValueError):
        memory.add("", "content")
