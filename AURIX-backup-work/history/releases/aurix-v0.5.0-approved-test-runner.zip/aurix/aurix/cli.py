import argparse
import json
from pathlib import Path

from aurix.config import get_max_steps
from aurix.evaluation.benchmark import load_cases, run_benchmark
from aurix.orchestrator import Orchestrator
from aurix.providers.factory import create_provider
from aurix.tools.workspace import build_workspace_context
from aurix.tools.patches import apply_proposal, revert_proposal
from aurix.tools.execution import run_test_suite


def main() -> None:
    parser = argparse.ArgumentParser(prog="aurix", description="AURIX local-first engineering agent")
    parser.add_argument("task", nargs="?", help="Task to reason about")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--benchmark", help="Run a JSON benchmark file instead of a single task")
    parser.add_argument("--json", action="store_true", help="Print machine-readable output")
    parser.add_argument("--apply-proposal", metavar="ID", help="Apply a reviewed patch proposal")
    parser.add_argument("--confirm-apply", action="store_true", help="Explicitly confirm patch application")
    parser.add_argument("--revert-proposal", metavar="ID", help="Reverse an applied patch proposal")
    parser.add_argument("--confirm-revert", action="store_true", help="Explicitly confirm patch reversal")
    parser.add_argument("--run-tests", choices=("pytest", "ruff"), help="Run a fixed test/lint command")
    parser.add_argument("--confirm-run-tests", action="store_true", help="Confirm execution in this trusted workspace")
    parser.add_argument("--test-timeout", type=int, default=120, help="Test timeout in seconds (max 120)")
    args = parser.parse_args()

    if args.run_tests:
        if args.apply_proposal or args.revert_proposal or args.confirm_apply or args.confirm_revert:
            parser.error("Test execution cannot be combined with patch operations")
        try:
            result = run_test_suite(args.workspace, args.run_tests, confirm=args.confirm_run_tests,
                                    timeout_seconds=args.test_timeout)
        except (ValueError, PermissionError, OSError) as exc:
            parser.exit(2, f"AURIX test execution refused/failed: {exc}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
              f"{result['suite']}: {'PASSED' if result['passed'] else 'FAILED'} "
              f"(exit={result['returncode']}, timeout={result['timed_out']})\n"
              f"{result['stdout']}\n{result['stderr']}")
        return
    if args.confirm_run_tests and not args.run_tests:
        parser.error("--confirm-run-tests requires --run-tests")
    if args.apply_proposal or args.revert_proposal:
        if args.apply_proposal and args.revert_proposal:
            parser.error("Choose either --apply-proposal or --revert-proposal")
        if args.apply_proposal and args.confirm_revert or args.revert_proposal and args.confirm_apply:
            parser.error("Confirmation flag does not match the requested operation")
        try:
            if args.apply_proposal:
                result = apply_proposal(args.workspace, args.apply_proposal, confirm=args.confirm_apply)
            else:
                result = revert_proposal(args.workspace, args.revert_proposal, confirm=args.confirm_revert)
        except (ValueError, PermissionError, OSError, RuntimeError) as exc:
            parser.exit(2, f"AURIX patch operation refused/failed: {exc}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
              f"Proposal {result['proposal_id']}: {result['status']} ({result['files']})")
        return
    if args.confirm_apply or args.confirm_revert:
        parser.error("A confirmation flag requires its matching proposal operation")
    provider = create_provider()
    orchestrator = Orchestrator(provider, max_steps=get_max_steps(), workspace=args.workspace)

    if args.benchmark:
        report = run_benchmark(orchestrator, load_cases(args.benchmark))
        print(json.dumps(report, ensure_ascii=False, indent=2) if args.json else
              f"AURIX benchmark: {report['passed']}/{report['cases']} passed ({report['pass_rate']:.0%})")
        return

    workspace = Path(args.workspace).expanduser().resolve()
    task = args.task or input("AURIX task> ").strip()
    context = build_workspace_context(workspace)
    result = orchestrator.run(task, context)
    if args.json:
        print(json.dumps({"status": result.status, "steps": result.steps, "message": result.message,
                          "trace": result.trace}, ensure_ascii=False, indent=2))
    else:
        print(f"\nAURIX [{result.status}] after {result.steps} step(s)\n{result.message}")
        print("\nNo autonomous file edits or shell execution are enabled.")


if __name__ == "__main__":
    main()
