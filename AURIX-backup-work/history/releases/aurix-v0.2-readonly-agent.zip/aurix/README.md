# AURIX

**Open, local-first AI engineering agent.** AURIX is an open-source project to build an agent that can inspect software projects, plan changes, use tools safely, run tests, and learn from measured outcomes—with no paid API required by default.

> Status: early research scaffold, not production-ready autonomous software engineering.

## Principles
- **Local-first:** local inference first; remote providers are optional adapters.
- **Tool-grounded:** prefer deterministic tools over unnecessary model calls.
- **Safe by default:** narrow workspace boundaries, command allowlists, bounded execution.
- **Measured, not hyped:** optimize only when reproducible evaluations show improvement.
- **Open and modular:** providers, memory backends, and tools are replaceable.

## Quick start

Requires Python 3.11+.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env
pytest
```

### Choose an inference engine

Ollama is **not required**. The default adapter speaks the OpenAI-compatible Chat Completions API, supported by local engines such as [LM Studio](https://lmstudio.ai/), [llama.cpp server](https://github.com/ggml-org/llama.cpp), and [vLLM](https://docs.vllm.ai/), as well as compatible hosted endpoints. Start one of those servers, then set `AURIX_BASE_URL` and `AURIX_MODEL` in `.env`.

```dotenv
AURIX_PROVIDER=openai-compatible
AURIX_BASE_URL=http://localhost:1234/v1
AURIX_MODEL=your-loaded-model-name
AURIX_API_KEY=
```

To use Ollama instead, set `AURIX_PROVIDER=ollama`, `AURIX_BASE_URL=http://localhost:11434`, and choose a model installed in Ollama. Provider selection lives behind one interface, so the core does not depend on any one inference vendor.

**Can we build our own model?** Yes, incrementally: first our own orchestration, evaluation, memory, retrieval, tool-use and inference runtime; later fine-tune an open-weight model on licensed data if benchmarks justify it. Training a competitive foundation model from scratch is a separate, expensive research effort—not something solved by changing the inference server.

The CLI now has a bounded, read-only tool loop: the model can request file listing, reading, and literal text search through an explicit allowlist. Tool results are treated as untrusted data. It does not autonomously edit files or execute model-proposed shell commands.

## Optional Neon memory

Set `DATABASE_URL` to a Neon PostgreSQL connection string and install `pip install -e ".[neon]"`. SQLite is the zero-setup default. Neon stores memory; it does not perform model inference.

## Development

```bash
pytest
ruff check .
```

See `docs/ARCHITECTURE.md`, `docs/SAFETY.md`, and `CONTRIBUTING.md`.

## Roadmap
1. Reproducible baseline and evaluation task format.
2. Provider-independent tracing and adapters for compatible local and hosted inference servers.
3. Bounded read-only tool loop for repository listing, file reads, and text search.
4. Repository map, reviewed diff-based edits, and sandboxed test execution.
5. Persistent memory and measured retrieval quality.
6. Multi-agent verification only if ablation benchmarks prove useful.
7. Public benchmarks for quality, latency, memory, and API/model cost.

## License
Apache-2.0, pending a final dependency and model-license audit before public release.

## Run a repeatable smoke benchmark

The benchmark runner checks simple, explicit acceptance terms and records latency and rough token estimates. It is a regression aid, **not** a complete measure of reasoning quality; token estimates use characters/4 and must not be treated as tokenizer counts or provider billing.

```bash
aurix --benchmark benchmarks/smoke.json --json
```

By default, metadata-only run telemetry is appended to `.aurix/runs.jsonl`. Prompts and completions are not written to this file. Disable persistence by injecting a custom telemetry implementation in Python; telemetry path can be changed with `AURIX_TELEMETRY_PATH`.
