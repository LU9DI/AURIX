import json
import pytest
from aurix.orchestrator import Orchestrator

class FakeProvider:
    def __init__(self, response): self.response = response
    def generate(self, prompt, *, system=""): return self.response


def test_orchestrator_returns_model_answer():
    result = Orchestrator(FakeProvider(json.dumps({"status": "final", "message": "Inspect tests first."}))).run("Review tests")
    assert result.status == "completed"
    assert result.message == "Inspect tests first."


def test_orchestrator_rejects_empty_task():
    with pytest.raises(ValueError):
        Orchestrator(FakeProvider("{}")).run(" ")

class SequenceProvider:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.prompts = []

    def generate(self, prompt, *, system=""):
        self.prompts.append(prompt)
        return self.responses.pop(0)


def test_orchestrator_can_call_read_only_tool_and_continue(tmp_path):
    from aurix.telemetry import JSONLTelemetry
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "app.py").write_text("def launch():\n    return 'ready'\n", encoding="utf-8")
    provider = SequenceProvider(
        json.dumps({"status": "tool_call", "tool": "search_text", "arguments": {"query": "launch"}}),
        json.dumps({"status": "final", "message": "The launch function is defined in src/app.py."}),
    )
    result = Orchestrator(provider, workspace=tmp_path, telemetry=JSONLTelemetry(tmp_path / "runs.jsonl")).run("Find launch")
    assert result.status == "completed"
    assert result.steps == 2
    assert "src/app.py" in result.message
    assert "launch" in provider.prompts[1]


def test_orchestrator_rejects_unapproved_tool(tmp_path):
    provider = SequenceProvider(
        json.dumps({"status": "tool_call", "tool": "run_shell", "arguments": {"command": "rm -rf ."}}),
        json.dumps({"status": "final", "message": "No shell tool is available."}),
    )
    result = Orchestrator(provider, workspace=tmp_path).run("Run a command")
    assert result.status == "completed"
    assert "No shell tool" in result.message


def test_orchestrator_stops_at_step_limit(tmp_path):
    response = json.dumps({"status": "tool_call", "tool": "list_files", "arguments": {}})
    result = Orchestrator(SequenceProvider(response, response), max_steps=2, workspace=tmp_path).run("List and inspect")
    assert result.status == "step_limit"
    assert result.steps == 2
