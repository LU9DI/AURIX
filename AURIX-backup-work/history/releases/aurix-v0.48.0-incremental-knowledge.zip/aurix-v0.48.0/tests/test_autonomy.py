import asyncio
import json
from pathlib import Path

from aurix.autonomy import AutonomousKernel, StudyQueue


class FakeProvider:
    def __init__(self, response=None):
        self.response = response or json.dumps({
            "summary": "A concise note.",
            "key_points": ["A point"],
            "uncertainties": ["Needs independent verification"],
            "follow_up_topics": ["Rust async cancellation", "Rust async cancellation safety"],
            "sources": [],
        })
        self.calls = 0

    def generate(self, prompt, *, system=""):
        self.calls += 1
        assert "untrusted data" in system.lower() or "untrusted" in prompt.lower()
        return self.response


def test_queue_deduplicates_and_prioritizes(tmp_path: Path):
    queue = StudyQueue(tmp_path / "autonomy.db")
    first = queue.enqueue("  Rust   async ", priority=1)
    duplicate = queue.enqueue("Rust async", priority=4)
    queue.enqueue("SQLite WAL", priority=3)
    assert first["id"] == duplicate["id"]
    assert queue.claim_next()["topic"] == "SQLite WAL"


def test_study_once_creates_candidate_and_followup(tmp_path: Path):
    queue = StudyQueue(tmp_path / ".aurix" / "autonomy.db")
    queue.enqueue("Rust async cancellation")
    provider = FakeProvider()
    kernel = AutonomousKernel(provider, tmp_path)
    result = kernel.study_once()
    assert result["status"] == "candidate_created"
    assert result["review_required"] is True
    assert result["follow_up_topics_enqueued"] == 1
    assert provider.calls == 1
    status = queue.status()
    assert status["counts"]["completed"] == 1
    assert status["counts"]["pending"] == 1


def test_invalid_model_json_is_saved_as_review_candidate(tmp_path: Path):
    queue = StudyQueue(tmp_path / ".aurix" / "autonomy.db")
    queue.enqueue("Topic")
    kernel = AutonomousKernel(FakeProvider("not json"), tmp_path)
    result = kernel.study_once()
    assert result["status"] == "candidate_created"
    from aurix.learning import LearningStore
    records = LearningStore(tmp_path / ".aurix" / "learning.db").list_records(scope="autonomous-study")
    assert len(records) == 1
    assert records[0]["status"] == "candidate"
    assert records[0]["consent_to_train"] is False


def test_empty_queue_does_not_call_provider(tmp_path: Path):
    provider = FakeProvider()
    kernel = AutonomousKernel(provider, tmp_path)
    assert kernel.study_once()["status"] == "idle"
    assert provider.calls == 0


def test_daemon_stops_after_bounded_cycles(tmp_path: Path):
    queue = StudyQueue(tmp_path / ".aurix" / "autonomy.db")
    queue.enqueue("Topic")
    kernel = AutonomousKernel(FakeProvider(), tmp_path, min_interval_seconds=60,
                              max_interval_seconds=60, max_cycles=1)
    result = asyncio.run(kernel.run())
    assert result["status"] == "stopped"
    assert result["cycles"] == 1
    assert queue.status()["counts"]["completed"] == 1
