# Changelog

## 0.48.0 — Incremental knowledge synchronization

- Knowledge indexing now hashes file contents and skips unchanged files on repeat runs.
- Changed files replace their old chunks rather than accumulating stale versions.
- Added root-scoped source ownership metadata and stale-file cleanup after complete scans.
- Added `--index-sync PATH` for explicit synchronization; `--index-add` also refreshes incrementally.
- Truncated scans do not prune missing sources, and cleanup respects overlapping indexed roots.
- Added regression tests for unchanged files, changed files, deletion, root isolation, and scan truncation.


## 0.47.0 — Policy-aware autonomous web research

- Added optional SearXNG adapter for bounded public-web search during autonomous study.
- Added bounded extraction of HTML text and source URL/title/snippet provenance.
- Rejects non-HTTP(S), credential-bearing, local/private hostnames and targets resolving to non-public IP addresses before fetching pages.
- Disables automatic redirects to avoid following unvalidated redirect destinations.
- Checks `robots.txt` before fetching result pages and fails closed when the policy cannot be checked.
- Web research remains disabled unless `AURIX_SEARXNG_URL` is explicitly configured.
- Search results and page text remain untrusted input; findings remain learning candidates and training consent remains false.
- This adapter does not bypass logins, CAPTCHAs, robots directives, paywalls, or provider access controls.

## 0.46.0 — Autonomous study kernel foundation

- Added a durable SQLite topic queue with priorities, deduplication, bounded retries, and persistent daemon state.
- Added an autonomous study cycle that records model-generated notes only as unverified learning candidates; training consent remains false by default.
- Added bounded background-loop controls, randomized idle intervals, Linux available-memory guard, stop-file support, and max-cycle limits.
- Added optional research-adapter injection without implementing stealth scraping or bypassing access controls.
- Added CLI operations to enqueue/list topics, run one cycle, or start a supervised daemon.
- The daemon uses the configured provider for synthesis; internet research is not active unless a compliant research adapter is supplied.

## 0.45.0 — Automatic local RAG in agent tasks

- Integrated local SQLite knowledge retrieval into the orchestrator before the first model call.
- Retrieved snippets include relative source paths, chunk numbers, and ranking scores as untrusted evidence.
- Added bounded retrieval controls and an environment switch; local index failures do not stop tasks.
- Retrieval uses an existing `.aurix/knowledge.db`; it does not scan or index files implicitly.
- Added telemetry for retrieved evidence count and result-level knowledge provenance.

## 0.44.0 — Local retrieval and inference efficiency

- Added a dependency-free SQLite knowledge index for text and source files.
- Added BM25-like lexical retrieval with source-path and chunk references.
- Added CLI commands to index, search, and inspect the local index without invoking a model.
- Excluded common internal/build directories and symlinks from indexing.
- This is lexical RAG infrastructure; embeddings, SSM/BitNet model execution, and model-weight training are not implemented by this change.

## 0.43.0 — Continual learning foundation

- Added evidence-gated learning candidates and consent-separated training export.
