"""AURIX: a local-first open-source AI engineering agent."""

__version__ = "0.38.0"
