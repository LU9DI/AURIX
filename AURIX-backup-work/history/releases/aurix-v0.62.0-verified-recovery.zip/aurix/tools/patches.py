"""Explicitly confirmed application and reversal of AURIX patch proposals.

This is a guardrail, not a sandbox. Only tracked, existing regular files may be
modified; the Git worktree must be clean before application.
"""
from __future__ import annotations

import re
import json
import hashlib
import subprocess
from pathlib import Path
from typing import Sequence

from aurix.tools.workspace import SENSITIVE_NAMES, safe_path
from aurix.tools.provenance import append_audit_event, verify_proposal_integrity

_PROPOSAL_ID = re.compile(r"^[0-9a-f]{12}$")
_MAX_PATCH_BYTES = 100_000


def _git(workspace: Path, args: Sequence[str], *, patch: str | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args], cwd=workspace, input=patch, text=True,
        capture_output=True, timeout=15, check=False,
    )


def _proposal_path(workspace: Path, proposal_id: str) -> Path:
    if not _PROPOSAL_ID.fullmatch(proposal_id):
        raise ValueError("Invalid proposal ID")
    root = workspace.expanduser().resolve()
    metadata = root / ".aurix"
    proposal_dir = metadata / "proposals"
    if metadata.is_symlink() or proposal_dir.is_symlink():
        raise PermissionError("AURIX proposal directories must not be symlinks")
    path = proposal_dir / f"{proposal_id}.diff"
    # Do not follow symlinks, even if they point back inside the repository.
    if path.is_symlink() or not path.is_file():
        raise FileNotFoundError(f"Patch proposal not found: {proposal_id}")
    if path.stat().st_size > _MAX_PATCH_BYTES:
        raise ValueError("Patch proposal exceeds size limit")
    verify_proposal_integrity(path, proposal_id)
    return path


def _validate_patch(workspace: Path, patch: str) -> list[str]:
    if not patch.strip() or "\x00" in patch:
        raise ValueError("Patch is empty or contains a NUL byte")
    if len(patch.encode("utf-8")) > _MAX_PATCH_BYTES:
        raise ValueError("Patch proposal exceeds size limit")
    forbidden_headers = ("GIT binary patch", "diff --git ", "index ", "new file mode ",
                         "deleted file mode ", "old mode ", "new mode ", "rename from ",
                         "rename to ", "copy from ", "copy to ", "similarity index ")
    if any(line.startswith(forbidden_headers) for line in patch.splitlines()):
        raise PermissionError("Only plain unified diffs are supported; metadata and binary patches are refused")

    lines = patch.splitlines()
    file_pairs: list[tuple[str, str]] = []
    old_path: str | None = None
    for line in lines:
        if line.startswith("--- "):
            old_path = line[4:].split("\t", 1)[0].split(" ", 1)[0]
        elif line.startswith("+++ "):
            new_path = line[4:].split("\t", 1)[0].split(" ", 1)[0]
            if old_path is None:
                raise ValueError("Malformed unified diff: missing old file header")
            file_pairs.append((old_path, new_path))
            old_path = None
    if not file_pairs or not any(line.startswith("@@") for line in lines):
        raise ValueError("Patch must contain file headers and at least one hunk")

    root = workspace.resolve()
    targets: list[str] = []
    for old, new in file_pairs:
        old_rel = old.removeprefix("a/")
        new_rel = new.removeprefix("b/")
        if old == "/dev/null" or new == "/dev/null" or old_rel != new_rel:
            raise PermissionError("Only in-place modifications of existing files are allowed")
        for header_path in (old_rel, new_rel):
            if "\\" in header_path:
                raise PermissionError("Backslashes are not allowed in patch paths")
            if header_path.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", header_path):
                raise PermissionError("Absolute paths are not allowed")
            parts = Path(header_path).parts
            if not header_path or any(part in {"..", ".git", ".aurix"} for part in parts):
                raise PermissionError("Unsafe path in patch")
            if Path(header_path).name.lower() in SENSITIVE_NAMES or Path(header_path).name.lower().startswith(".env."):
                raise PermissionError("Patch may not modify sensitive files")
        target = safe_path(root, new_rel)
        if not target.is_file() or target.is_symlink():
            raise PermissionError("Patch targets must be existing regular files")
        relative = target.relative_to(root).as_posix()
        tracked = _git(root, ["ls-files", "--error-unmatch", "--", relative])
        if tracked.returncode != 0:
            raise PermissionError(f"Patch target is not tracked by Git: {relative}")
        targets.append(relative)
    return targets


def _tracked_status(workspace: Path) -> str:
    result = _git(workspace, ["status", "--porcelain", "--untracked-files=no"])
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Could not verify Git worktree state")
    return result.stdout.strip()


def _rollback_exact_patch(workspace: Path, patch: str, *, expected_status: str, reason: str) -> None:
    """Apply the exact inverse and verify the final tracked-worktree state."""
    reverse_check = _git(workspace, ["apply", "--reverse", "--check", "--whitespace=error", "-"], patch=patch)
    if reverse_check.returncode != 0:
        raise RuntimeError(
            f"{reason}; automatic rollback refused because the exact inverse no longer applies. "
            "Recovery status: manual_intervention_required. Inspect the worktree immediately."
        )
    rollback = _git(workspace, ["apply", "--reverse", "--whitespace=error", "-"], patch=patch)
    if rollback.returncode != 0:
        raise RuntimeError(
            f"{reason}; automatic rollback failed. Recovery status: manual_intervention_required. "
            "Inspect the worktree immediately."
        )
    try:
        actual_status = _tracked_status(workspace)
    except Exception as exc:
        raise RuntimeError(
            f"{reason}; inverse patch ran but final state could not be verified. "
            "Recovery status: manual_intervention_required."
        ) from exc
    if actual_status != expected_status:
        raise RuntimeError(
            f"{reason}; inverse patch ran but final tracked status differs from expectation. "
            "Recovery status: manual_intervention_required. Inspect the worktree immediately."
        )


def apply_proposal(
    workspace: Path | str, proposal_id: str, *, confirm: bool = False,
    require_audit_gate: bool = False,
) -> dict[str, str]:
    """Apply a proposal after explicit confirmation and optional passing-audit gate.

    The gate binds recorded low-risk review and passing verification to the exact
    proposal digest. Local evidence is tamper-evident, not a remote trust anchor.
    """
    if not confirm:
        raise PermissionError("Explicit confirmation is required to apply a patch")
    root = Path(workspace).expanduser().resolve()
    proposal = _proposal_path(root, proposal_id)
    patch = proposal.read_text(encoding="utf-8")
    patch_digest = hashlib.sha256(proposal.read_bytes()).hexdigest()
    if require_audit_gate:
        audit_dir = root / ".aurix" / "audits"
        audit_path = audit_dir / f"{proposal_id}.json"
        if audit_dir.is_symlink() or audit_path.is_symlink() or not audit_path.is_file() or audit_path.stat().st_size > 1_000_000:
            raise PermissionError("A passing audit record is required before application")
        try:
            audit = json.loads(audit_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise PermissionError("Audit evidence is unreadable; refusing application") from exc
        verification = audit.get("verification", {})
        review = audit.get("review", {})
        tracks = audit.get("review_tracks", {})
        security_track = tracks.get("security", {})
        correctness_track = tracks.get("correctness", {})
        verification_evidence = {key: verification.get(key) for key in (
            "proposal_id", "proposal_sha256", "base_commit", "suite", "requested_suite",
            "test_selection", "isolation", "sandbox_image", "sandbox_image_id",
            "runtime_fingerprint", "baseline_result", "test_result", "regression_status",
        )}
        expected_evidence_digest = hashlib.sha256(json.dumps(
            verification_evidence, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        ).encode("utf-8")).hexdigest()
        head = _git(root, ["rev-parse", "HEAD"])
        if (audit.get("schema_version") != 6
                or audit.get("proposal_id") != proposal_id
                or audit.get("proposal_sha256") != patch_digest
                or audit.get("status") != "audit_passed"
                or not head.returncode == 0
                or audit.get("base_commit") != head.stdout.strip()
                or verification.get("evidence_sha256") != expected_evidence_digest
                or verification.get("proposal_id") != proposal_id
                or verification.get("proposal_sha256") != patch_digest
                or verification.get("base_commit") != head.stdout.strip()
                or verification.get("suite") not in {"pytest", "ruff"}
                or verification.get("requested_suite") not in {"pytest", "ruff", "auto"}
                or not isinstance(verification.get("test_selection"), dict)
                or verification.get("isolation") not in {"trusted", "docker"}
                or not isinstance(verification.get("runtime_fingerprint"), dict)
                or not all(verification["runtime_fingerprint"].get(key) for key in (
                    "python_version", "python_implementation", "system", "release", "machine"
                ))
                or (verification.get("isolation") == "docker" and not re.fullmatch(
                    r"sha256:[0-9a-f]{64}", str(verification.get("sandbox_image_id", ""))
                ))
                or (verification.get("isolation") == "trusted" and verification.get("sandbox_image_id") is not None)
                or verification.get("regression_status") == "introduced_failure"
                or not isinstance(verification.get("test_result"), dict)
                or not verification["test_result"].get("passed", False)
                or review.get("risk_level") != "low"
                or security_track.get("proposal_sha256", security_track.get("integrity", {}).get("sha256")) != patch_digest
                or correctness_track.get("proposal_sha256") != patch_digest
                or correctness_track.get("risk_level") != "low"
                or verification.get("status") != "verified_pass"):
            raise PermissionError("Audit evidence does not approve this exact patch; rerun audit and verification")
    targets = _validate_patch(root, patch)
    inside = _git(root, ["rev-parse", "--show-toplevel"])
    if inside.returncode != 0 or Path(inside.stdout.strip()).resolve() != root:
        raise ValueError("Workspace must be the Git repository root")
    status = _git(root, ["status", "--porcelain", "--untracked-files=no"])
    if status.returncode != 0:
        raise RuntimeError(status.stderr.strip() or "Could not inspect Git status")
    if status.stdout.strip():
        raise PermissionError("Git worktree has tracked changes; commit or stash them before applying")
    if hashlib.sha256(proposal.read_bytes()).hexdigest() != patch_digest:
        raise PermissionError("Proposal changed during application preflight; refusing to apply")
    check = _git(root, ["apply", "--check", "--whitespace=error", "-"], patch=patch)
    if check.returncode != 0:
        raise ValueError(f"Patch preflight failed: {check.stderr.strip()[:500]}")
    applied = _git(root, ["apply", "--whitespace=error", "-"], patch=patch)
    if applied.returncode != 0:
        # Git apply is expected to be atomic, but explicitly inspect and recover
        # if a Git/platform failure leaves any of the intended edits behind.
        reverse_check = _git(root, ["apply", "--reverse", "--check", "--whitespace=error", "-"], patch=patch)
        if reverse_check.returncode == 0:
            _rollback_exact_patch(root, patch, expected_status="", reason="Patch application failed")
        raise RuntimeError(
            f"Patch application failed: {applied.stderr.strip()[:500]}. "
            "Recovery status: manual_intervention_required; inspect the worktree."
        )

    def rollback_applied_patch(reason: str) -> None:
        _rollback_exact_patch(root, patch, expected_status="", reason=reason)

    # Confirm the resulting tracked diff is exactly the set of approved targets.
    changed = _git(root, ["diff", "--name-only", "--no-renames"])
    actual_targets = sorted(line for line in changed.stdout.splitlines() if line)
    if changed.returncode != 0 or actual_targets != sorted(set(targets)):
        rollback_applied_patch("Applied diff did not match the approved target set")
        raise RuntimeError("Applied diff did not match the approved target set; changes were rolled back")
    if hashlib.sha256(proposal.read_bytes()).hexdigest() != patch_digest:
        rollback_applied_patch("Proposal changed during application")
        raise PermissionError("Proposal changed during application; changes were rolled back")
    try:
        append_audit_event(root, "proposal_applied", proposal_id, {
            "files": targets, "patch_sha256": patch_digest,
        })
    except Exception as exc:
        rollback_applied_patch("Could not persist the application audit event")
        raise RuntimeError("Audit logging failed; patch application was rolled back") from exc
    return {"proposal_id": proposal_id, "status": "applied", "files": ", ".join(targets),
            "reversible_with": f"aurix --revert-proposal {proposal_id} --confirm-revert",
            "transaction": "applied_and_audited"}


def revert_proposal(workspace: Path | str, proposal_id: str, *, confirm: bool = False) -> dict[str, str]:
    """Reverse an applied proposal if its exact inverse still applies cleanly."""
    if not confirm:
        raise PermissionError("Explicit confirmation is required to revert a patch")
    root = Path(workspace).expanduser().resolve()
    proposal = _proposal_path(root, proposal_id)
    patch = proposal.read_text(encoding="utf-8")
    _validate_patch(root, patch)
    inside = _git(root, ["rev-parse", "--show-toplevel"])
    if inside.returncode != 0 or Path(inside.stdout.strip()).resolve() != root:
        raise ValueError("Workspace must be the Git repository root")
    status = _git(root, ["status", "--porcelain", "--untracked-files=no"])
    if status.returncode != 0 or not status.stdout.strip():
        raise PermissionError("No tracked changes are available to revert, or Git status failed")
    check = _git(root, ["apply", "--reverse", "--check", "--whitespace=error", "-"], patch=patch)
    if check.returncode != 0:
        raise ValueError("Exact reverse patch no longer applies; refusing to risk unrelated changes")
    before_status = status.stdout.strip()
    result = _git(root, ["apply", "--reverse", "--whitespace=error", "-"], patch=patch)
    if result.returncode != 0:
        raise RuntimeError(f"Patch reversal failed: {result.stderr.strip()[:500]}")
    after_status = _tracked_status(root)
    if not after_status:
        try:
            append_audit_event(root, "proposal_reverted", proposal_id, {
                "files": "tracked patch targets", "recovery_status": "not_needed",
            })
        except Exception as exc:
            # Reapply the exact patch so an audit failure does not silently leave
            # a reversal that the caller believes was recorded.
            forward_check = _git(root, ["apply", "--check", "--whitespace=error", "-"], patch=patch)
            if forward_check.returncode != 0:
                raise RuntimeError(
                    "Reversal audit logging failed and forward recovery is unsafe. "
                    "Recovery status: manual_intervention_required."
                ) from exc
            forward = _git(root, ["apply", "--whitespace=error", "-"], patch=patch)
            if forward.returncode != 0 or not _tracked_status(root):
                raise RuntimeError(
                    "Reversal audit logging failed and recovery could not be verified. "
                    "Recovery status: manual_intervention_required."
                ) from exc
            raise RuntimeError("Reversal audit logging failed; original patch was restored") from exc
        return {"proposal_id": proposal_id, "status": "reverted", "files": "tracked patch targets",
                "transaction": "reverted_and_audited", "recovery_status": "verified"}
    # Existing tracked changes may predate the patch; the exact inverse must
    # restore the same status, not merely any non-empty dirty state.
    if after_status != before_status:
        forward_check = _git(root, ["apply", "--check", "--whitespace=error", "-"], patch=patch)
        if forward_check.returncode == 0:
            forward = _git(root, ["apply", "--whitespace=error", "-"], patch=patch)
            if forward.returncode == 0 and _tracked_status(root) == before_status:
                raise RuntimeError("Reversal changed unexpected tracked state; original patch was restored")
        raise RuntimeError("Reversal changed unexpected tracked state; recovery status: manual_intervention_required")
    try:
        append_audit_event(root, "proposal_reverted", proposal_id, {
            "files": "tracked patch targets", "recovery_status": "verified",
        })
    except Exception as exc:
        forward_check = _git(root, ["apply", "--check", "--whitespace=error", "-"], patch=patch)
        if forward_check.returncode != 0:
            raise RuntimeError(
                "Reversal audit logging failed and forward recovery is unsafe. "
                "Recovery status: manual_intervention_required."
            ) from exc
        forward = _git(root, ["apply", "--whitespace=error", "-"], patch=patch)
        if forward.returncode != 0 or _tracked_status(root) != before_status:
            raise RuntimeError(
                "Reversal audit logging failed and recovery could not be verified. "
                "Recovery status: manual_intervention_required."
            ) from exc
        raise RuntimeError("Reversal audit logging failed; original patch was restored") from exc
    return {"proposal_id": proposal_id, "status": "reverted", "files": "tracked patch targets",
            "transaction": "reverted_and_audited", "recovery_status": "verified"}
