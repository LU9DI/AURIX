"""Deterministic heuristic review for proposed unified diffs.

This is a triage aid, not a proof of correctness or security.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from aurix.tools.patches import _proposal_path, _validate_patch
from aurix.tools.provenance import append_audit_event, verify_proposal_integrity

_RULES: tuple[tuple[str, str, str, re.Pattern[str]], ...] = (
    ("dynamic-code", "high", "Added code may evaluate or execute dynamically",
     re.compile(r"\b(eval|exec)\s*\(")),
    ("shell-execution", "high", "Added code may invoke a shell or subprocess",
     re.compile(r"\b(subprocess\.(run|Popen|call|check_call|check_output)|os\.system|shell\s*=\s*True)\b")),
    ("deserialization", "high", "Added code may use unsafe deserialization",
     re.compile(r"\bpickle\.(loads|load)\s*\(|\byaml\.load\s*\(")),
    ("tls-validation", "medium", "Added code may disable TLS certificate verification",
     re.compile(r"\bverify\s*=\s*False\b|CERT_NONE")),
    ("secret-literal", "high", "Added code may contain a hard-coded credential",
     re.compile(r"(?i)(api[_-]?key|secret|password|token)\s*=\s*['\"][^'\"]{8,}['\"]")),
    ("broad-permissions", "medium", "Added code may set broad filesystem permissions",
     re.compile(r"chmod\s*\(.*0?777|\b0o777\b")),
    ("sql-concatenation", "medium", "Added code may build SQL using string concatenation/interpolation",
     re.compile(r"(?i)(select|insert|update|delete)\s+.{0,80}(\+\s*\w+|%s|\{\w+\})")),
)


def review_proposal(workspace: Path | str, proposal_id: str) -> dict[str, Any]:
    """Return a bounded static review of newly added diff lines."""
    root = Path(workspace).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Workspace must be a directory")
    proposal = _proposal_path(root, proposal_id)
    integrity = verify_proposal_integrity(proposal, proposal_id)
    patch = proposal.read_text(encoding="utf-8")
    targets = _validate_patch(root, patch)
    findings: list[dict[str, Any]] = []
    current_file = ""
    added_count = 0
    for line_number, line in enumerate(patch.splitlines(), start=1):
        if line.startswith("+++ "):
            current_file = line[4:].split("\t", 1)[0].removeprefix("b/")
            continue
        if not line.startswith("+") or line.startswith("+++"):
            continue
        added_count += 1
        added = line[1:]
        for rule_id, severity, summary, pattern in _RULES:
            if pattern.search(added):
                findings.append({
                    "rule": rule_id,
                    "severity": severity,
                    "file": current_file,
                    "patch_line": line_number,
                    "summary": summary,
                    "sample": added.strip()[:240],
                })
    risk = "high" if any(x["severity"] == "high" for x in findings) else (
        "medium" if findings else "low")
    append_audit_event(root, "proposal_reviewed", proposal_id, {"risk_level": risk, "finding_count": len(findings), "sha256": integrity["sha256"]})
    return {
        "proposal_id": proposal_id,
        "integrity": integrity,
        "status": "review_required",
        "risk_level": risk,
        "targets": targets,
        "added_lines_scanned": added_count,
        "finding_count": len(findings),
        "findings": findings[:100],
        "limitations": [
            "Heuristic scan covers added diff lines only and can miss vulnerabilities.",
            "A low risk level does not mean the patch is safe or correct.",
            "Human review and appropriate tests remain required.",
        ],
        "apply_permitted_by_review": False,
    }


_CORRECTNESS_RULES: tuple[tuple[str, str, str, re.Pattern[str]], ...] = (
    ("swallowed-exception", "medium", "Added code may silently swallow an exception",
     re.compile(r"except(?:\s+[A-Za-z_][\w.]*)?\s*:\s*(?:#.*)?$")),
    ("assert-false", "medium", "Added code contains an unconditional failing assertion",
     re.compile(r"\bassert\s+(?:False|0|None)\b")),
    ("empty-exception-handler", "medium", "Added exception handler may have no meaningful handling",
     re.compile(r"^\s*pass\s*(?:#.*)?$")),
)


def review_correctness_proposal(workspace: Path | str, proposal_id: str) -> dict[str, Any]:
    """Run a separate deterministic correctness/robustness triage over added lines.

    This is intentionally independent from the security rule set, but is still a
    heuristic: it cannot establish semantic correctness or replace real tests.
    """
    root = Path(workspace).expanduser().resolve(strict=True)
    proposal = _proposal_path(root, proposal_id)
    digest = __import__("hashlib").sha256(proposal.read_bytes()).hexdigest()
    patch = proposal.read_text(encoding="utf-8")
    _validate_patch(root, patch)
    findings: list[dict[str, Any]] = []
    current_file = ""
    previous_added: str | None = None
    for line_number, line in enumerate(patch.splitlines(), start=1):
        if line.startswith("+++ "):
            current_file = line[4:].split("\t", 1)[0].removeprefix("b/")
            previous_added = None
            continue
        if not line.startswith("+") or line.startswith("+++"):
            continue
        added = line[1:]
        for rule_id, severity, summary, pattern in _CORRECTNESS_RULES:
            if pattern.search(added):
                # An empty handler is only a finding when the added line is pass;
                # the rule is intentionally conservative and may need human review.
                findings.append({"rule": rule_id, "severity": severity, "file": current_file,
                                "patch_line": line_number, "summary": summary,
                                "sample": added.strip()[:240]})
        previous_added = added
    risk = "medium" if findings else "low"
    append_audit_event(root, "proposal_correctness_reviewed", proposal_id,
                       {"risk_level": risk, "finding_count": len(findings), "sha256": digest})
    return {"proposal_id": proposal_id, "proposal_sha256": digest,
            "status": "review_required", "risk_level": risk,
            "finding_count": len(findings), "findings": findings[:100],
            "limitations": ["Static heuristics cannot prove functional correctness.",
                            "Passing this review track does not replace tests or human review."],
            "apply_permitted_by_review": False}
