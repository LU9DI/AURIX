import subprocess

import pytest

from aurix.tools.patches import apply_proposal, revert_proposal


def make_repo(tmp_path):
    root = tmp_path / "repo"
    root.mkdir()
    subprocess.run(["git", "init", str(root)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(root), "config", "user.email", "aurix-test@example.invalid"], check=True)
    subprocess.run(["git", "-C", str(root), "config", "user.name", "AURIX tests"], check=True)
    (root / "app.py").write_text("value = 'old'\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "app.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "initial"], check=True, capture_output=True)
    proposal_dir = root / ".aurix" / "proposals"
    proposal_dir.mkdir(parents=True)
    proposal_id = "a1b2c3d4e5f6"
    patch = "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-value = 'old'\n+value = 'new'\n"
    (proposal_dir / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    return root, proposal_id


def test_apply_requires_explicit_confirmation(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    with pytest.raises(PermissionError, match="confirmation"):
        apply_proposal(root, proposal_id)
    assert "old" in (root / "app.py").read_text(encoding="utf-8")


def test_apply_and_revert_reviewed_proposal(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    result = apply_proposal(root, proposal_id, confirm=True)
    assert result["status"] == "applied"
    assert "new" in (root / "app.py").read_text(encoding="utf-8")
    reverted = revert_proposal(root, proposal_id, confirm=True)
    assert reverted["status"] == "reverted"
    assert "old" in (root / "app.py").read_text(encoding="utf-8")


def test_apply_refuses_dirty_tracked_worktree(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    (root / "app.py").write_text("user edit\n", encoding="utf-8")
    with pytest.raises(PermissionError, match="tracked changes"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_untracked_target(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = "--- a/new.py\n+++ b/new.py\n@@ -1 +1 @@\n-old\n+new\n"
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="existing regular files"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_path_traversal(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = "--- a/../outside.py\n+++ b/../outside.py\n@@ -1 +1 @@\n-old\n+new\n"
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="Unsafe path"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_git_metadata_headers(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = ("diff --git a/app.py b/app.py\nindex 1234567..89abcde 100644\n"
             "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-value = 'old'\n+value = 'new'\n")
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="plain unified diffs"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_with_audit_gate_rejects_missing_evidence(tmp_path):
    import pytest
    from aurix.tools.patches import apply_proposal

    root, proposal_id = make_repo(tmp_path)
    with pytest.raises(PermissionError, match="passing audit record"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)
