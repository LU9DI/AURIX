# Changelog

## 0.54.0 — Integrated patch review loop

- Exposed the deterministic proposal-review tool directly to the orchestrator, allowing a model to create a review-only patch and then request bounded static triage by proposal ID.
- Kept review separate from application: heuristic findings never authorize patch application or imply that tests passed.
- Enforced a strict proposal-ID argument schema and kept the tool unavailable to arbitrary shell execution or file-writing flows.
- Added end-to-end regression coverage for proposal creation followed by independent review of added diff lines.

## 0.53.0 — Role-scoped read-only agent tools

- Added a capability-limited toolbox for project inventory, safe path listing/reading, literal workspace search, local knowledge retrieval, and read-only Git status.
- Each role has an explicit tool allowlist; every call is schema-validated and outputs are bounded. Sensitive files and symlinks are rejected by workspace readers.
- Added a strict JSON tool-request protocol with a maximum of three tool calls per agent run and one final synthesis request; ordinary text-only provider responses continue to work.
- Tool errors are returned as bounded error types without leaking exception text or credentials. No arbitrary shell, file writes, network access, or recursive agent spawning is exposed.
- Added regression tests for allowed/denied capabilities, bounded protocol parsing, and secret-file exclusion.


## 0.52.0 — Bounded parallel specialist teams

- Specialist contributions can run concurrently through a bounded thread pool (1–4 workers); each worker creates its own configured provider instance and results retain deterministic role order.
- Added sequential mode for providers that do not support concurrent requests, plus CLI worker-count validation.
- Task-scoped team profiles are deleted after execution so repeated runs do not fill the persistent named-agent registry; explicitly created named specialists remain persistent.
- Team outputs report execution mode, worker bound, partial failures, and the security boundary: no implicit shell, filesystem, or external-tool permissions.
- Added tests for parallel execution, sequential mode, and temporary-profile cleanup.

## 0.51.0 — Persistent specialist-agent factory

- Added a bounded SQLite registry for named specialist profiles with validated roles, descriptions, uniqueness, and a configurable hard cap.
- Added CLI operations to create, list, and run specialist agents using the configured provider.
- Added task-scoped team creation: architect, researcher, and reviewer profiles each contribute independently; a coordinator synthesizes successful outputs and exposes partial failures.
- Specialist outputs are treated as untrusted proposals. No shell, filesystem mutation, credentials, or external-tool permissions are granted implicitly.
- Agents are role profiles, not separate autonomous model instances; team runs are bounded and use the configured provider. No recursive spawning or unlimited agent creation is allowed.
- Added tests for persistence, invalid roles/names, duplicate names, provider delegation, team creation, and partial failures.


## 0.48.0 — Incremental knowledge synchronization

- Knowledge indexing now hashes file contents and skips unchanged files on repeat runs.
- Changed files replace their old chunks rather than accumulating stale versions.
- Added root-scoped source ownership metadata and stale-file cleanup after complete scans.
- Added `--index-sync PATH` for explicit synchronization; `--index-add` also refreshes incrementally.
- Truncated scans do not prune missing sources, and cleanup respects overlapping indexed roots.
- Added regression tests for unchanged files, changed files, deletion, root isolation, and scan truncation.


## 0.47.0 — Policy-aware autonomous web research

- Added optional SearXNG adapter for bounded public-web search during autonomous study.
- Added bounded extraction of HTML text and source URL/title/snippet provenance.
- Rejects non-HTTP(S), credential-bearing, local/private hostnames and targets resolving to non-public IP addresses before fetching pages.
- Disables automatic redirects to avoid following unvalidated redirect destinations.
- Checks `robots.txt` before fetching result pages and fails closed when the policy cannot be checked.
- Web research remains disabled unless `AURIX_SEARXNG_URL` is explicitly configured.
- Search results and page text remain untrusted input; findings remain learning candidates and training consent remains false.
- This adapter does not bypass logins, CAPTCHAs, robots directives, paywalls, or provider access controls.

## 0.46.0 — Autonomous study kernel foundation

- Added a durable SQLite topic queue with priorities, deduplication, bounded retries, and persistent daemon state.
- Added an autonomous study cycle that records model-generated notes only as unverified learning candidates; training consent remains false by default.
- Added bounded background-loop controls, randomized idle intervals, Linux available-memory guard, stop-file support, and max-cycle limits.
- Added optional research-adapter injection without implementing stealth scraping or bypassing access controls.
- Added CLI operations to enqueue/list topics, run one cycle, or start a supervised daemon.
- The daemon uses the configured provider for synthesis; internet research is not active unless a compliant research adapter is supplied.

## 0.45.0 — Automatic local RAG in agent tasks

- Integrated local SQLite knowledge retrieval into the orchestrator before the first model call.
- Retrieved snippets include relative source paths, chunk numbers, and ranking scores as untrusted evidence.
- Added bounded retrieval controls and an environment switch; local index failures do not stop tasks.
- Retrieval uses an existing `.aurix/knowledge.db`; it does not scan or index files implicitly.
- Added telemetry for retrieved evidence count and result-level knowledge provenance.

## 0.44.0 — Local retrieval and inference efficiency

- Added a dependency-free SQLite knowledge index for text and source files.
- Added BM25-like lexical retrieval with source-path and chunk references.
- Added CLI commands to index, search, and inspect the local index without invoking a model.
- Excluded common internal/build directories and symlinks from indexing.
- This is lexical RAG infrastructure; embeddings, SSM/BitNet model execution, and model-weight training are not implemented by this change.

## 0.43.0 — Continual learning foundation

- Added evidence-gated learning candidates and consent-separated training export.
