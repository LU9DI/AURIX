import subprocess
import hashlib

import pytest

from aurix.tools.patches import apply_proposal, revert_proposal


def make_repo(tmp_path):
    root = tmp_path / "repo"
    root.mkdir()
    subprocess.run(["git", "init", str(root)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(root), "config", "user.email", "aurix-test@example.invalid"], check=True)
    subprocess.run(["git", "-C", str(root), "config", "user.name", "AURIX tests"], check=True)
    (root / "app.py").write_text("value = 'old'\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "app.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "initial"], check=True, capture_output=True)
    proposal_dir = root / ".aurix" / "proposals"
    proposal_dir.mkdir(parents=True)
    proposal_id = "a1b2c3d4e5f6"
    patch = "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-value = 'old'\n+value = 'new'\n"
    (proposal_dir / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    return root, proposal_id


def test_apply_requires_explicit_confirmation(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    with pytest.raises(PermissionError, match="confirmation"):
        apply_proposal(root, proposal_id)
    assert "old" in (root / "app.py").read_text(encoding="utf-8")


def test_apply_and_revert_reviewed_proposal(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    result = apply_proposal(root, proposal_id, confirm=True)
    assert result["status"] == "applied"
    assert "new" in (root / "app.py").read_text(encoding="utf-8")
    reverted = revert_proposal(root, proposal_id, confirm=True)
    assert reverted["status"] == "reverted"
    assert "old" in (root / "app.py").read_text(encoding="utf-8")


def test_apply_refuses_dirty_tracked_worktree(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    (root / "app.py").write_text("user edit\n", encoding="utf-8")
    with pytest.raises(PermissionError, match="tracked changes"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_untracked_target(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = "--- a/new.py\n+++ b/new.py\n@@ -1 +1 @@\n-old\n+new\n"
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="existing regular files"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_path_traversal(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = "--- a/../outside.py\n+++ b/../outside.py\n@@ -1 +1 @@\n-old\n+new\n"
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="Unsafe path"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_git_metadata_headers(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = ("diff --git a/app.py b/app.py\nindex 1234567..89abcde 100644\n"
             "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-value = 'old'\n+value = 'new'\n")
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="plain unified diffs"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_with_audit_gate_rejects_missing_evidence(tmp_path):
    import pytest
    from aurix.tools.patches import apply_proposal

    root, proposal_id = make_repo(tmp_path)
    with pytest.raises(PermissionError, match="passing audit record"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def _write_passing_audit(root, proposal_id):
    import hashlib
    import json
    import subprocess

    proposal = root / ".aurix" / "proposals" / f"{proposal_id}.diff"
    patch_digest = hashlib.sha256(proposal.read_bytes()).hexdigest()
    base_commit = subprocess.run(
        ["git", "-C", str(root), "rev-parse", "HEAD"], check=True,
        capture_output=True, text=True,
    ).stdout.strip()
    verification = {
        "audit_id": "a" * 32,
        "verification_id": "b" * 32,
        "proposal_id": proposal_id,
        "proposal_sha256": patch_digest,
        "base_commit": base_commit,
        "suite": "pytest",
        "requested_suite": "pytest",
        "test_selection": {"mode": "full_suite", "reason": "test fixture", "paths": []},
        "isolation": "trusted",
        "sandbox_image": None,
        "sandbox_image_id": None,
        "runtime_fingerprint": {"python_version": "3.test", "python_implementation": "CPython", "system": "TestOS", "release": "1", "machine": "test"},
        "baseline_result": {"passed": True, "returncode": 0},
        "test_result": {"passed": True, "returncode": 0},
        "regression_status": "clean",
    }
    verification["evidence_sha256"] = hashlib.sha256(json.dumps(
        verification, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
    ).encode("utf-8")).hexdigest()
    record = {
        "schema_version": 8,
        "audit_id": "a" * 32,
        "proposal_id": proposal_id,
        "proposal_sha256": patch_digest,
        "base_commit": base_commit,
        "status": "audit_passed",
        "review": {"risk_level": "low"},
        "review_tracks": {
            "security": {"proposal_sha256": patch_digest, "risk_level": "low",
                         "evidence_schema": 1, "findings": [],
                         "integrity": {"sha256": patch_digest}},
            "correctness": {"proposal_sha256": patch_digest, "risk_level": "low",
                            "evidence_schema": 1, "findings": []},
        },
        "verification": {**verification, "status": "verified_pass"},
    }
    audit_dir = root / ".aurix" / "audits"
    audit_dir.mkdir(parents=True, exist_ok=True)
    (audit_dir / f"{proposal_id}.json").write_text(json.dumps(record), encoding="utf-8")


def test_audit_gate_accepts_evidence_bound_to_current_head(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    result = apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)
    assert result["status"] == "applied"


def test_audit_gate_rejects_evidence_for_previous_head(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    (root / "app.py").write_text("value = 'another commit'\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "app.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "advance head"], check=True, capture_output=True)
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def test_audit_gate_rejects_tampered_verification_evidence(tmp_path):
    import json

    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    path = root / ".aurix" / "audits" / f"{proposal_id}.json"
    audit = json.loads(path.read_text(encoding="utf-8"))
    audit["verification"]["test_result"]["passed"] = False
    path.write_text(json.dumps(audit), encoding="utf-8")
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def test_apply_rolls_back_when_audit_logging_fails(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)

    def fail_audit(*args, **kwargs):
        raise OSError("simulated audit storage failure")

    monkeypatch.setattr(patches, "append_audit_event", fail_audit)
    with pytest.raises(RuntimeError, match="rolled back"):
        apply_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"
    status = subprocess.run(
        ["git", "-C", str(root), "status", "--porcelain", "--untracked-files=no"],
        check=True, capture_output=True, text=True,
    ).stdout
    assert status == ""


def test_apply_reports_transaction_state(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    result = apply_proposal(root, proposal_id, confirm=True)
    assert result["transaction"] == "applied_and_audited"


def test_apply_rollback_verifies_final_tracked_status(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)
    original_append = patches.append_audit_event

    def fail_audit(*args, **kwargs):
        raise OSError("simulated audit failure")

    monkeypatch.setattr(patches, "append_audit_event", fail_audit)
    with pytest.raises(RuntimeError, match="rolled back"):
        apply_proposal(root, proposal_id, confirm=True)
    assert patches._tracked_status(root) == ""
    monkeypatch.setattr(patches, "append_audit_event", original_append)


def test_revert_reports_verified_transaction(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    result = revert_proposal(root, proposal_id, confirm=True)
    assert result["transaction"] == "reverted_and_audited"
    assert result["recovery_status"] == "verified"
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"


def test_revert_restores_patch_if_audit_logging_fails(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)

    def fail_audit(*args, **kwargs):
        raise OSError("simulated audit failure")

    monkeypatch.setattr(patches, "append_audit_event", fail_audit)
    with pytest.raises(RuntimeError, match="original patch was restored"):
        revert_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'new'\n"
    assert patches._tracked_status(root) == "M app.py"


def test_patch_operation_refuses_existing_workspace_lock(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    lock = root / ".aurix" / "operation.lock"
    lock.write_text('{"pid": 999999, "created_at": 0}', encoding="utf-8")
    with pytest.raises(PermissionError, match="workspace lock"):
        apply_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"


def test_apply_detects_head_change_during_preflight(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)
    (root / "other.py").write_text("value = 1\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "other.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "add unrelated file"], check=True, capture_output=True)
    original_git = patches._git
    changed = False

    def race_git(workspace, args, *, patch=None):
        nonlocal changed
        result = original_git(workspace, args, patch=patch)
        if args[:2] == ["apply", "--check"] and not changed:
            changed = True
            (root / "other.py").write_text("value = 2\n", encoding="utf-8")
            subprocess.run(["git", "-C", str(root), "add", "other.py"], check=True)
            subprocess.run(["git", "-C", str(root), "commit", "-m", "concurrent commit"], check=True, capture_output=True)
        return result

    monkeypatch.setattr(patches, "_git", race_git)
    with pytest.raises(PermissionError, match="HEAD changed during preflight"):
        apply_proposal(root, proposal_id, confirm=True)
    assert "new" not in (root / "app.py").read_text(encoding="utf-8")
    assert patches._git_head(root) != ""


def test_audit_gate_rejects_finding_with_mismatched_line_evidence(tmp_path):
    import json
    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    path = root / ".aurix" / "audits" / f"{proposal_id}.json"
    audit = json.loads(path.read_text(encoding="utf-8"))
    patch = (root / ".aurix" / "proposals" / f"{proposal_id}.diff").read_bytes()
    digest = hashlib.sha256(patch).hexdigest()
    audit["review_tracks"]["security"]["findings"] = [{
        "file": "app.py", "patch_line": 4, "evidence": {
            "file": "app.py", "patch_line": 4, "patch_sha256": digest,
            "line_sha256": "0" * 64, "source_line": 1, "hunk": "@@ -1 +1 @@",
        }
    }]
    path.write_text(json.dumps(audit), encoding="utf-8")
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def test_audit_gate_rejects_cross_cycle_verification(tmp_path):
    import json

    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    path = root / ".aurix" / "audits" / f"{proposal_id}.json"
    audit = json.loads(path.read_text(encoding="utf-8"))
    audit["verification"]["audit_id"] = "c" * 32
    # Recompute the ordinary evidence digest to prove cycle identity is an independent gate.
    evidence = {key: audit["verification"].get(key) for key in (
        "audit_id", "verification_id", "proposal_id", "proposal_sha256", "base_commit",
        "suite", "requested_suite", "test_selection", "isolation", "sandbox_image",
        "sandbox_image_id", "runtime_fingerprint", "baseline_result", "test_result",
        "regression_status",
    )}
    audit["verification"]["evidence_sha256"] = hashlib.sha256(__import__("json").dumps(
        evidence, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
    ).encode("utf-8")).hexdigest()
    path.write_text(json.dumps(audit), encoding="utf-8")
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)
