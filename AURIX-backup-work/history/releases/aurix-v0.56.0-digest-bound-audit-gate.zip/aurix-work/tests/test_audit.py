from __future__ import annotations

import subprocess

from aurix import audit as audit_module
from aurix.audit import audit_proposal


def _repo_with_proposal(tmp_path, added_line="value = 'new'"):
    root = tmp_path / "repo"
    root.mkdir()
    subprocess.run(["git", "init", str(root)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(root), "config", "user.email", "aurix-test@example.invalid"], check=True)
    subprocess.run(["git", "-C", str(root), "config", "user.name", "AURIX tests"], check=True)
    (root / "app.py").write_text("value = 'old'\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "app.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "initial"], check=True, capture_output=True)
    proposal_id = "a1b2c3d4e5f6"
    proposal_dir = root / ".aurix" / "proposals"
    proposal_dir.mkdir(parents=True)
    patch = f"--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-value = 'old'\n+{added_line}\n"
    (proposal_dir / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    return root, proposal_id


def test_audit_does_not_run_verification_without_confirmation(tmp_path, monkeypatch):
    root, proposal_id = _repo_with_proposal(tmp_path)

    def forbidden_verify(*args, **kwargs):
        raise AssertionError("verification must not run without confirmation")

    monkeypatch.setattr(audit_module, "verify_proposal", forbidden_verify)
    result = audit_proposal(root, proposal_id)
    assert result["status"] == "reviewed_verification_not_run"
    assert result["verification"]["status"] == "not_run"
    assert result["application"] == {"performed": False, "permitted_by_review": False}
    assert len(result["proposal_sha256"]) == 64
    assert result["audited_at"]


def test_audit_reports_pass_only_for_low_risk_and_passing_verification(tmp_path, monkeypatch):
    root, proposal_id = _repo_with_proposal(tmp_path)
    monkeypatch.setattr(audit_module, "verify_proposal", lambda *a, **kw: {
        "proposal_id": proposal_id, "status": "verified_pass", "suite": "pytest",
        "primary_workspace_modified": False,
    })
    result = audit_proposal(root, proposal_id, confirm_verify=True)
    assert result["status"] == "audit_passed"
    assert result["verification"]["status"] == "verified_pass"
    assert result["application"]["performed"] is False


def test_audit_high_risk_never_reports_audit_passed(tmp_path, monkeypatch):
    root, proposal_id = _repo_with_proposal(tmp_path, "result = eval(user_input)")
    monkeypatch.setattr(audit_module, "verify_proposal", lambda *a, **kw: {
        "proposal_id": proposal_id, "status": "verified_pass", "suite": "pytest",
        "primary_workspace_modified": False,
    })
    result = audit_proposal(root, proposal_id, confirm_verify=True)
    assert result["review"]["risk_level"] == "high"
    assert result["status"] == "audit_needs_attention"


def test_audit_record_is_bound_to_exact_patch_digest(tmp_path, monkeypatch):
    import hashlib
    import json

    root, proposal_id = _repo_with_proposal(tmp_path)
    monkeypatch.setattr(audit_module, "verify_proposal", lambda *a, **kw: {
        "proposal_id": proposal_id, "status": "verified_pass", "suite": "pytest",
        "primary_workspace_modified": False,
    })
    result = audit_proposal(root, proposal_id, confirm_verify=True)
    saved = json.loads((root / ".aurix" / "audits" / f"{proposal_id}.json").read_text())
    actual = hashlib.sha256((root / ".aurix" / "proposals" / f"{proposal_id}.diff").read_bytes()).hexdigest()
    assert result["status"] == "audit_passed"
    assert saved["proposal_sha256"] == actual
    assert saved["status"] == "audit_passed"


def test_audit_refuses_to_record_if_patch_changes_during_review(tmp_path, monkeypatch):
    root, proposal_id = _repo_with_proposal(tmp_path)
    original_review = audit_module.review_proposal

    def mutate_after_review(workspace, pid):
        result = original_review(workspace, pid)
        patch = root / ".aurix" / "proposals" / f"{pid}.diff"
        patch.write_text(patch.read_text() + "# changed\n", encoding="utf-8")
        return result

    monkeypatch.setattr(audit_module, "review_proposal", mutate_after_review)
    try:
        audit_proposal(root, proposal_id)
    except PermissionError as exc:
        assert "changed during audit" in str(exc)
    else:
        raise AssertionError("stale audit evidence must be refused")
    assert not (root / ".aurix" / "audits" / f"{proposal_id}.json").exists()
