import argparse
import json
from pathlib import Path

from aurix.config import get_max_steps
from aurix.evaluation.benchmark import load_cases, run_benchmark
from aurix.orchestrator import Orchestrator
from aurix.providers.factory import create_provider
from aurix.tools.workspace import build_workspace_context
from aurix.tools.patches import apply_proposal, revert_proposal
from aurix.tools.execution import run_test_suite
from aurix.tools.verification import verify_proposal
from aurix.diagnostics import run_diagnostics
from aurix.tools.review import review_proposal
from aurix.reports import attach_audit_to_run_report, verify_run_report, write_run_report
from aurix.audit import audit_proposal
from aurix.memory import create_memory, retrieve_memories


def main() -> None:
    parser = argparse.ArgumentParser(prog="aurix", description="AURIX local-first engineering agent")
    parser.add_argument("task", nargs="?", help="Task to reason about")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--doctor", action="store_true", help="Run read-only installation/readiness checks")
    parser.add_argument("--probe-provider", action="store_true", help="Make a live model request (may consume compute/API credits)")
    parser.add_argument("--benchmark", help="Run a JSON benchmark file instead of a single task")
    parser.add_argument("--report-run", metavar="PATH", help="Explicitly save a local JSON run report inside the workspace (includes task text)")
    parser.add_argument("--verify-run-report", metavar="PATH", help="Verify the SHA-256 integrity digest of an existing run report")
    parser.add_argument("--json", action="store_true", help="Print machine-readable output")
    parser.add_argument("--apply-proposal", metavar="ID", help="Apply a reviewed patch proposal")
    parser.add_argument("--confirm-apply", action="store_true", help="Explicitly confirm patch application")
    parser.add_argument("--revert-proposal", metavar="ID", help="Reverse an applied patch proposal")
    parser.add_argument("--confirm-revert", action="store_true", help="Explicitly confirm patch reversal")
    parser.add_argument("--verify-proposal", metavar="ID", help="Test a proposal in a disposable Git worktree")
    parser.add_argument("--review-proposal", metavar="ID", help="Run a deterministic heuristic review of a patch proposal")
    parser.add_argument("--audit-proposal", metavar="ID", help="Review a proposal and report one combined audit result")
    parser.add_argument("--confirm-audit-verify", action="store_true", help="Explicitly run tests for the audited proposal in a disposable Git worktree")
    parser.add_argument("--attach-audit-to-report", metavar="PATH", help="Attach compact audit evidence to an existing schema-v2 run report")
    parser.add_argument("--confirm-verify", action="store_true", help="Explicitly confirm proposal verification")
    parser.add_argument("--verify-suite", choices=("pytest", "ruff"), default="pytest", help="Suite for proposal verification")
    parser.add_argument("--run-tests", choices=("pytest", "ruff"), help="Run a fixed test/lint command")
    parser.add_argument("--confirm-run-tests", action="store_true", help="Confirm execution in this trusted workspace")
    parser.add_argument("--test-timeout", type=int, default=120, help="Test timeout in seconds (max 120)")
    parser.add_argument("--memory-add", metavar="TEXT", help="Explicitly store a memory record")
    parser.add_argument("--memory-kind", choices=("fact", "hypothesis", "decision", "test_result", "observation"), default="observation", help="Evidence type for --memory-add")
    parser.add_argument("--memory-confidence", type=float, help="Optional confidence from 0.0 to 1.0 for --memory-add")
    parser.add_argument("--memory-search", metavar="QUERY", help="Search stored memory records")
    parser.add_argument("--memory-scope", default="default", help="Memory isolation scope (default: default)")
    parser.add_argument("--use-memory-context", action="store_true", help="Explicitly retrieve scoped memories and include bounded evidence in a task prompt")
    parser.add_argument("--memory-backend", choices=("sqlite", "postgres"), help="Override AURIX_MEMORY_BACKEND")
    parser.add_argument("--memory-limit", type=int, default=10, help="Maximum ranked memory results (1-50)")
    parser.add_argument("--memory-candidates", type=int, default=100, help="Recent scoped memories to rank (1-500)")
    parser.add_argument("--memory-max-content-chars", type=int, default=4000, help="Maximum characters per returned memory (100-20000)")
    args = parser.parse_args()

    if args.use_memory_context and (args.memory_add is not None or args.memory_search is not None):
        parser.error("--use-memory-context cannot be combined with --memory-add or --memory-search")

    if args.memory_add is not None or args.memory_search is not None:
        if args.memory_add is not None and args.memory_search is not None:
            parser.error("Choose either --memory-add or --memory-search")
        if args.memory_search is not None and (args.memory_kind != "observation" or args.memory_confidence is not None):
            parser.error("--memory-kind and --memory-confidence require --memory-add")
        if args.task or args.benchmark or args.report_run or args.apply_proposal or args.revert_proposal or args.verify_proposal or args.review_proposal or args.audit_proposal or args.run_tests or args.doctor or args.verify_run_report:
            parser.error("Memory operations cannot be combined with a task or another operation")
        if not args.memory_scope.strip():
            parser.error("--memory-scope must not be empty")
        try:
            store = create_memory(args.memory_backend, workspace=args.workspace)
            if args.memory_add is not None:
                if args.memory_confidence is not None and not 0.0 <= args.memory_confidence <= 1.0:
                    raise ValueError("--memory-confidence must be between 0 and 1")
                metadata = {"source": "cli", "kind": args.memory_kind}
                if args.memory_confidence is not None:
                    metadata["confidence"] = args.memory_confidence
                record_id = store.add(args.memory_scope, args.memory_add, metadata)
                result = {"status": "stored", "id": record_id, "scope": args.memory_scope, "metadata": metadata}
            else:
                records = retrieve_memories(
                    store, args.memory_search, scope=args.memory_scope, limit=args.memory_limit,
                    candidate_limit=args.memory_candidates, max_content_chars=args.memory_max_content_chars,
                )
                result = {"status": "ok", "scope": args.memory_scope, "count": len(records), "records": records,
                          "retrieval": "lexical_overlap", "semantic_search": False}
        except (ValueError, PermissionError, OSError, RuntimeError) as exc:
            parser.exit(2, f"AURIX memory operation failed: {type(exc).__name__}: {exc}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else (
            f"Memory record {result['id']} stored in scope {result['scope']}" if args.memory_add is not None
            else f"Found {result['count']} memory record(s) in scope {result['scope']}"
        ))
        return

    if args.verify_run_report:
        try:
            result = verify_run_report(args.workspace, args.verify_run_report)
        except (ValueError, PermissionError, OSError) as exc:
            parser.exit(2, f"AURIX report verification failed: {exc}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
              f"Run report {result['status']}: {result['path']}")
        if not result["valid"]:
            raise SystemExit(1)
        return

    if args.attach_audit_to_report and not args.audit_proposal:
        parser.error("--attach-audit-to-report requires --audit-proposal")
    if args.probe_provider and not args.doctor:
        parser.error("--probe-provider requires --doctor")
    if args.doctor:
        try:
            provider = create_provider() if args.probe_provider else None
            result = run_diagnostics(args.workspace, probe_provider=args.probe_provider, provider=provider)
        except (ValueError, OSError, RuntimeError) as exc:
            parser.exit(2, f"AURIX diagnostics failed: {type(exc).__name__}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
              f"AURIX doctor: {result['status']}\n" + "\n".join(
                  f"[{item['status']}] {item['name']}: {item['detail']}" for item in result["checks"]))
        return

    if args.run_tests:
        if args.apply_proposal or args.revert_proposal or args.verify_proposal or args.review_proposal or args.audit_proposal or args.confirm_apply or args.confirm_revert or args.confirm_verify or args.confirm_audit_verify:
            parser.error("Test execution cannot be combined with patch operations or proposal verification")
        try:
            result = run_test_suite(args.workspace, args.run_tests, confirm=args.confirm_run_tests,
                                    timeout_seconds=args.test_timeout)
        except (ValueError, PermissionError, OSError) as exc:
            parser.exit(2, f"AURIX test execution refused/failed: {exc}\n")
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else
              f"{result['suite']}: {'PASSED' if result['passed'] else 'FAILED'} "
              f"(exit={result['returncode']}, timeout={result['timed_out']})\n"
              f"{result['stdout']}\n{result['stderr']}")
        return
    if args.confirm_run_tests and not args.run_tests:
        parser.error("--confirm-run-tests requires --run-tests")
    operations = [bool(args.apply_proposal), bool(args.revert_proposal), bool(args.verify_proposal), bool(args.review_proposal), bool(args.audit_proposal)]
    if any(operations):
        if sum(operations) > 1:
            parser.error("Choose only one proposal operation")
        if args.apply_proposal and (args.confirm_revert or args.confirm_verify):
            parser.error("Confirmation flag does not match the requested operation")
        if args.revert_proposal and (args.confirm_apply or args.confirm_verify):
            parser.error("Confirmation flag does not match the requested operation")
        if args.verify_proposal and (args.confirm_apply or args.confirm_revert):
            parser.error("Confirmation flag does not match the requested operation")
        if args.review_proposal and (args.confirm_apply or args.confirm_revert or args.confirm_verify or args.confirm_audit_verify):
            parser.error("Review cannot be combined with operation confirmation flags")
        if args.audit_proposal and (args.confirm_apply or args.confirm_revert or args.confirm_verify):
            parser.error("Proposal audit cannot be combined with unrelated confirmation flags")
        if args.confirm_audit_verify and not args.audit_proposal:
            parser.error("--confirm-audit-verify requires --audit-proposal")
        if args.attach_audit_to_report and not args.audit_proposal:
            parser.error("--attach-audit-to-report requires --audit-proposal")
        try:
            if args.apply_proposal:
                result = apply_proposal(args.workspace, args.apply_proposal, confirm=args.confirm_apply)
            elif args.revert_proposal:
                result = revert_proposal(args.workspace, args.revert_proposal, confirm=args.confirm_revert)
            elif args.verify_proposal:
                result = verify_proposal(args.workspace, args.verify_proposal, confirm=args.confirm_verify,
                                         suite=args.verify_suite, timeout_seconds=args.test_timeout)
            elif args.review_proposal:
                result = review_proposal(args.workspace, args.review_proposal)
            else:
                result = audit_proposal(args.workspace, args.audit_proposal,
                                        confirm_verify=args.confirm_audit_verify,
                                        suite=args.verify_suite, timeout_seconds=args.test_timeout)
                if args.attach_audit_to_report:
                    result["report_attachment"] = attach_audit_to_run_report(
                        args.workspace, args.attach_audit_to_report, audit_result=result
                    )
        except (ValueError, PermissionError, OSError, RuntimeError) as exc:
            parser.exit(2, f"AURIX patch operation refused/failed: {exc}\n")
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif args.verify_proposal:
            test_result = result["test_result"]
            print(f"Proposal {result['proposal_id']}: {result['status']} "
                  f"(suite={result['suite']}, exit={test_result['returncode']}, "
                  f"duration_ms={test_result['duration_ms']})")
            print(str(test_result.get("stdout", "")))
            if test_result.get("stderr"):
                print(str(test_result["stderr"]))
            print(str(result["security_note"]))
        elif args.audit_proposal:
            review = result["review"]
            print(f"Proposal {result['proposal_id']}: {result['status']} "
                  f"(heuristic risk={review['risk_level']}, findings={review['finding_count']}, "
                  f"verification={result['verification']['status']})")
            print("No patch was applied. Review findings and limitations before proceeding.")
            if result.get("report_attachment"):
                print(f"Audit evidence attached to run report: {result['report_attachment']['path']}")
        elif args.review_proposal:
            print(f"Proposal {result['proposal_id']}: heuristic risk={result['risk_level']} "
                  f"({result['finding_count']} finding(s)); manual review still required")
            for finding in result["findings"]:
                print(f"[{finding['severity']}] {finding['file']}:{finding['patch_line']} "
                      f"{finding['rule']}: {finding['summary']}")
        else:
            print(f"Proposal {result['proposal_id']}: {result['status']} ({result['files']})")
        return
    if args.confirm_apply or args.confirm_revert or args.confirm_verify or args.confirm_audit_verify:
        parser.error("A confirmation flag requires its matching proposal operation")
    provider = create_provider()
    memory_store = create_memory(args.memory_backend, workspace=args.workspace) if args.use_memory_context else None
    orchestrator = Orchestrator(
        provider, max_steps=get_max_steps(), workspace=args.workspace,
        memory_store=memory_store if args.use_memory_context else None,
        memory_scope=args.memory_scope, memory_limit=min(args.memory_limit, 10),
    )

    if args.benchmark:
        report = run_benchmark(orchestrator, load_cases(args.benchmark))
        print(json.dumps(report, ensure_ascii=False, indent=2) if args.json else
              f"AURIX benchmark: {report['passed']}/{report['cases']} passed ({report['pass_rate']:.0%})")
        return

    workspace = Path(args.workspace).expanduser().resolve()
    task = args.task or input("AURIX task> ").strip()
    context = build_workspace_context(workspace)
    result = orchestrator.run(task, context)
    report_info = None
    if args.report_run:
        try:
            report_info = write_run_report(args.workspace, args.report_run, task=task, result=result,
                                           provider=type(provider).__name__)
        except (ValueError, PermissionError, OSError) as exc:
            parser.exit(2, f"AURIX report could not be written: {exc}\n")
    if args.json:
        output = {"status": result.status, "steps": result.steps, "message": result.message, "trace": result.trace,
                  "memory_context": {"enabled": args.use_memory_context, "scope": args.memory_scope if args.use_memory_context else None,
                                     "evidence_count": len(result.memory_evidence), "evidence": result.memory_evidence}}
        if report_info is not None:
            output["report"] = report_info
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(f"\nAURIX [{result.status}] after {result.steps} step(s)\n{result.message}")
        print("\nNo autonomous file edits or shell execution are enabled.")
        if args.use_memory_context:
            print(f"Scoped memory context enabled: {args.memory_scope} (retrieved records are treated as untrusted evidence).")
        if report_info is not None:
            print(f"Run report saved: {report_info['path']} (run_id={report_info['run_id']})")


if __name__ == "__main__":
    main()
