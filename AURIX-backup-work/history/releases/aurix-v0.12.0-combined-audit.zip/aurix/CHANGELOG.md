# Changelog

## 0.4.0 — Explicit patch application and reversal

- Added separate CLI commands to apply or reverse a stored proposal only after an explicit confirmation flag.
- Require the workspace to be the Git repository root and the tracked worktree to be clean before applying a patch.
- Restrict patches to in-place modifications of existing tracked regular files.
- Reject binary/metadata diffs, renames, copies, additions/deletions, unsafe paths, symlinks, and sensitive filenames.
- Run `git apply --check` before application and reverse-check before attempting a reversal.
- Added focused tests and updated safety documentation.

This is not a sandbox and does not establish that a patch is semantically correct. Review every diff and inspect the worktree after applying or reverting.


## 0.5.0 — Explicitly approved test runner

- Added a fixed-command test runner for `pytest` and `ruff`; no model-controlled command arguments.
- Required explicit confirmation, bounded runtime/output, and passed a reduced environment to subprocesses.
- Added tests for confirmation, command allowlisting, timeout bounds, secret-like environment removal, and failed test outcomes.
- Clarified that process-level limits do not provide OS sandboxing; trusted repositories only.


## 0.6.0
- Added explicit proposal verification in a disposable detached Git worktree.
- Added CLI options `--verify-proposal`, `--confirm-verify`, and `--verify-suite`.
- Added integration tests proving pass/fail reporting and preservation of the primary checkout.
- Clarified that a disposable worktree is not an operating-system sandbox.

## 0.7.0 — Installation diagnostics and explicit provider probe

- Added `aurix --doctor` for read-only readiness checks across Python, workspace, Git, core dependencies, optional test/lint tools, provider configuration, and optional Neon configuration.
- Added opt-in `--probe-provider` for a real model request; this can consume local compute or hosted API credits.
- Provider probe output suppresses raw responses and exception details to avoid leaking secrets.
- Added tests for read-only behavior and safe provider-probe reporting.


## 0.8.0 — 2026-10-08

- Added deterministic heuristic review for patch proposals, focused on newly added lines.
- Added findings for dynamic execution, shell/subprocess use, unsafe deserialization, credential-like literals, TLS verification disabled, broad file permissions, and likely SQL interpolation.
- Added CLI command `--review-proposal ID` with JSON output.
- Review results never authorize application; human review remains required.
- Added tests for high-risk findings, low-risk results, removed-line exclusion, and missing proposals.


## 0.9.0 — Strict model protocol

- Reject malformed JSON and non-object responses instead of treating arbitrary model text as a successful final answer.
- Validate response status, message type, tool allowlist, and tool argument shape before dispatch.
- Enforce a 100,000-character provider-response ceiling and record bounded protocol-error labels in traces.
- Added regression tests confirming malformed or unauthorized responses cannot execute tools.


## 0.11.0 — Proposal-linked audit reports

- Capture bounded tool status and valid proposal identifiers in the execution trace without storing tool-result bodies.
- Upgrade run reports to schema version 2 and link proposals as metadata-only artifacts.
- Ignore malformed proposal identifiers when producing report artifact indexes.
- Add regression coverage for proposal linkage and exclusion of patch contents from reports.


## 0.12.0 — Combined proposal audit

- Added `--audit-proposal` to combine heuristic diff review and verification status in one structured result.
- Kept test execution opt-in behind `--confirm-audit-verify`; no tests run from an audit without explicit confirmation.
- Reports `audit_passed` only when heuristic risk is low and the selected verification suite passes. High-risk findings remain `audit_needs_attention`.
- Explicitly records that audit never applies a patch and that disposable worktree verification is not an OS sandbox.
- Added regression tests for confirmation gating and risk-aware result classification.
