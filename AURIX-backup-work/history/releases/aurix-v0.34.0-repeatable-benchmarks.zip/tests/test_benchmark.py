import json
import pytest
from aurix.evaluation.benchmark import load_cases, run_benchmark
from aurix.telemetry import JSONLTelemetry


class FakeProvider:
    def generate(self, prompt, *, system=""):
        return json.dumps({"status": "final", "message": "Run the test before changing code."})


def test_benchmark_checks_required_terms(tmp_path):
    cases = [{"id": "test-first", "task": "What first?", "must_contain": ["test", "code"]}]
    from aurix.orchestrator import Orchestrator
    report = run_benchmark(Orchestrator(FakeProvider(), telemetry=JSONLTelemetry(tmp_path / "trace.jsonl")), cases)
    assert report["cases"] == 1
    assert report["passed"] == 1
    assert report["pass_rate"] == 1.0


def test_benchmark_rejects_empty_file(tmp_path):
    path = tmp_path / "cases.json"
    path.write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError):
        load_cases(path)


def test_benchmark_checks_status_steps_and_text_exclusions(tmp_path):
    from aurix.orchestrator import Orchestrator
    cases = [{
        "id": "guardrails",
        "task": "What first?",
        "must_contain": ["test"],
        "must_not_contain": ["deploy immediately"],
        "expected_status": "completed",
        "min_steps": 1,
        "max_steps": 1,
    }]
    report = run_benchmark(Orchestrator(FakeProvider(), telemetry=JSONLTelemetry(tmp_path / "trace.jsonl")), cases)
    item = report["results"][0]
    assert report["schema_version"] == 3
    assert item["passed"] is True
    assert item["checks"] == {
        "must_contain": True,
        "must_not_contain": True,
        "required_tools": True,
        "forbidden_tools": True,
        "expected_status": True,
        "step_bounds": True,
    }


def test_benchmark_fails_missing_required_tool_and_forbidden_phrase(tmp_path):
    from aurix.orchestrator import Orchestrator
    cases = [{
        "task": "What first?",
        "required_tools": ["inspect_project"],
        "must_not_contain": ["test"],
    }]
    report = run_benchmark(Orchestrator(FakeProvider(), telemetry=JSONLTelemetry(tmp_path / "trace.jsonl")), cases)
    item = report["results"][0]
    assert item["passed"] is False
    assert item["missing_tools"] == ["inspect_project"]
    assert item["forbidden_text_found"] == ["test"]


def test_load_cases_validates_step_bounds_and_duplicate_ids(tmp_path):
    path = tmp_path / "cases.json"
    path.write_text(json.dumps([{"task": "bad", "min_steps": 4, "max_steps": 2}]), encoding="utf-8")
    with pytest.raises(ValueError, match="min_steps"):
        load_cases(path)

    from aurix.orchestrator import Orchestrator
    duplicate = [{"id": "same", "task": "one"}, {"id": "same", "task": "two"}]
    with pytest.raises(ValueError, match="Duplicate"):
        run_benchmark(Orchestrator(FakeProvider(), telemetry=JSONLTelemetry(tmp_path / "trace2.jsonl")), duplicate)


def test_load_cases_rejects_malformed_json(tmp_path):
    path = tmp_path / "broken.json"
    path.write_text("{oops", encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid benchmark JSON"):
        load_cases(path)


def test_benchmark_repetitions_reports_aggregate_stability(tmp_path):
    from aurix.orchestrator import Orchestrator

    class AlternatingProvider:
        def __init__(self):
            self.calls = 0

        def generate(self, prompt, *, system=""):
            self.calls += 1
            message = "contains target" if self.calls % 2 else "misses requirement"
            return json.dumps({"status": "final", "message": message})

    provider = AlternatingProvider()
    cases = [{"id": "unstable", "task": "repeat", "must_contain": ["target"]}]
    report = run_benchmark(
        Orchestrator(provider, telemetry=JSONLTelemetry(tmp_path / "repeat.jsonl")),
        cases,
        repetitions=4,
    )
    assert report["schema_version"] == 3
    assert report["cases"] == 1
    assert report["executions"] == 4
    assert report["passed"] == 2
    assert report["failed"] == 2
    assert report["pass_rate"] == 0.5
    assert report["consistently_passing_cases"] == 0
    assert report["per_case"][0]["pass_rate"] == 0.5
    assert len(report["results"]) == 4
    assert [item["repetition"] for item in report["results"]] == [1, 2, 3, 4]
    assert report["latency_mean_ms"] >= 0
    assert report["estimated_output_tokens_total"] > 0


def test_benchmark_repetitions_validated(tmp_path):
    from aurix.orchestrator import Orchestrator
    orchestrator = Orchestrator(FakeProvider(), telemetry=JSONLTelemetry(tmp_path / "bad-reps.jsonl"))
    with pytest.raises(ValueError, match="between 1 and 10"):
        run_benchmark(orchestrator, [{"task": "task"}], repetitions=0)
    with pytest.raises(ValueError, match="between 1 and 10"):
        run_benchmark(orchestrator, [{"task": "task"}], repetitions=11)
    with pytest.raises(ValueError, match="between 1 and 10"):
        run_benchmark(orchestrator, [{"task": "task"}], repetitions=True)
