from __future__ import annotations

import json
import statistics
import time
from pathlib import Path
from typing import Any

from aurix.orchestrator import Orchestrator
from aurix.telemetry import estimate_tokens

_STRING_LIST_FIELDS = ("must_contain", "must_not_contain", "required_tools", "forbidden_tools")
_MAX_REPETITIONS = 10


def _validate_case(case: Any, index: int) -> dict[str, Any]:
    if not isinstance(case, dict) or not isinstance(case.get("task"), str) or not case["task"].strip():
        raise ValueError(f"Benchmark case {index} requires a non-empty task")
    for field in _STRING_LIST_FIELDS:
        value = case.get(field, [])
        if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
            raise ValueError(f"Benchmark case {index}: {field} must be a list of non-empty strings")
    for field in ("min_steps", "max_steps"):
        if field in case and (isinstance(case[field], bool) or not isinstance(case[field], int) or case[field] < 0):
            raise ValueError(f"Benchmark case {index}: {field} must be a non-negative integer")
    if "min_steps" in case and "max_steps" in case and case["min_steps"] > case["max_steps"]:
        raise ValueError(f"Benchmark case {index}: min_steps cannot exceed max_steps")
    if "expected_status" in case and (not isinstance(case["expected_status"], str) or not case["expected_status"].strip()):
        raise ValueError(f"Benchmark case {index}: expected_status must be a non-empty string")
    if "context" in case and not isinstance(case["context"], str):
        raise ValueError(f"Benchmark case {index}: context must be a string")
    if "id" in case and (not isinstance(case["id"], str) or not case["id"].strip()):
        raise ValueError(f"Benchmark case {index}: id must be a non-empty string")
    return case


def load_cases(path: str | Path) -> list[dict[str, Any]]:
    """Load and validate a non-empty JSON benchmark suite."""
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid benchmark JSON: {exc}") from exc
    if not isinstance(payload, list) or not payload:
        raise ValueError("Benchmark must be a non-empty JSON array")
    return [_validate_case(case, index) for index, case in enumerate(payload)]


def run_benchmark(
    orchestrator: Orchestrator, cases: list[dict[str, Any]], *, repetitions: int = 1,
) -> dict[str, Any]:
    """Run acceptance checks repeatedly and report stability/latency aggregates.

    This is a deterministic criteria runner, not a semantic software-quality score.
    Repetitions can trigger repeated provider calls and corresponding compute/API costs.
    """
    if not isinstance(cases, list) or not cases:
        raise ValueError("Benchmark cases must be a non-empty list")
    if isinstance(repetitions, bool) or not isinstance(repetitions, int) or not 1 <= repetitions <= _MAX_REPETITIONS:
        raise ValueError(f"repetitions must be an integer between 1 and {_MAX_REPETITIONS}")
    validated = [_validate_case(case, index) for index, case in enumerate(cases)]
    case_ids = [case.get("id", f"case-{index + 1}") for index, case in enumerate(validated)]
    if len(set(case_ids)) != len(case_ids):
        raise ValueError("Duplicate benchmark case id")

    results: list[dict[str, Any]] = []
    per_case: list[dict[str, Any]] = []
    for index, case in enumerate(validated):
        case_id = case_ids[index]
        case_results = []
        for repetition in range(1, repetitions + 1):
            start = time.perf_counter()
            result = orchestrator.run(case["task"], case.get("context", ""))
            elapsed_ms = round((time.perf_counter() - start) * 1000, 2)
            normalized = result.message.casefold()
            missing = [needle for needle in case.get("must_contain", []) if needle.casefold() not in normalized]
            forbidden_text = [needle for needle in case.get("must_not_contain", []) if needle.casefold() in normalized]
            used_tools = [item["tool"] for item in result.trace if isinstance(item.get("tool"), str)]
            missing_tools = [tool for tool in case.get("required_tools", []) if tool not in used_tools]
            forbidden_tools_used = [tool for tool in case.get("forbidden_tools", []) if tool in used_tools]
            expected_status = case.get("expected_status")
            status_ok = expected_status is None or result.status == expected_status
            min_steps = case.get("min_steps")
            max_steps = case.get("max_steps")
            steps_ok = (min_steps is None or result.steps >= min_steps) and (max_steps is None or result.steps <= max_steps)
            checks = {
                "must_contain": not missing,
                "must_not_contain": not forbidden_text,
                "required_tools": not missing_tools,
                "forbidden_tools": not forbidden_tools_used,
                "expected_status": status_ok,
                "step_bounds": steps_ok,
            }
            item = {
                "id": case_id,
                "repetition": repetition,
                "passed": all(checks.values()),
                "checks": checks,
                "missing": missing,
                "forbidden_text_found": forbidden_text,
                "missing_tools": missing_tools,
                "forbidden_tools_used": forbidden_tools_used,
                "expected_status": expected_status,
                "status": result.status,
                "status_ok": status_ok,
                "steps": result.steps,
                "steps_ok": steps_ok,
                "tools_used": used_tools,
                "latency_ms": elapsed_ms,
                "estimated_output_tokens": estimate_tokens(result.message),
            }
            results.append(item)
            case_results.append(item)
        case_passed = sum(1 for item in case_results if item["passed"])
        latencies = [item["latency_ms"] for item in case_results]
        per_case.append({
            "id": case_id,
            "runs": len(case_results),
            "passed": case_passed,
            "failed": len(case_results) - case_passed,
            "pass_rate": round(case_passed / len(case_results), 4),
            "stable_pass": case_passed == len(case_results),
            "latency_mean_ms": round(statistics.fmean(latencies), 2),
            "latency_median_ms": round(statistics.median(latencies), 2),
            "estimated_output_tokens_total": sum(item["estimated_output_tokens"] for item in case_results),
        })

    total = len(results)
    passed = sum(1 for item in results if item["passed"])
    latencies = [item["latency_ms"] for item in results]
    return {
        "schema_version": 3,
        "cases": len(validated),
        "repetitions": repetitions,
        "executions": total,
        "passed": passed,
        "failed": total - passed,
        "pass_rate": round(passed / total, 4),
        "consistently_passing_cases": sum(1 for item in per_case if item["stable_pass"]),
        "latency_mean_ms": round(statistics.fmean(latencies), 2),
        "latency_median_ms": round(statistics.median(latencies), 2),
        "estimated_output_tokens_total": sum(item["estimated_output_tokens"] for item in results),
        "per_case": per_case,
        "results": results,
        "limitations": [
            "Acceptance criteria do not establish semantic correctness.",
            "Token estimates use characters divided by four and are not provider billing data.",
            "Repeated runs may consume additional local compute or API credits.",
        ],
    }
