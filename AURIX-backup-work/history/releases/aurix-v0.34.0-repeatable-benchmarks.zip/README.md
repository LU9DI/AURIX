# AURIX

**Open, local-first AI engineering agent.** AURIX is an open-source project to build an agent that can inspect software projects, plan changes, use tools safely, run tests, and learn from measured outcomes—with no paid API required by default.

> Status: v0.34.0 research release; REA CLI investigation commands are allowlisted; not production-ready autonomous software engineering.

## Principles
- **Local-first:** local inference first; remote providers are optional adapters.
- **Tool-grounded:** prefer deterministic tools over unnecessary model calls.
- **Safe by default:** narrow workspace boundaries, command allowlists, bounded execution.
- **Measured, not hyped:** optimize only when reproducible evaluations show improvement.
- **Open and modular:** providers, memory backends, and tools are replaceable.

## Quick start

Requires Python 3.11+.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env
pytest
python -m aurix.cli --doctor --workspace .
```

### Choose an inference engine

Ollama is **not required**. The default adapter speaks the OpenAI-compatible Chat Completions API, supported by local engines such as [LM Studio](https://lmstudio.ai/), [llama.cpp server](https://github.com/ggml-org/llama.cpp), and [vLLM](https://docs.vllm.ai/), as well as compatible hosted endpoints. Start one of those servers, then set `AURIX_BASE_URL` and `AURIX_MODEL` in `.env`.

```dotenv
AURIX_PROVIDER=openai-compatible
AURIX_BASE_URL=http://localhost:1234/v1
AURIX_MODEL=your-loaded-model-name
AURIX_API_KEY=
```

To use Ollama instead, set `AURIX_PROVIDER=ollama`, `AURIX_BASE_URL=http://localhost:11434`, and choose a model installed in Ollama. Provider selection lives behind one interface, so the core does not depend on any one inference vendor.

**Can we build our own model?** Yes, incrementally: first our own orchestration, evaluation, memory, retrieval, tool-use and inference runtime; later fine-tune an open-weight model on licensed data if benchmarks justify it. Training a competitive foundation model from scratch is a separate, expensive research effort—not something solved by changing the inference server.

Run `aurix --doctor --workspace .` for read-only environment checks. Add `--probe-provider` to send a live test prompt; this can consume compute or API credits. Probe output suppresses raw model responses and exception details.

The CLI has a bounded tool loop for file listing, reading, and literal text search. It can also save proposed unified diffs for review. In v0.4, a proposal can be applied or reversed only through a separate CLI operation with an explicit confirmation flag; v0.5 adds an explicitly approved, fixed-command test/lint runner with a timeout and reduced environment; v0.6 can verify a proposal in a disposable Git worktree without changing the primary checkout; application requires a clean tracked Git worktree and only supports in-place edits to existing tracked regular files. This is not a sandbox and is not production-ready for untrusted repositories.

### Project inventory and Git inspection (v0.25.0)

Current package version: **0.34.0**.

The agent can map project ecosystems, manifests, test-file locations, CI configuration, source-file counts, and package-script names before proposing a change. This inventory is structural only: it does not execute tests or scripts. Git status and diff inspection are also available in the bounded tool loop.

### REA reverse-engineering integration (v0.23.0)

AURIX can delegate static JavaScript/Electron application analysis to the upstream
[REA — Reverse Engineer Anything](https://github.com/morluto/rea) CLI. REA remains
a separate MIT-licensed tool; AURIX does not copy or fork its implementation.
Install Node.js and REA using the upstream instructions, then ensure `rea` is on
`PATH` (or set `AURIX_REA_BIN` to the executable).

When useful, the model can request the `rea_analyze_app` tool for a directory or
`.asar` file inside the configured AURIX workspace. It calls
`rea analyze-javascript-application TARGET --json`, passes a reduced environment,
uses no shell, caps execution at 120 seconds, and bounds returned output. The
static analysis does not launch the target application. Targets outside the
workspace and unsupported file types are rejected.

```bash
npm install --global rea-agents
rea --help
aurix --workspace . "Inspect the Electron application in ./desktop-app" --json
```

The `rea_analyze_app` adapter covers the static JavaScript/Electron workflow.
A separate, restricted MCP workflow for native binary overview is described
below; neither integration exposes the full REA catalog, browser runtime capture,
or process tracing. Those capabilities require additional explicit adapters and
upstream prerequisites. REA must be installed separately; AURIX does not silently
download it or run `npx` during a task.


### Optional Docker-isolated test execution (v0.33.0)

AURIX can run its fixed `pytest`/`ruff` commands inside an operator-selected Docker image, with network disabled, a read-only container root filesystem, dropped Linux capabilities, process/memory/CPU limits, and only the workspace mounted writable. It checks that the image is already local and uses `--pull=never`; it will not download an image or fall back to host execution. The image must already contain the project dependencies and test tools. The Docker daemon and image remain part of the trust boundary; this is defense-in-depth, not a claim of perfect isolation.

Example (image must be built/pulled by the operator first):

```bash
aurix --workspace . --run-tests pytest --confirm-run-tests \
  --test-isolation docker --sandbox-image aurix-test:local --json

aurix --workspace . --verify-proposal a1b2c3d4e5f6 --confirm-verify \
  --test-isolation docker --sandbox-image aurix-test:local --json
```

The default `trusted` mode is unchanged and is not an OS sandbox. This optional Docker backend was tested with mocked Docker CLI calls in this environment; a live Docker run was not possible here.

### Baseline-aware proposal verification (v0.32.0)

When an operator enables agent verification, AURIX can run the fixed test suite on the clean baseline and then on the proposed patch in a disposable Git worktree. The result distinguishes `clean`, `introduced_failure`, `improved`, `preexisting_failure_persists`, and `not_compared`. Baseline comparison is enabled by default and runs tests twice, so it costs more time. This is regression evidence, not proof of semantic correctness. Tests are not OS-sandboxed and must only run against trusted repositories.

### Iterative proposal verification (v0.31.0)

When agent verification is enabled, the model receives test results in its next context. A failed proposal is treated as immutable for that run: the orchestrator rejects attempts to verify the same failed proposal again, prompting the model to create a new diff. Verification outcomes and process exit codes are recorded in the trace when available. This is a bounded model-directed repair loop, not proof of semantic correctness; tests still run without OS-level sandboxing.

### Opt-in agent verification (v0.29.0)

When launched with `--allow-agent-verification`, the model is explicitly informed that it may call `verify_proposal` with a stored proposal ID and a fixed `pytest` or `ruff` suite. Without this flag, the tool is omitted from the model-facing tool instructions and rejected by the orchestrator. Verification runs in a disposable Git worktree, but it is not an OS sandbox and must only be enabled for trusted repositories.

### Direct REA MCP transport (v0.28.0)

AURIX can now use REA's stdio JSON-RPC MCP server for a restricted native-binary
investigation workflow. The `rea_mcp_investigate` tool launches the already
installed `rea mcp` executable (no `npx`, auto-download, or shell), initializes
the MCP connection, discovers the live tool catalog, then calls only
`open_binary` and `binary_overview`. The target must be a regular file inside
the configured workspace. The analyzed target is not launched by AURIX; native
analysis may launch or connect to a configured provider such as Ghidra or Hopper.
The MCP process is bounded by a timeout and stopped after the workflow. This is
a first narrow MCP integration, not unrestricted access to the full REA catalog.

REA remains an optional external dependency. Install and configure it separately,
then run AURIX against a trusted target. MCP behavior is covered with protocol
fixtures; this release does not claim a live Ghidra/Hopper integration test.

### Heuristic patch review (v0.8)

Before applying a proposal, run a deterministic scan over added diff lines:

```bash
aurix --workspace . --review-proposal a1b2c3d4e5f6 --json
```

The scanner flags selected patterns such as dynamic code execution, subprocess/shell use, unsafe deserialization, hard-coded credential-like strings, disabled TLS verification, broad file permissions, and possible SQL interpolation. It is a triage aid, not a security analyzer: it may produce false positives and miss vulnerabilities. Even a `low` result does not authorize or apply the patch; review and test it manually.

### Audit evidence integrity (v0.16)

Audit attachment is accepted only when the existing run report digest verifies and the referenced proposal SHA-256 matches the exact proposal file currently stored under `.aurix/proposals`. Audit metadata is validated before the report is changed; invalid booleans, risk levels, verification states, or finding counts are rejected. This binds the audit record to the current patch bytes, but SHA-256 alone is not a digital signature and does not authenticate the author.

```bash
aurix --workspace . --audit-proposal a1b2c3d4e5f6 \
  --attach-audit-to-report reports/run.json --json
```

The report must already exist and pass integrity verification. Use `--confirm-audit-verify` only when you explicitly authorize execution of repository tests.

## Persistent memory (v0.22.0)

SQLite is the zero-setup default. Memory is opt-in: AURIX does not automatically persist task prompts or model completions as memories. Add and search records explicitly, scoped by repository or project:

```bash
# Store a deliberately selected fact in a scope
 aurix --workspace . --memory-add "Auth tests require a seeded user" --memory-scope repo:my-project --memory-kind fact --memory-confidence 0.95 --json

# Search only that scope
 aurix --workspace . --memory-search "auth tests" --memory-scope repo:my-project --json
```

Set `AURIX_MEMORY_BACKEND=postgres`, `DATABASE_URL` to a Neon/PostgreSQL connection string, and install `pip install -e ".[neon]"` to use Neon. You can select `--memory-backend sqlite` or `--memory-backend postgres` per command. The default SQLite database is `<workspace>/.aurix/memory.db`; `AURIX_MEMORY_PATH` can override its path. Scope is a logical filter, not an authorization boundary: do not share one database between mutually untrusted users without adding access controls. Neon stores memory; it does not perform model inference.

To include relevant saved memories in a task prompt, explicitly enable contextual memory:

```bash
aurix --workspace . --memory-scope repo:my-project --use-memory-context \
  "Inspect the authentication flow" --json
```

Context retrieval is disabled by default. When enabled, AURIX retrieves only records in the selected scope, includes at most 10 bounded records, and labels them as untrusted evidence rather than instructions. The labels and confidence values are descriptive metadata and are not independently verified. Scope is a logical filter, not an authorization boundary.

## Development

```bash
pytest
ruff check .
```

See `docs/ARCHITECTURE.md`, `docs/SAFETY.md`, and `CONTRIBUTING.md`.

## Roadmap
1. Reproducible baseline and evaluation task format.
2. Provider-independent tracing and adapters for compatible local and hosted inference servers.
3. Bounded read-only tool loop for repository listing, file reads, and text search.
4. Reviewable patch proposals, explicitly confirmed application/reversal, and fixed-command test/lint execution with timeout. OS-level sandboxing remains future work.
5. Persistent memory and measured retrieval quality.
6. Multi-agent verification only if ablation benchmarks prove useful.
7. Public benchmarks for quality, latency, memory, and API/model cost.

## License
Apache-2.0, pending a final dependency and model-license audit before public release.

## Run a repeatable smoke benchmark

The benchmark runner supports explicit acceptance criteria: `must_contain`, `must_not_contain`, `expected_status`, `required_tools`, `forbidden_tools`, `min_steps`, and `max_steps`. Reports show per-criterion results, tool usage, latency, and rough output-token estimates. Use `--benchmark-repetitions 3` to run each case three times (valid range 1–10) and report aggregate pass rate, stable passes, mean/median latency, and total estimated output tokens. Repeated calls may incur extra compute/API cost. It is a regression aid, **not** a measure of semantic correctness or general reasoning quality; token estimates use characters/4 and must not be treated as tokenizer counts or provider billing. Existing smoke cases remain compatible.

```bash
aurix --benchmark benchmarks/smoke.json --json
```

By default, metadata-only run telemetry is appended to `.aurix/runs.jsonl`. Prompts and completions are not written to this file. Disable persistence by injecting a custom telemetry implementation in Python; telemetry path can be changed with `AURIX_TELEMETRY_PATH`.


### Reviewable patch proposals

AURIX can prepare a unified diff using the `propose_patch` tool. The diff is saved under `.aurix/proposals/` and marked for manual review; **the agent does not apply it automatically**. Inspect every proposal before applying it yourself. The proposal writer rejects absolute paths, parent-directory traversal, and symlinked metadata directories, but a proposal is still untrusted input and must be reviewed before use.

### Applying a reviewed patch proposal (v0.4)

Review the full diff first. The agent never applies it during reasoning. Only after review, use the proposal ID shown by AURIX:

```bash
aurix --workspace . --apply-proposal a1b2c3d4e5f6 --confirm-apply
# If the exact reverse patch still applies cleanly:
aurix --workspace . --revert-proposal a1b2c3d4e5f6 --confirm-revert
```

The operation requires Git, a clean tracked worktree for application, and an existing tracked file for every target. It refuses additions/deletions, renames, binary patches, unsafe paths, symlinks, sensitive filenames, and patches that fail Git's preflight. Reversal is a new patch operation, not a guaranteed restoration if other edits have changed the same lines. Back up important work and inspect `git diff` after every operation. This remains defense in depth, not a security sandbox.


### Explicitly approved test execution (v0.5)

Run a fixed test or lint command in a workspace you trust:

```bash
aurix --workspace . --run-tests pytest --confirm-run-tests --json
aurix --workspace . --run-tests ruff --confirm-run-tests --json
```

Only the fixed commands `python -m pytest -q` and `python -m ruff check .` are available; model-provided arguments are never executed. Runtime is capped at 120 seconds, output is bounded, and common credential/application environment variables are not passed to the child process. **This is not a sandbox:** test code may still read files, access the network, or perform other actions available to the OS user. Only run tests from repositories you trust. The command is never called automatically by the model.


### Verify a proposal before applying it (v0.6)

AURIX can apply a proposal to a temporary detached Git worktree, run a fixed test or lint suite there, and remove the temporary worktree afterward. The primary checkout remains unchanged. This is a useful preflight, but **not an OS-level sandbox**: test code can still access resources available to the OS user. Run only against trusted repositories and review the patch even when tests pass.

```bash
aurix --workspace . --verify-proposal a1b2c3d4e5f6 --confirm-verify --verify-suite pytest --json
# Or check lint instead of tests:
aurix --workspace . --verify-proposal a1b2c3d4e5f6 --confirm-verify --verify-suite ruff --json
```

Verification requires a clean tracked worktree and an existing proposal ID. A successful result means the selected suite passed in the temporary worktree; it does not establish correctness, security, or absence of regressions beyond that suite.


### Strict model response protocol (0.9.0)

AURIX now fails closed when a provider returns malformed JSON, a non-object JSON value, an unsupported status/tool, non-string message content, invalid tool arguments, or a response over 100,000 characters. Such responses are marked `invalid_response` and do not execute a tool. This reduces accidental or model-induced protocol ambiguity; it is not a security sandbox and does not establish the correctness of model output.


### Local run reports (v0.11.0)

Use `aurix "Inspect the authentication flow" --workspace . --report-run reports/auth-review.json` to explicitly save a JSON report under the workspace. The report includes the task text, status, run ID, and trace metadata, but not raw prompts, model completions, or tool-result bodies. Report paths must be relative to the workspace; traversal and symlink destinations are rejected. Do not use this option for tasks whose text should not be persisted.


### Proposal-linked run reports (v0.11.0)

Run reports use schema version 2 and include a metadata-only `artifacts.proposals` index for proposals created during the task. The trace stores proposal IDs and bounded status labels, not patch bodies or raw tool results. Reports remain opt-in via `--report-run PATH`; the task text is included in the report.


### Combined proposal audit (v0.12.0)

Run `aurix --audit-proposal PROPOSAL_ID --workspace . --json` to combine heuristic diff review with an explicit record that verification was not run. To also run the selected fixed test suite in a disposable Git worktree, add `--confirm-audit-verify`; choose `--verify-suite pytest` or `--verify-suite ruff`. Verification executes repository code and is not an OS sandbox. The combined audit never applies the patch and never treats high-risk findings as a passing audit, even if tests pass.


### Linking proposal audits to run reports (v0.15.0)

After a task has written a schema-v2 run report, attach a proposal audit to it:

```bash
aurix --audit-proposal PROPOSAL_ID --workspace . --attach-audit-to-report reports/auth-review.json --json
```

To also execute the configured fixed suite in a disposable Git worktree, add `--confirm-audit-verify`. The report attachment stores compact metadata including the SHA-256 digest of the reviewed patch, UTC audit time, risk level, finding count, verification status and suite. It intentionally excludes full findings and raw test output. The run report must already exist and must be schema version 2. Verification is not an OS sandbox, and audits never apply patches.


### Run report integrity (v0.15.0)

Reports written with `--report-run` include a canonical SHA-256 digest. Verify an existing report without modifying it:

```bash
aurix --workspace . --verify-run-report reports/auth-review.json --json
```

Verification reports `valid`, `tampered`, or `missing_integrity` (for older reports). This is a tamper-evident checksum, not a digital signature: someone who can rewrite the report and recompute its digest can forge it. Keep reports in a trusted workspace and use external signed storage if authenticity is required.


### Audit attachment integrity (v0.15.0)

Audit attachment now verifies the existing schema-v2 report digest before modifying it and refuses to silently recalculate integrity for tampered or legacy reports. Each successful new attachment preserves the prior digest in a compact `integrity_history` entry and reports the previous/current digests. Duplicate attachment of the same proposal digest and audit timestamp is idempotent. This is local tamper detection, not a signature or an externally anchored immutable log.



### Evidence-aware memory records (v0.20.0)

Memory records may include a validated `kind` (`fact`, `hypothesis`, `decision`, `test_result`, or `observation`) and optional numeric `confidence` from `0.0` to `1.0`. These labels preserve provenance/epistemic status; they do not independently verify a claim. Existing records and custom metadata remain compatible. Example:

```bash
aurix --workspace . --memory-add "Regression test passed on commit abc123" \
  --memory-kind test_result --memory-confidence 1.0 --memory-scope repo:my-project --json
```

Confidence is user-supplied metadata, not a calibrated model probability.

### Memory retrieval (v0.19.0)

Memory search ranks recent records in the selected scope by deterministic lexical overlap; it is not embedding-based semantic retrieval. Results are bounded by `--memory-limit`, `--memory-candidates`, and `--memory-max-content-chars`. Example:

```bash
aurix --workspace . --memory-search "authentication regression" \
  --memory-scope repo:my-project --memory-limit 5 --json
```

A memory scope is a logical filter, not an authorization boundary. Do not share a database across mutually untrusted users without a separate authorization layer.


### Hybrid memory retrieval (v0.20.0)

The Python API `retrieve_memories(..., embedder=adapter, lexical_weight=0.65)` can combine lexical overlap with an injected embedding adapter implementing `embed(text) -> sequence[float]`. No embedding provider or model is bundled or selected automatically; without an adapter, the CLI remains lexical-only and reports `semantic_search: false`. Embedding failures and vector dimension mismatches raise errors rather than silently falling back. Candidates are still bounded to recent records in the requested scope. `evaluate_retrieval` reports precision@k, recall@k and reciprocal rank against manually labeled record IDs; it is a measurement helper, not proof that semantic retrieval is better.


### Memory evidence traceability (v0.22.0)

When `--use-memory-context` is enabled, task JSON output includes `memory_context.evidence`: compact provenance for the records retrieved (ID, scope, kind, retrieval mode, relevance score, and matched terms). Explicit run reports also store this metadata, covered by the report integrity digest. Memory text is not copied into the provenance trace, and memory use remains opt-in.

### Opt-in agent-driven verification

By default, the model cannot trigger test execution. For a repository you trust, pass `--allow-agent-verification` to let the agent request verification of a stored patch proposal using the fixed `pytest` or `ruff` suite. Verification runs in a disposable Git worktree and returns structured results to the agent, enabling a test-feedback/revision loop without changing the primary checkout. This is **not an OS sandbox**: tests can access available filesystem and network resources. Do not enable it for untrusted repositories.


### REA investigation commands (v0.27.0)

In addition to static JavaScript/Electron analysis, the model may request `rea_investigate` for the allowlisted REA CLI commands `analyze`, `search`, `function`, `decompile`, `xrefs`, `trace`, `providers`, and `capabilities`. Target paths are workspace-relative and bounded output is returned as structured evidence when possible. No shell is used and analyzed targets are not launched. Native analysis requires REA and a compatible provider configured separately. The separate native investigation workflow now uses direct MCP stdio transport for a restricted `open_binary` → `binary_overview` sequence; it still does not expose unrestricted access to the full REA MCP catalog.
