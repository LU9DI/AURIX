import os
import subprocess
import sys

import pytest

from aurix.tools.execution import _safe_environment, run_test_suite


def test_execution_requires_confirmation(tmp_path):
    with pytest.raises(PermissionError, match="confirmation"):
        run_test_suite(tmp_path, "pytest")


def test_only_fixed_suites_are_accepted(tmp_path):
    with pytest.raises(ValueError, match="Unsupported"):
        run_test_suite(tmp_path, "shell; rm -rf /", confirm=True)


def test_timeout_is_bounded_and_workspace_must_exist(tmp_path):
    with pytest.raises(FileNotFoundError):
        run_test_suite(tmp_path / "missing", confirm=True)
    # Even a huge requested timeout is clamped; assert through a fake process.
    original = subprocess.run
    seen = {}
    def fake_run(*args, **kwargs):
        seen["timeout"] = kwargs["timeout"]
        return subprocess.CompletedProcess(args[0], 0, "ok", "")
    subprocess.run = fake_run
    try:
        result = run_test_suite(tmp_path, "pytest", confirm=True, timeout_seconds=999)
    finally:
        subprocess.run = original
    assert seen["timeout"] == 120
    assert result["passed"] is True


def test_runner_drops_secret_like_environment_variables(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "secret-value")
    monkeypatch.setenv("DATABASE_URL", "postgres://secret")
    env = _safe_environment()
    assert "OPENAI_API_KEY" not in env
    assert "DATABASE_URL" not in env
    assert env["PYTHONDONTWRITEBYTECODE"] == "1"


def test_runner_reports_nonzero_exit(tmp_path, monkeypatch):
    def fake_run(*args, **kwargs):
        return subprocess.CompletedProcess(args[0], 1, "failure", "trace")
    monkeypatch.setattr(subprocess, "run", fake_run)
    result = run_test_suite(tmp_path, "pytest", confirm=True)
    assert result["passed"] is False
    assert result["returncode"] == 1
    assert result["stderr"] == "trace"
