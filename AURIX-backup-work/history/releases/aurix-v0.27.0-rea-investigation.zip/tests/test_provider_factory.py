import pytest

from aurix.providers.factory import create_provider
from aurix.providers.ollama import OllamaProvider
from aurix.providers.openai_compatible import OpenAICompatibleProvider


def test_default_provider_is_openai_compatible(monkeypatch):
    monkeypatch.delenv("AURIX_PROVIDER", raising=False)
    monkeypatch.setenv("AURIX_BASE_URL", "http://localhost:1234/v1")
    provider = create_provider()
    assert isinstance(provider, OpenAICompatibleProvider)
    assert provider.base_url == "http://localhost:1234/v1"


def test_ollama_is_optional(monkeypatch):
    monkeypatch.setenv("AURIX_PROVIDER", "ollama")
    monkeypatch.setenv("AURIX_BASE_URL", "http://localhost:11434")
    assert isinstance(create_provider(), OllamaProvider)


def test_unknown_provider_fails_closed(monkeypatch):
    monkeypatch.setenv("AURIX_PROVIDER", "magic")
    with pytest.raises(ValueError, match="Unknown AURIX_PROVIDER"):
        create_provider()
