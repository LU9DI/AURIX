import json
import pytest
from aurix.evaluation.benchmark import load_cases, run_benchmark
from aurix.telemetry import JSONLTelemetry


class FakeProvider:
    def generate(self, prompt, *, system=""):
        return json.dumps({"status": "final", "message": "Run the test before changing code."})


def test_benchmark_checks_required_terms(tmp_path):
    cases = [{"id": "test-first", "task": "What first?", "must_contain": ["test", "code"]}]
    from aurix.orchestrator import Orchestrator
    report = run_benchmark(Orchestrator(FakeProvider(), telemetry=JSONLTelemetry(tmp_path / "trace.jsonl")), cases)
    assert report["cases"] == 1
    assert report["passed"] == 1
    assert report["pass_rate"] == 1.0


def test_benchmark_rejects_empty_file(tmp_path):
    path = tmp_path / "cases.json"
    path.write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError):
        load_cases(path)
