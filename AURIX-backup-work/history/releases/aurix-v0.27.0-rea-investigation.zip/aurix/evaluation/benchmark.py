from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from aurix.orchestrator import Orchestrator
from aurix.telemetry import estimate_tokens


def load_cases(path: str | Path) -> list[dict[str, Any]]:
    """Load JSON array of cases; fail closed on malformed or underspecified data."""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, list) or not payload:
        raise ValueError("Benchmark must be a non-empty JSON array")
    for index, case in enumerate(payload):
        if not isinstance(case, dict) or not isinstance(case.get("task"), str) or not case["task"].strip():
            raise ValueError(f"Benchmark case {index} requires a non-empty task")
        expected = case.get("must_contain", [])
        if not isinstance(expected, list) or not all(isinstance(item, str) for item in expected):
            raise ValueError(f"Benchmark case {index}: must_contain must be a list of strings")
    return payload


def run_benchmark(orchestrator: Orchestrator, cases: list[dict[str, Any]]) -> dict[str, Any]:
    results = []
    for case in cases:
        start = time.perf_counter()
        result = orchestrator.run(case["task"], case.get("context", ""))
        elapsed_ms = round((time.perf_counter() - start) * 1000, 2)
        normalized = result.message.casefold()
        missing = [needle for needle in case.get("must_contain", []) if needle.casefold() not in normalized]
        results.append({
            "id": case.get("id", f"case-{len(results) + 1}"),
            "passed": not missing,
            "missing": missing,
            "status": result.status,
            "latency_ms": elapsed_ms,
            "estimated_output_tokens": estimate_tokens(result.message),
        })
    total = len(results)
    passed = sum(item["passed"] for item in results)
    return {
        "schema_version": 1,
        "cases": total,
        "passed": passed,
        "failed": total - passed,
        "pass_rate": round(passed / total, 4) if total else 0.0,
        "results": results,
    }
