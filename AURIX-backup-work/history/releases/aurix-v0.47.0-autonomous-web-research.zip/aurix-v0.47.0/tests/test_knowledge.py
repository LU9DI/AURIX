from pathlib import Path

import pytest

from aurix.knowledge import KnowledgeIndex


def test_index_and_search_without_provider(tmp_path: Path):
    project = tmp_path / "docs"
    project.mkdir()
    (project / "python.md").write_text("Python testing uses pytest fixtures and assertions.\n", encoding="utf-8")
    (project / "database.md").write_text("SQLite stores local records and structured knowledge.\n", encoding="utf-8")
    index = KnowledgeIndex(tmp_path / ".aurix" / "knowledge.db")
    result = index.index_path(project)
    assert result["indexed_files"] == 2
    found = index.search("pytest testing fixtures")
    assert found
    assert found[0]["source"].endswith("python.md")
    assert index.stats() == {"files": 2, "chunks": 2}


def test_reject_empty_query(tmp_path: Path):
    index = KnowledgeIndex(tmp_path / "knowledge.db")
    with pytest.raises(ValueError):
        index.search("   ")


def test_skips_hidden_aurix_and_git_dirs(tmp_path: Path):
    root = tmp_path / "repo"
    (root / ".git").mkdir(parents=True)
    (root / ".aurix").mkdir()
    (root / "src").mkdir()
    (root / ".git" / "secret.md").write_text("needle secret", encoding="utf-8")
    (root / ".aurix" / "internal.md").write_text("needle internal", encoding="utf-8")
    (root / "src" / "code.py").write_text("needle implementation", encoding="utf-8")
    index = KnowledgeIndex(tmp_path / "db.sqlite")
    index.index_path(root)
    found = index.search("needle")
    assert len(found) == 1
    assert found[0]["source"].endswith("code.py")
