import pytest
from aurix.memory.sqlite import SQLiteMemory


def test_memory_add_and_search(tmp_path):
    memory = SQLiteMemory(tmp_path / "memory.db")
    record_id = memory.add("repo:demo", "Fix the flaky authentication test", {"source": "test"})
    results = memory.search("authentication", scope="repo:demo")
    assert results[0]["id"] == record_id
    assert results[0]["metadata"]["source"] == "test"


def test_memory_rejects_empty_values(tmp_path):
    memory = SQLiteMemory(tmp_path / "memory.db")
    with pytest.raises(ValueError):
        memory.add("", "content")


def test_retrieval_ranks_relevant_records_above_recent_irrelevant(tmp_path):
    from aurix.memory.retrieval import retrieve_memories

    memory = SQLiteMemory(tmp_path / "memory.db")
    memory.add("repo:demo", "authentication bug fixed by refreshing JWT")
    memory.add("repo:demo", "unrelated documentation cleanup")
    memory.add("repo:demo", "authentication regression in token refresh")
    results = retrieve_memories(memory, "authentication regression", scope="repo:demo")
    assert len(results) == 2
    assert results[0]["content"] == "authentication regression in token refresh"
    assert results[0]["relevance_score"] > results[1]["relevance_score"]
    assert results[0]["matched_terms"] == ["authentication", "regression"]


def test_retrieval_is_scope_filtered_and_bounded(tmp_path):
    from aurix.memory.retrieval import retrieve_memories

    memory = SQLiteMemory(tmp_path / "memory.db")
    memory.add("repo:one", "authentication " + "detail " * 300)
    memory.add("repo:two", "authentication in another repository")
    results = retrieve_memories(memory, "authentication", scope="repo:one", limit=1,
                               max_content_chars=100)
    assert len(results) == 1
    assert results[0]["scope"] == "repo:one"
    assert len(results[0]["content"]) == 100
    assert results[0]["content_truncated"] is True


def test_retrieval_rejects_query_without_tokens(tmp_path):
    from aurix.memory.retrieval import retrieve_memories

    memory = SQLiteMemory(tmp_path / "memory.db")
    with pytest.raises(ValueError, match="at least one token"):
        retrieve_memories(memory, "!!!", scope="repo:demo")
