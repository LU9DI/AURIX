import json
import subprocess
import hashlib

import pytest

from aurix.tools.patches import apply_proposal, revert_proposal, inspect_transactions, plan_transaction_recovery, finalize_interrupted_recovery


def make_repo(tmp_path):
    root = tmp_path / "repo"
    root.mkdir()
    subprocess.run(["git", "init", str(root)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(root), "config", "user.email", "aurix-test@example.invalid"], check=True)
    subprocess.run(["git", "-C", str(root), "config", "user.name", "AURIX tests"], check=True)
    (root / "app.py").write_text("value = 'old'\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "app.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "initial"], check=True, capture_output=True)
    proposal_dir = root / ".aurix" / "proposals"
    proposal_dir.mkdir(parents=True)
    proposal_id = "a1b2c3d4e5f6"
    patch = "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-value = 'old'\n+value = 'new'\n"
    (proposal_dir / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    return root, proposal_id


def test_apply_requires_explicit_confirmation(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    with pytest.raises(PermissionError, match="confirmation"):
        apply_proposal(root, proposal_id)
    assert "old" in (root / "app.py").read_text(encoding="utf-8")


def test_apply_and_revert_reviewed_proposal(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    result = apply_proposal(root, proposal_id, confirm=True)
    assert result["status"] == "applied"
    assert "new" in (root / "app.py").read_text(encoding="utf-8")
    reverted = revert_proposal(root, proposal_id, confirm=True)
    assert reverted["status"] == "reverted"
    assert "old" in (root / "app.py").read_text(encoding="utf-8")


def test_apply_refuses_dirty_tracked_worktree(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    (root / "app.py").write_text("user edit\n", encoding="utf-8")
    with pytest.raises(PermissionError, match="tracked changes"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_untracked_target(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = "--- a/new.py\n+++ b/new.py\n@@ -1 +1 @@\n-old\n+new\n"
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="existing regular files"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_path_traversal(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = "--- a/../outside.py\n+++ b/../outside.py\n@@ -1 +1 @@\n-old\n+new\n"
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="Unsafe path"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_refuses_git_metadata_headers(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    patch = ("diff --git a/app.py b/app.py\nindex 1234567..89abcde 100644\n"
             "--- a/app.py\n+++ b/app.py\n@@ -1 +1 @@\n-value = 'old'\n+value = 'new'\n")
    (root / ".aurix" / "proposals" / f"{proposal_id}.diff").write_text(patch, encoding="utf-8")
    with pytest.raises(PermissionError, match="plain unified diffs"):
        apply_proposal(root, proposal_id, confirm=True)


def test_apply_with_audit_gate_rejects_missing_evidence(tmp_path):
    import pytest
    from aurix.tools.patches import apply_proposal

    root, proposal_id = make_repo(tmp_path)
    with pytest.raises(PermissionError, match="passing audit record"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def _write_passing_audit(root, proposal_id):
    import hashlib
    import json
    import subprocess

    proposal = root / ".aurix" / "proposals" / f"{proposal_id}.diff"
    patch_digest = hashlib.sha256(proposal.read_bytes()).hexdigest()
    base_commit = subprocess.run(
        ["git", "-C", str(root), "rev-parse", "HEAD"], check=True,
        capture_output=True, text=True,
    ).stdout.strip()
    verification = {
        "audit_id": "a" * 32,
        "verification_id": "b" * 32,
        "proposal_id": proposal_id,
        "proposal_sha256": patch_digest,
        "base_commit": base_commit,
        "target_state_sha256": hashlib.sha256(json.dumps([{"path": "app.py", "sha256": hashlib.sha256((root / "app.py").read_bytes()).hexdigest()}], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest(),
        "suite": "pytest",
        "requested_suite": "pytest",
        "test_selection": {"mode": "full_suite", "reason": "test fixture", "paths": []},
        "isolation": "trusted",
        "sandbox_image": None,
        "sandbox_image_id": None,
        "runtime_fingerprint": {"python_version": "3.test", "python_implementation": "CPython", "system": "TestOS", "release": "1", "machine": "test"},
        "baseline_result": {"passed": True, "returncode": 0},
        "test_result": {"passed": True, "returncode": 0},
        "regression_status": "clean",
    }
    verification["evidence_sha256"] = hashlib.sha256(json.dumps(
        verification, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
    ).encode("utf-8")).hexdigest()
    target_state = [{"path": "app.py", "sha256": hashlib.sha256((root / "app.py").read_bytes()).hexdigest()}]
    target_state_sha256 = hashlib.sha256(json.dumps(target_state, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()
    verification["target_state_sha256"] = target_state_sha256
    verification["evidence_sha256"] = hashlib.sha256(json.dumps(
        {key: value for key, value in verification.items() if key != "evidence_sha256"},
        sort_keys=True, separators=(",", ":"), ensure_ascii=False,
    ).encode("utf-8")).hexdigest()
    record = {
        "schema_version": 9,
        "audit_id": "a" * 32,
        "target_state": target_state,
        "target_state_sha256": target_state_sha256,
        "proposal_id": proposal_id,
        "proposal_sha256": patch_digest,
        "base_commit": base_commit,
        "status": "audit_passed",
        "review": {"risk_level": "low"},
        "review_tracks": {
            "security": {"proposal_sha256": patch_digest, "risk_level": "low",
                         "evidence_schema": 1, "findings": [],
                         "integrity": {"sha256": patch_digest}},
            "correctness": {"proposal_sha256": patch_digest, "risk_level": "low",
                            "evidence_schema": 1, "findings": []},
        },
        "verification": {**verification, "status": "verified_pass"},
    }
    audit_dir = root / ".aurix" / "audits"
    audit_dir.mkdir(parents=True, exist_ok=True)
    (audit_dir / f"{proposal_id}.json").write_text(json.dumps(record), encoding="utf-8")


def test_audit_gate_accepts_evidence_bound_to_current_head(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    result = apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)
    assert result["status"] == "applied"


def test_audit_gate_rejects_evidence_for_previous_head(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    (root / "app.py").write_text("value = 'another commit'\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "app.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "advance head"], check=True, capture_output=True)
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def test_audit_gate_rejects_tampered_verification_evidence(tmp_path):
    import json

    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    path = root / ".aurix" / "audits" / f"{proposal_id}.json"
    audit = json.loads(path.read_text(encoding="utf-8"))
    audit["verification"]["test_result"]["passed"] = False
    path.write_text(json.dumps(audit), encoding="utf-8")
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def test_apply_rolls_back_when_audit_logging_fails(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)

    def fail_audit(*args, **kwargs):
        raise OSError("simulated audit storage failure")

    monkeypatch.setattr(patches, "append_audit_event", fail_audit)
    with pytest.raises(RuntimeError, match="rolled back"):
        apply_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"
    status = subprocess.run(
        ["git", "-C", str(root), "status", "--porcelain", "--untracked-files=no"],
        check=True, capture_output=True, text=True,
    ).stdout
    assert status == ""


def test_apply_reports_transaction_state(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    result = apply_proposal(root, proposal_id, confirm=True)
    assert result["transaction"] == "applied_and_audited"


def test_apply_rollback_verifies_final_tracked_status(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)
    original_append = patches.append_audit_event

    def fail_audit(*args, **kwargs):
        raise OSError("simulated audit failure")

    monkeypatch.setattr(patches, "append_audit_event", fail_audit)
    with pytest.raises(RuntimeError, match="rolled back"):
        apply_proposal(root, proposal_id, confirm=True)
    assert patches._tracked_status(root) == ""
    monkeypatch.setattr(patches, "append_audit_event", original_append)


def test_revert_reports_verified_transaction(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    result = revert_proposal(root, proposal_id, confirm=True)
    assert result["transaction"] == "reverted_and_audited"
    assert result["recovery_status"] == "verified"
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"


def test_revert_restores_patch_if_audit_logging_fails(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)

    def fail_audit(*args, **kwargs):
        raise OSError("simulated audit failure")

    monkeypatch.setattr(patches, "append_audit_event", fail_audit)
    with pytest.raises(RuntimeError, match="original patch was restored"):
        revert_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'new'\n"
    assert patches._tracked_status(root) == "M app.py"


def test_patch_operation_refuses_existing_workspace_lock(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    lock = root / ".aurix" / "operation.lock"
    lock.write_text('{"pid": 999999, "created_at": 0}', encoding="utf-8")
    with pytest.raises(PermissionError, match="workspace lock"):
        apply_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"


def test_apply_detects_head_change_during_preflight(tmp_path, monkeypatch):
    import aurix.tools.patches as patches

    root, proposal_id = make_repo(tmp_path)
    (root / "other.py").write_text("value = 1\n", encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "add", "other.py"], check=True)
    subprocess.run(["git", "-C", str(root), "commit", "-m", "add unrelated file"], check=True, capture_output=True)
    original_git = patches._git
    changed = False

    def race_git(workspace, args, *, patch=None):
        nonlocal changed
        result = original_git(workspace, args, patch=patch)
        if args[:2] == ["apply", "--check"] and not changed:
            changed = True
            (root / "other.py").write_text("value = 2\n", encoding="utf-8")
            subprocess.run(["git", "-C", str(root), "add", "other.py"], check=True)
            subprocess.run(["git", "-C", str(root), "commit", "-m", "concurrent commit"], check=True, capture_output=True)
        return result

    monkeypatch.setattr(patches, "_git", race_git)
    with pytest.raises(PermissionError, match="HEAD changed during preflight"):
        apply_proposal(root, proposal_id, confirm=True)
    assert "new" not in (root / "app.py").read_text(encoding="utf-8")
    assert patches._git_head(root) != ""


def test_audit_gate_rejects_finding_with_mismatched_line_evidence(tmp_path):
    import json
    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    path = root / ".aurix" / "audits" / f"{proposal_id}.json"
    audit = json.loads(path.read_text(encoding="utf-8"))
    patch = (root / ".aurix" / "proposals" / f"{proposal_id}.diff").read_bytes()
    digest = hashlib.sha256(patch).hexdigest()
    audit["review_tracks"]["security"]["findings"] = [{
        "file": "app.py", "patch_line": 4, "evidence": {
            "file": "app.py", "patch_line": 4, "patch_sha256": digest,
            "line_sha256": "0" * 64, "source_line": 1, "hunk": "@@ -1 +1 @@",
        }
    }]
    path.write_text(json.dumps(audit), encoding="utf-8")
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def test_audit_gate_rejects_cross_cycle_verification(tmp_path):
    import json

    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    path = root / ".aurix" / "audits" / f"{proposal_id}.json"
    audit = json.loads(path.read_text(encoding="utf-8"))
    audit["verification"]["audit_id"] = "c" * 32
    # Recompute the ordinary evidence digest to prove cycle identity is an independent gate.
    evidence = {key: audit["verification"].get(key) for key in (
        "audit_id", "verification_id", "proposal_id", "proposal_sha256", "base_commit", "target_state_sha256",
        "suite", "requested_suite", "test_selection", "isolation", "sandbox_image",
        "sandbox_image_id", "runtime_fingerprint", "baseline_result", "test_result",
        "regression_status",
    )}
    audit["verification"]["evidence_sha256"] = hashlib.sha256(__import__("json").dumps(
        evidence, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
    ).encode("utf-8")).hexdigest()
    path.write_text(json.dumps(audit), encoding="utf-8")
    with pytest.raises(PermissionError, match="exact patch"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)


def test_audit_gate_rejects_target_file_changed_after_audit(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    _write_passing_audit(root, proposal_id)
    (root / "app.py").write_text("value = 'externally changed'\n", encoding="utf-8")
    with pytest.raises(PermissionError, match="changed since audit"):
        apply_proposal(root, proposal_id, confirm=True, require_audit_gate=True)
    assert "externally changed" in (root / "app.py").read_text(encoding="utf-8")


def test_apply_persists_durable_transaction_journal(tmp_path):
    import json

    root, proposal_id = make_repo(tmp_path)
    result = apply_proposal(root, proposal_id, confirm=True)
    journal_path = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    journal = json.loads(journal_path.read_text(encoding="utf-8"))
    assert result["journal"] == f".aurix/transactions/{proposal_id}.json"
    assert journal["state"] == "applied_and_audited"
    assert journal["patch_sha256"] == hashlib.sha256(
        (root / ".aurix" / "proposals" / f"{proposal_id}.diff").read_bytes()
    ).hexdigest()
    assert journal["recovery"] == "verified"


def test_incomplete_transaction_journal_blocks_retry(tmp_path):
    import json

    root, proposal_id = make_repo(tmp_path)
    journal_dir = root / ".aurix" / "transactions"
    journal_dir.mkdir()
    (journal_dir / f"{proposal_id}.json").write_text(json.dumps({
        "schema_version": 1, "proposal_id": proposal_id,
        "state": "patch_applied", "recovery": "pending_verification",
    }), encoding="utf-8")
    with pytest.raises(PermissionError, match="incomplete transaction journal"):
        apply_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"


def test_malformed_transaction_journal_fails_closed(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    journal_dir = root / ".aurix" / "transactions"
    journal_dir.mkdir()
    (journal_dir / f"{proposal_id}.json").write_text("{broken", encoding="utf-8")
    with pytest.raises(PermissionError, match="journal is unreadable"):
        apply_proposal(root, proposal_id, confirm=True)
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"


def test_inspect_transactions_is_read_only_and_reports_clean_workspace(tmp_path):
    root, _ = make_repo(tmp_path)
    before = (root / "app.py").read_bytes()
    report = inspect_transactions(root)
    assert report["status"] == "clean"
    assert report["count"] == 0
    assert report["read_only"] is True
    assert (root / "app.py").read_bytes() == before


def test_inspect_transactions_confirms_applied_patch_without_mutating(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    journal = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    before_journal = journal.read_bytes()
    before_target = (root / "app.py").read_bytes()
    report = inspect_transactions(root)
    assert report["status"] == "inspected"
    assert report["transactions"][0]["status"] == "consistent_terminal_record"
    assert journal.read_bytes() == before_journal
    assert (root / "app.py").read_bytes() == before_target


def test_inspect_transactions_flags_external_edit_to_applied_patch(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    (root / "app.py").write_text("value = 'external'\n", encoding="utf-8")
    report = inspect_transactions(root)
    assert report["status"] == "manual_intervention_required"
    assert report["transactions"][0]["status"] == "manual_intervention_required"


def test_recovery_plan_proposes_rollback_without_mutating_workspace(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    journal = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    record = json.loads(journal.read_text(encoding="utf-8"))
    record.update(state="patch_applied", recovery="pending_verification")
    journal.write_text(json.dumps(record), encoding="utf-8")
    before_target = (root / "app.py").read_bytes()
    before_journal = journal.read_bytes()

    report = plan_transaction_recovery(root)

    assert report["read_only"] is True
    assert report["execution_performed"] is False
    assert report["plans"][0]["action"] == "propose_exact_patch_rollback"
    assert report["plans"][0]["safe_to_automate"] is False
    assert all(item["passed"] for item in report["plans"][0]["preconditions"])
    assert (root / "app.py").read_bytes() == before_target
    assert journal.read_bytes() == before_journal


def test_recovery_plan_requires_manual_review_after_external_edit(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    journal = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    record = json.loads(journal.read_text(encoding="utf-8"))
    record.update(state="patch_applied", recovery="pending_verification")
    journal.write_text(json.dumps(record), encoding="utf-8")
    (root / "app.py").write_text("value = 'external edit'\n", encoding="utf-8")

    report = plan_transaction_recovery(root)

    assert report["plans"][0]["action"] == "manual_review"
    assert report["plans"][0]["safe_to_automate"] is False
    assert report["plans"][0]["mutates_workspace"] is False


def test_explicit_transaction_recovery_rolls_back_exact_patch_and_records_history(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    journal_path = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    record = json.loads(journal_path.read_text(encoding="utf-8"))
    record.update(state="patch_applied", recovery="pending_verification")
    journal_path.write_text(json.dumps(record), encoding="utf-8")

    from aurix.tools.patches import recover_transaction
    result = recover_transaction(root, proposal_id, confirm=True)

    assert result["status"] == "recovered"
    assert result["transaction"] == "rolled_back"
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"
    final = json.loads(journal_path.read_text(encoding="utf-8"))
    assert final["state"] == "rolled_back"
    assert final["recovery_history"][-1]["result"] == "verified"


def test_explicit_transaction_recovery_refuses_external_edit(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    journal_path = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    record = json.loads(journal_path.read_text(encoding="utf-8"))
    record.update(state="patch_applied", recovery="pending_verification")
    journal_path.write_text(json.dumps(record), encoding="utf-8")
    (root / "app.py").write_text("value = 'external edit'\n", encoding="utf-8")

    from aurix.tools.patches import recover_transaction
    with pytest.raises(PermissionError, match="Exact inverse patch no longer applies|Tracked diff differs"):
        recover_transaction(root, proposal_id, confirm=True)
    assert "external edit" in (root / "app.py").read_text(encoding="utf-8")


def test_explicit_transaction_recovery_requires_confirmation(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    from aurix.tools.patches import recover_transaction
    with pytest.raises(PermissionError, match="Explicit confirmation"):
        recover_transaction(root, proposal_id, confirm=False)


def test_inspection_reconciles_interrupted_recovery_without_mutating_journal(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    from aurix.tools.patches import apply_proposal
    apply_proposal(root, proposal_id, confirm=True)
    journal_path = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    journal = json.loads(journal_path.read_text(encoding="utf-8"))
    journal.update(state="recovery_in_progress", recovery="pending_verification")
    journal_path.write_text(json.dumps(journal), encoding="utf-8")
    before = journal_path.read_bytes()

    report = inspect_transactions(root)

    row = report["transactions"][0]
    assert row["status"] == "manual_intervention_required"
    assert row["observed_state"] == "patch_still_applied_exactly"
    assert row["suggested_action"] == "review transaction and rerun explicit recovery after fresh preflight"
    assert journal_path.read_bytes() == before
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'new'\n"


def test_inspection_detects_rollback_done_but_journal_unfinalized(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    from aurix.tools.patches import apply_proposal
    apply_proposal(root, proposal_id, confirm=True)
    journal_path = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    journal = json.loads(journal_path.read_text(encoding="utf-8"))
    journal.update(state="recovery_interrupted", recovery="manual_intervention_required")
    # Simulate crash after exact reverse patch but before journal finalization.
    subprocess.run(["git", "-C", str(root), "apply", "--reverse", "--whitespace=error", "-"],
                   input=(root / ".aurix" / "proposals" / f"{proposal_id}.diff").read_text(encoding="utf-8"),
                   text=True, capture_output=True, check=True)
    journal_path.write_text(json.dumps(journal), encoding="utf-8")
    before = journal_path.read_bytes()

    report = inspect_transactions(root)

    row = report["transactions"][0]
    assert row["observed_state"] == "rollback_effectively_completed_journal_unfinalized"
    assert row["status"] == "manual_intervention_required"
    assert journal_path.read_bytes() == before
    assert (root / "app.py").read_text(encoding="utf-8") == "value = 'old'\n"


def test_finalize_interrupted_recovery_only_updates_journal_after_verified_baseline(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    journal_path = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    journal = json.loads(journal_path.read_text(encoding="utf-8"))
    journal.update(state="recovery_interrupted", recovery="manual_intervention_required")
    journal_path.write_text(json.dumps(journal), encoding="utf-8")
    subprocess.run(["git", "-C", str(root), "apply", "--reverse", "--whitespace=error", "-"],
                   input=(root / ".aurix" / "proposals" / f"{proposal_id}.diff").read_text(encoding="utf-8"),
                   text=True, capture_output=True, check=True)
    before_source = (root / "app.py").read_bytes()

    with pytest.raises(PermissionError, match="Explicit confirmation"):
        finalize_interrupted_recovery(root, proposal_id, confirm=False)
    result = finalize_interrupted_recovery(root, proposal_id, confirm=True)

    assert result["status"] == "finalized"
    assert (root / "app.py").read_bytes() == before_source
    final = json.loads(journal_path.read_text(encoding="utf-8"))
    assert final["state"] == "rolled_back"
    assert final["recovery_history"][-1]["result"] == "baseline_verified"


def test_finalize_interrupted_recovery_refuses_dirty_worktree(tmp_path):
    root, proposal_id = make_repo(tmp_path)
    apply_proposal(root, proposal_id, confirm=True)
    journal_path = root / ".aurix" / "transactions" / f"{proposal_id}.json"
    journal = json.loads(journal_path.read_text(encoding="utf-8"))
    journal.update(state="recovery_interrupted", recovery="manual_intervention_required")
    journal_path.write_text(json.dumps(journal), encoding="utf-8")
    (root / "app.py").write_text("value = 'external edit'\n", encoding="utf-8")

    with pytest.raises(PermissionError, match="not clean"):
        finalize_interrupted_recovery(root, proposal_id, confirm=True)
    assert json.loads(journal_path.read_text(encoding="utf-8"))["state"] == "recovery_interrupted"
    assert "external edit" in (root / "app.py").read_text(encoding="utf-8")
