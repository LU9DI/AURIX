# Changelog

## 0.4.0 — Explicit patch application and reversal

- Added separate CLI commands to apply or reverse a stored proposal only after an explicit confirmation flag.
- Require the workspace to be the Git repository root and the tracked worktree to be clean before applying a patch.
- Restrict patches to in-place modifications of existing tracked regular files.
- Reject binary/metadata diffs, renames, copies, additions/deletions, unsafe paths, symlinks, and sensitive filenames.
- Run `git apply --check` before application and reverse-check before attempting a reversal.
- Added focused tests and updated safety documentation.

This is not a sandbox and does not establish that a patch is semantically correct. Review every diff and inspect the worktree after applying or reverting.


## 0.5.0 — Explicitly approved test runner

- Added a fixed-command test runner for `pytest` and `ruff`; no model-controlled command arguments.
- Required explicit confirmation, bounded runtime/output, and passed a reduced environment to subprocesses.
- Added tests for confirmation, command allowlisting, timeout bounds, secret-like environment removal, and failed test outcomes.
- Clarified that process-level limits do not provide OS sandboxing; trusted repositories only.


## 0.6.0
- Added explicit proposal verification in a disposable detached Git worktree.
- Added CLI options `--verify-proposal`, `--confirm-verify`, and `--verify-suite`.
- Added integration tests proving pass/fail reporting and preservation of the primary checkout.
- Clarified that a disposable worktree is not an operating-system sandbox.

## 0.7.0 — Installation diagnostics and explicit provider probe

- Added `aurix --doctor` for read-only readiness checks across Python, workspace, Git, core dependencies, optional test/lint tools, provider configuration, and optional Neon configuration.
- Added opt-in `--probe-provider` for a real model request; this can consume local compute or hosted API credits.
- Provider probe output suppresses raw responses and exception details to avoid leaking secrets.
- Added tests for read-only behavior and safe provider-probe reporting.


## 0.8.0 — 2026-10-08

- Added deterministic heuristic review for patch proposals, focused on newly added lines.
- Added findings for dynamic execution, shell/subprocess use, unsafe deserialization, credential-like literals, TLS verification disabled, broad file permissions, and likely SQL interpolation.
- Added CLI command `--review-proposal ID` with JSON output.
- Review results never authorize application; human review remains required.
- Added tests for high-risk findings, low-risk results, removed-line exclusion, and missing proposals.


## 0.9.0 — Strict model protocol

- Reject malformed JSON and non-object responses instead of treating arbitrary model text as a successful final answer.
- Validate response status, message type, tool allowlist, and tool argument shape before dispatch.
- Enforce a 100,000-character provider-response ceiling and record bounded protocol-error labels in traces.
- Added regression tests confirming malformed or unauthorized responses cannot execute tools.


## 0.11.0 — Proposal-linked audit reports

- Capture bounded tool status and valid proposal identifiers in the execution trace without storing tool-result bodies.
- Upgrade run reports to schema version 2 and link proposals as metadata-only artifacts.
- Ignore malformed proposal identifiers when producing report artifact indexes.
- Add regression coverage for proposal linkage and exclusion of patch contents from reports.


## 0.12.0 — Combined proposal audit

- Added `--audit-proposal` to combine heuristic diff review and verification status in one structured result.
- Kept test execution opt-in behind `--confirm-audit-verify`; no tests run from an audit without explicit confirmation.
- Reports `audit_passed` only when heuristic risk is low and the selected verification suite passes. High-risk findings remain `audit_needs_attention`.
- Explicitly records that audit never applies a patch and that disposable worktree verification is not an OS sandbox.
- Added regression tests for confirmation gating and risk-aware result classification.


## 0.13.0 — Proposal-linked audit evidence

- Added SHA-256 identity and UTC audit timestamp to proposal audit results.
- Added `--attach-audit-to-report` to link compact audit outcomes to an existing schema-v2 run report.
- Audit attachments retain proposal digest, risk level, finding count, verification status/suite, and whether a patch was applied; raw test output and full findings are excluded.
- Added checks for report schema, size, workspace-relative paths, and symlinks, plus atomic replacement and regression tests.
- Attachment requires an existing run report; it does not fabricate a run record for an audit-only command.


## 0.14.0 — Run report integrity

- Add canonical SHA-256 integrity digests to newly written run reports and refresh the digest when compact audit evidence is attached.
- Add read-only `--verify-run-report PATH` verification that distinguishes valid, tampered, and legacy reports without an integrity digest.
- Enforce schema-v2, workspace-relative paths, symlink refusal, and a 2 MB report size ceiling during verification.
- Add regression tests for tampering detection, digest refresh after audit attachment, and legacy reports without integrity metadata.
- Clarify that a local digest detects accidental or post-write changes but is not a digital signature and cannot authenticate a report against an attacker able to rewrite both content and digest.


## 0.15.0 — Guarded audit history

- Verify the existing report digest before attaching audit evidence; tampered and legacy reports are refused instead of silently rehashed.
- Preserve the prior digest and timestamp in a compact integrity history when a new audit is attached.
- Make duplicate audit attachment idempotent and return previous/current report digests.
- Validate audit result identity, SHA-256 shape, and nested metadata before mutation.
- Add regression tests for tampering refusal, digest history, and malformed metadata.

Integrity history remains inside the local report and is not cryptographically authenticated against an attacker who can rewrite the entire file.
