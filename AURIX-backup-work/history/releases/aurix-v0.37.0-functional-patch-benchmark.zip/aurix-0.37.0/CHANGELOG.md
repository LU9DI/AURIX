## 0.37.0 — Functional patch benchmark

- Added an opt-in functional benchmark that runs a fixture's baseline tests, applies an operator-supplied patch only to a disposable copy, then reruns the same fixed pytest suite.
- Reports whether the baseline and candidate match expected outcomes and separately counts demonstrated fixes (baseline fails, patched candidate passes).
- Requires explicit `--confirm-functional-benchmark`; supports the existing trusted or Docker test runner, never falls back from Docker, and does not modify fixture sources.
- Restricts fixture/patch paths to the suite directory, rejects symlinks, bounds case/patch sizes, checks patch paths, and only accepts edits to existing regular files.
- Added a small known-defect fixture and tests for the real baseline-fail/candidate-pass path.
- Limitations: evaluates supplied patches rather than generating them; trusted mode is not an OS sandbox; test success is bounded by test coverage.

## 0.36.0 — Evidence-aware benchmark criteria

- Benchmark cases can require patch proposal creation, successful proposal verification, and specified regression statuses observed in tool traces.
- Reports include explicit pass/fail checks and evidence fields for these criteria.
- Bumped benchmark report schema to v5 to distinguish the new evaluation contract.
- These criteria measure recorded workflow evidence, not semantic correctness by themselves.

## 0.35.0 — Reproducible benchmark comparison

- Benchmark reports now include a UTC creation timestamp, AURIX/Python versions, provider class, and SHA-256 fingerprint of the normalized suite.
- Added `compare_reports` to compare pass rate, per-case stability, mean latency, and estimated output-token deltas between runs.
- Added `--benchmark-compare` and `--benchmark-output` CLI options for saved report comparisons and explicit JSON artifact output.
- Comparisons reject mismatched suite fingerprints, case IDs, repetition counts, or unsupported schema versions.
- Comparison output explicitly states that results are descriptive and do not establish causality, statistical significance, or semantic correctness.
- Added metadata, regression-delta, and incompatible-report tests.

## 0.33.0 — Optional Docker-isolated test execution

- Added an explicit Docker backend for fixed `pytest`/`ruff` commands, with network disabled, read-only container root, dropped capabilities, no-new-privileges, PID/memory/CPU limits, and only the selected workspace mounted writable.
- Requires an operator-selected image already present locally; uses `--pull=never`, performs a local image inspection, and fails closed if Docker/image is unavailable (never falls back to host execution).
- Exposed `--test-isolation` and `--sandbox-image` for direct test execution, proposal verification, and opt-in agent verification.
- Kept trusted host execution as the default for compatibility and documented its non-sandbox status.
- Added mocked tests for Docker invocation policy, image validation, and fail-closed behavior. Live Docker execution was unavailable in the development environment.

## 0.32.0 — Baseline-aware regression verification

- Run the approved fixed test suite against the clean baseline before applying a proposal in the disposable worktree, then rerun it after applying the proposal.
- Report `clean`, `introduced_failure`, `improved`, `preexisting_failure_persists`, or `not_compared` so existing failures are not confused with regressions introduced by a patch.
- Allow operators to disable baseline comparison when they explicitly choose a single verification run.
- The test runner remains bounded but is not an OS sandbox; only use it with trusted repositories. Baseline comparison doubles test execution cost and does not establish semantic correctness.

## 0.31.0 — Iterative verification feedback

- Added an explicit model instruction to revise failed patches instead of claiming success or retrying an immutable proposal.
- The orchestrator now rejects repeated verification of a proposal that already failed during the same task run, requiring a newly generated proposal ID.
- Verification trace metadata includes the test pass flag and process return code when returned by the verification tool.
- Added regression coverage for a complete simulated propose → failed verification → revised proposal → passed verification cycle.
- This remains model-directed iteration; tests run in a disposable Git worktree, not an OS sandbox, and simulated tests do not establish real-model performance.

## 0.30.0 — Acceptance-driven benchmark criteria

- Added validated benchmark criteria for expected task status, required/forbidden tools, prohibited output phrases, and minimum/maximum orchestration steps.
- Benchmark reports now expose each criterion's result, actual tool usage, step count, missing requirements, and forbidden matches.
- Preserved existing `must_contain` smoke cases; schema version advanced to 2.
- These deterministic checks improve regression visibility but do not measure semantic correctness or general engineering ability.

## 0.29.0 — Opt-in verification loop alignment

- Fixed model-facing tool instructions so `verify_proposal` is advertised only when `--allow-agent-verification` is enabled.
- Kept runtime allowlisting aligned with the operator's setting; disabled runs reject model requests for verification.
- Corrected the package `__version__` to match the release metadata.
- Added end-to-end orchestrator tests for verification feedback and opt-in tool exposure.

## 0.28.0 — 2026-10-09

- Added a direct stdio JSON-RPC MCP client for REA, including initialization, live tool discovery, request matching, bounded messages, deadlines, and process cleanup.
- Added `rea_mcp_investigate`, restricted to the `open_binary` → `binary_overview` workflow; no shell, no automatic package download, and workspace-local regular-file targets only.
- Added protocol-fixture tests and orchestrator integration coverage. Live native-provider validation remains environment-dependent and is not claimed.

## 0.26.0 — Opt-in agent-driven proposal verification

- Added the `verify_proposal` tool to the model loop only when the operator starts AURIX with `--allow-agent-verification`.
- Verification uses the fixed `pytest` or `ruff` runner against a patch in a disposable detached Git worktree; the primary checkout remains unchanged.
- The model receives structured pass/fail status, bounded output, timeout information, and the non-sandbox security caveat to support a test-feedback/revision loop.
- Added strict proposal ID, suite, and timeout validation. Arbitrary commands and model-supplied command arguments are not supported.
- Disabled by default. Tests may still access operating-system resources and the network; enable only for trusted repositories.

# Changelog

## 0.34.0 — Repeated benchmark runs and stability metrics

- Added `--benchmark-repetitions` (1–10) to rerun each case and measure consistency instead of relying on a single sample.
- Benchmark schema v3 reports per-case pass rate/stable pass, total executions, mean/median latency, and estimated output-token totals.
- Validates repetition limits and reports the additional compute/API-cost caveat.
- Added regression tests for unstable results, aggregate metrics, and invalid repetition counts.
- These checks still measure authored acceptance criteria, not semantic correctness or real-world engineering success.


## [0.25.0] - 2026-10-08

- Add `inspect_project`, a bounded, read-only project inventory for ecosystems, manifests, source-extension counts, test files, CI configuration, and package-script names.
- Keep project scripts as names only: no tests, build scripts, or application code are executed by inventory.
- Avoid traversing symlinked directories, skip ignored/vendor and sensitive paths, and cap filesystem traversal and returned inventories.
- Integrate project inventory into the model tool protocol and add orchestration, ecosystem detection, and symlink-boundary tests.


## [0.24.0] - 2026-10-08

- Add bounded, read-only `git_status` and `git_diff` tools to the model tool loop so AURIX can inspect tracked, staged, and untracked changes before proposing edits.
- Disable external diff drivers and color output, avoid shell invocation, enforce repository-root scope, and cap returned diff/status output.
- Expand the orchestrator's explicit tool allowlist and system protocol to document Git inspection tools.
- Add bounded, numbered line-range reads so the model can inspect relevant sections of large source files without repeatedly loading file prefixes.


## 0.23.0 — REA static-analysis adapter
- Connected the AURIX tool loop to the upstream `morluto/rea` CLI for static JavaScript/Electron application analysis.
- Added workspace-contained directory/ASAR validation, shell-free subprocess invocation, a reduced child environment, bounded output and timeout handling.
- REA remains an explicit external dependency; AURIX does not auto-download it or claim full MCP/native-provider integration.
- Added tests for invocation policy, path restrictions, timeout behavior, and orchestration handoff.


## 0.22.0 — Memory evidence traceability
- Expose compact memory provenance (record ID, scope, evidence kind, retrieval mode, score, matched terms) on task results without copying memory content into traces.
- Include the provenance in JSON CLI output and explicitly requested run reports so operators can audit which records were retrieved.
- Preserve report integrity hashing; memory evidence metadata is covered by the existing report digest.
- Keep memory injection opt-in and scoped; no automatic long-term memory writes were added.


## 0.21.0 — Opt-in contextual memory
- Added explicit `--use-memory-context` to retrieve relevant records for task prompts without enabling persistent memory access by default.
- Scoped retrieval to the configured memory scope and bounded injected evidence to 10 records / 8,000 serialized characters.
- Memory is labeled untrusted evidence, never instructions; kind/confidence labels are preserved as descriptive metadata.
- Added orchestration tests for opt-in behavior and scope isolation.


## 0.20.0 — Evidence-aware memory records
- Added validated memory evidence kinds: fact, hypothesis, decision, test_result, and observation.
- Added optional confidence metadata constrained to [0, 1], with CLI flags for explicit memory creation.
- Applied the same reserved-field validation to SQLite and PostgreSQL/Neon stores.
- Kept legacy metadata and existing records compatible; labels are descriptive and do not constitute verification.

## 0.18.0
- Added deterministic lexical relevance ranking for memory retrieval.
- Added explicit candidate, result-count, and per-record content limits.
- Search results expose relevance scores and matched terms, and clarify that retrieval is not semantic/embedding search.
- Added tests for ranking, scope filtering, truncation, and empty-token queries.

# Changelog

## 0.4.0 — Explicit patch application and reversal

- Added separate CLI commands to apply or reverse a stored proposal only after an explicit confirmation flag.
- Require the workspace to be the Git repository root and the tracked worktree to be clean before applying a patch.
- Restrict patches to in-place modifications of existing tracked regular files.
- Reject binary/metadata diffs, renames, copies, additions/deletions, unsafe paths, symlinks, and sensitive filenames.
- Run `git apply --check` before application and reverse-check before attempting a reversal.
- Added focused tests and updated safety documentation.

This is not a sandbox and does not establish that a patch is semantically correct. Review every diff and inspect the worktree after applying or reverting.


## 0.5.0 — Explicitly approved test runner

- Added a fixed-command test runner for `pytest` and `ruff`; no model-controlled command arguments.
- Required explicit confirmation, bounded runtime/output, and passed a reduced environment to subprocesses.
- Added tests for confirmation, command allowlisting, timeout bounds, secret-like environment removal, and failed test outcomes.
- Clarified that process-level limits do not provide OS sandboxing; trusted repositories only.


## 0.6.0
- Added explicit proposal verification in a disposable detached Git worktree.
- Added CLI options `--verify-proposal`, `--confirm-verify`, and `--verify-suite`.
- Added integration tests proving pass/fail reporting and preservation of the primary checkout.
- Clarified that a disposable worktree is not an operating-system sandbox.

## 0.7.0 — Installation diagnostics and explicit provider probe

- Added `aurix --doctor` for read-only readiness checks across Python, workspace, Git, core dependencies, optional test/lint tools, provider configuration, and optional Neon configuration.
- Added opt-in `--probe-provider` for a real model request; this can consume local compute or hosted API credits.
- Provider probe output suppresses raw responses and exception details to avoid leaking secrets.
- Added tests for read-only behavior and safe provider-probe reporting.


## 0.8.0 — 2026-10-08

- Added deterministic heuristic review for patch proposals, focused on newly added lines.
- Added findings for dynamic execution, shell/subprocess use, unsafe deserialization, credential-like literals, TLS verification disabled, broad file permissions, and likely SQL interpolation.
- Added CLI command `--review-proposal ID` with JSON output.
- Review results never authorize application; human review remains required.
- Added tests for high-risk findings, low-risk results, removed-line exclusion, and missing proposals.


## 0.9.0 — Strict model protocol

- Reject malformed JSON and non-object responses instead of treating arbitrary model text as a successful final answer.
- Validate response status, message type, tool allowlist, and tool argument shape before dispatch.
- Enforce a 100,000-character provider-response ceiling and record bounded protocol-error labels in traces.
- Added regression tests confirming malformed or unauthorized responses cannot execute tools.


## 0.11.0 — Proposal-linked audit reports

- Capture bounded tool status and valid proposal identifiers in the execution trace without storing tool-result bodies.
- Upgrade run reports to schema version 2 and link proposals as metadata-only artifacts.
- Ignore malformed proposal identifiers when producing report artifact indexes.
- Add regression coverage for proposal linkage and exclusion of patch contents from reports.


## 0.12.0 — Combined proposal audit

- Added `--audit-proposal` to combine heuristic diff review and verification status in one structured result.
- Kept test execution opt-in behind `--confirm-audit-verify`; no tests run from an audit without explicit confirmation.
- Reports `audit_passed` only when heuristic risk is low and the selected verification suite passes. High-risk findings remain `audit_needs_attention`.
- Explicitly records that audit never applies a patch and that disposable worktree verification is not an OS sandbox.
- Added regression tests for confirmation gating and risk-aware result classification.


## 0.13.0 — Proposal-linked audit evidence

- Added SHA-256 identity and UTC audit timestamp to proposal audit results.
- Added `--attach-audit-to-report` to link compact audit outcomes to an existing schema-v2 run report.
- Audit attachments retain proposal digest, risk level, finding count, verification status/suite, and whether a patch was applied; raw test output and full findings are excluded.
- Added checks for report schema, size, workspace-relative paths, and symlinks, plus atomic replacement and regression tests.
- Attachment requires an existing run report; it does not fabricate a run record for an audit-only command.


## 0.14.0 — Run report integrity

- Add canonical SHA-256 integrity digests to newly written run reports and refresh the digest when compact audit evidence is attached.
- Add read-only `--verify-run-report PATH` verification that distinguishes valid, tampered, and legacy reports without an integrity digest.
- Enforce schema-v2, workspace-relative paths, symlink refusal, and a 2 MB report size ceiling during verification.
- Add regression tests for tampering detection, digest refresh after audit attachment, and legacy reports without integrity metadata.
- Clarify that a local digest detects accidental or post-write changes but is not a digital signature and cannot authenticate a report against an attacker able to rewrite both content and digest.


## 0.15.0 — Guarded audit history

- Verify the existing report digest before attaching audit evidence; tampered and legacy reports are refused instead of silently rehashed.
- Preserve the prior digest and timestamp in a compact integrity history when a new audit is attached.
- Make duplicate audit attachment idempotent and return previous/current report digests.
- Validate audit result identity, SHA-256 shape, and nested metadata before mutation.
- Add regression tests for tampering refusal, digest history, and malformed metadata.

Integrity history remains inside the local report and is not cryptographically authenticated against an attacker who can rewrite the entire file.


## 0.16.0 — Strict audit evidence binding

- Require audit attachment's proposal SHA-256 to match the current proposal file bytes.
- Reuse proposal path validation, including rejection of symlinked metadata directories and proposal files.
- Validate audit timestamp, status, risk level, finding count, verification state/suite, and exact boolean application metadata before writing.
- Add regressions for mismatched patch digests, invalid boolean strings, and negative finding counts.
- Clarify that report hashes provide tamper evidence, not identity/authenticity guarantees.


## 0.17.0 — Unified persistent memory interface

- Added a backend-independent `MemoryStore` protocol and a factory for SQLite or optional PostgreSQL/Neon.
- Added explicit CLI memory operations (`--memory-add`, `--memory-search`) with a required-by-default logical scope and JSON output.
- Kept memory persistence opt-in; tasks, prompts, completions, and traces are not automatically copied into long-term memory.
- Added tests for default workspace database placement, backend validation, and scope-isolated CLI retrieval.
- Documented that scopes are filters, not multi-tenant authorization controls, and that Neon has not been validated without live credentials.


## 0.19.0 — Hybrid retrieval interface and evaluation

- Added an optional injected embedding adapter to combine semantic cosine similarity with lexical overlap, without binding the core to a specific model or provider.
- Hybrid retrieval can return relevant candidates even when they share no lexical tokens with the query; lexical-only behavior remains the default.
- Reject malformed, non-finite, zero-length, and dimension-mismatched embeddings instead of silently degrading to lexical mode.
- Added retrieval evaluation metrics: precision@k, recall@k, and reciprocal rank against manually labeled IDs.
- Documented that CLI retrieval remains lexical-only until an embedding adapter is explicitly configured and evaluated.


## 0.27.0 — 2026-10-09

- Added `rea_investigate` for allowlisted REA CLI analysis, search, function, decompile, xrefs, trace, provider discovery, and capabilities discovery.
- Enforced workspace-relative targets, query/provider validation, subprocess timeouts, bounded output, reduced child environment, and `shell=False`.
- Connected the tool to the orchestrator and documented native-provider prerequisites and the remaining lack of direct MCP transport.
