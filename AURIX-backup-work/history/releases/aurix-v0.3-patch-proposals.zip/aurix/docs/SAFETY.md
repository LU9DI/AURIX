# Safety model

AURIX is intended to eventually read and modify code and invoke developer tools.

## Initial safeguards
- Resolve workspace paths and reject traversal.
- Run commands without a shell and only from a narrow allowlist.
- Bound command duration, output size, and reasoning steps.
- Treat model output as untrusted data, never as policy.

## Required before production
- Run untrusted repositories in disposable containers/VMs without ambient credentials.
- Require approval for writes, network access, installs, deployments, and destructive actions.
- Redact secrets from traces and memory; implement retention and deletion controls.
- Test prompt injection, path traversal, symlink escapes, command injection, resource exhaustion, and exfiltration.
- Never expose host secrets or production credentials to models or untrusted repositories.

## Context privacy

The context builder skips common `.env*` and SSH private-key filenames and bounds both the number of files and total characters. This is defense-in-depth, not a guarantee that arbitrary credentials cannot appear in source files. Review repository contents before sending context to a hosted model. Telemetry deliberately stores metadata only; never add prompt/completion logging without explicit opt-in and a clear retention policy.

## Execution boundary

The current CLI does not automatically edit files or execute model-proposed commands. The command helper's allowlist is not a sandbox; do not expose it to untrusted model output as an autonomous executor. Before enabling edits or command execution, implement isolated execution, patch review, path validation, resource limits, and explicit user approval.


## Patch proposals

The `propose_patch` tool stores a bounded unified diff in `.aurix/proposals/` for human review. It does not apply changes. Proposals reject absolute paths, parent traversal, and edits targeting `.git` or `.aurix`. This validation is defense in depth, not proof that a diff is semantically safe. Review the complete diff before applying it with your normal development tools.
