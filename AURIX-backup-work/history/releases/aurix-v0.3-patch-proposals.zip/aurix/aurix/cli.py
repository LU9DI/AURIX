import argparse
import json
from pathlib import Path

from aurix.config import get_max_steps
from aurix.evaluation.benchmark import load_cases, run_benchmark
from aurix.orchestrator import Orchestrator
from aurix.providers.factory import create_provider
from aurix.tools.workspace import build_workspace_context


def main() -> None:
    parser = argparse.ArgumentParser(prog="aurix", description="AURIX local-first engineering agent")
    parser.add_argument("task", nargs="?", help="Task to reason about")
    parser.add_argument("--workspace", default=".")
    parser.add_argument("--benchmark", help="Run a JSON benchmark file instead of a single task")
    parser.add_argument("--json", action="store_true", help="Print machine-readable output")
    args = parser.parse_args()
    provider = create_provider()
    orchestrator = Orchestrator(provider, max_steps=get_max_steps(), workspace=args.workspace)

    if args.benchmark:
        report = run_benchmark(orchestrator, load_cases(args.benchmark))
        print(json.dumps(report, ensure_ascii=False, indent=2) if args.json else
              f"AURIX benchmark: {report['passed']}/{report['cases']} passed ({report['pass_rate']:.0%})")
        return

    workspace = Path(args.workspace).expanduser().resolve()
    task = args.task or input("AURIX task> ").strip()
    context = build_workspace_context(workspace)
    result = orchestrator.run(task, context)
    if args.json:
        print(json.dumps({"status": result.status, "steps": result.steps, "message": result.message,
                          "trace": result.trace}, ensure_ascii=False, indent=2))
    else:
        print(f"\nAURIX [{result.status}] after {result.steps} step(s)\n{result.message}")
        print("\nNo autonomous file edits or shell execution are enabled.")


if __name__ == "__main__":
    main()
