# Changelog

## 0.45.0 — Automatic local RAG in agent tasks

- Integrated local SQLite knowledge retrieval into the orchestrator before the first model call.
- Retrieved snippets include relative source paths, chunk numbers, and ranking scores as untrusted evidence.
- Added bounded retrieval controls and an environment switch; local index failures do not stop tasks.
- Retrieval uses an existing `.aurix/knowledge.db`; it does not scan or index files implicitly.
- Added telemetry for retrieved evidence count and result-level knowledge provenance.

## 0.44.0 — Local retrieval and inference efficiency

- Added a dependency-free SQLite knowledge index for text and source files.
- Added BM25-like lexical retrieval with source-path and chunk references.
- Added CLI commands to index, search, and inspect the local index without invoking a model.
- Excluded common internal/build directories and symlinks from indexing.
- This is lexical RAG infrastructure; embeddings, SSM/BitNet model execution, and model-weight training are not implemented by this change.

## 0.43.0 — Continual learning foundation

- Added evidence-gated learning candidates and consent-separated training export.
