import pytest

from aurix.agents import AgentManager


class FakeProvider:
    def __init__(self, output="ok"):
        self.output = output
        self.calls = []

    def generate(self, prompt, *, system=""):
        self.calls.append((prompt, system))
        return self.output


def test_agent_registry_persists_and_lists(tmp_path):
    path = tmp_path / ".aurix" / "agents.db"
    manager = AgentManager(path)
    created = manager.create("sec_review", "security", "Threat-model APIs")
    assert created["name"] == "sec_review"
    assert AgentManager(path).get("sec_review")["role"] == "security"
    assert AgentManager(path).list()[0]["description"] == "Threat-model APIs"


def test_agent_registry_rejects_invalid_and_duplicate_profiles(tmp_path):
    manager = AgentManager(tmp_path / "agents.db")
    with pytest.raises(ValueError):
        manager.create("bad name", "reviewer")
    with pytest.raises(ValueError):
        manager.create("not_allowed", "superuser")
    manager.create("review", "reviewer")
    with pytest.raises(ValueError, match="already exists"):
        manager.create("review", "reviewer")


def test_agent_run_uses_role_and_bounded_task(tmp_path):
    manager = AgentManager(tmp_path / "agents.db")
    manager.create("test_agent", "tester", "Regression testing")
    provider = FakeProvider("test plan")
    result = manager.run("test_agent", "Write a test plan", lambda: provider)
    assert result["status"] == "completed"
    assert result["output"] == "test plan"
    assert "Regression testing" in provider.calls[0][0]
    assert "failure cases" in provider.calls[0][1]
    with pytest.raises(ValueError):
        manager.run("test_agent", "", lambda: provider)


def test_team_creates_specialists_and_synthesizes(tmp_path):
    manager = AgentManager(tmp_path / "agents.db")
    providers = []

    def factory():
        provider = FakeProvider(f"answer-{len(providers)}")
        providers.append(provider)
        return provider

    result = manager.create_team("Design a resilient cache", factory)
    assert result["status"] == "completed"
    assert result["successful_agents"] == 3
    assert {agent["role"] for agent in result["agents_created"]} == {"architect", "researcher", "reviewer"}
    assert len(manager.list()) == 3
    assert result["synthesis"] == "answer-3"


def test_team_reports_partial_failures(tmp_path):
    manager = AgentManager(tmp_path / "agents.db")
    calls = 0

    class FailingProvider:
        def generate(self, prompt, *, system=""):
            nonlocal calls
            calls += 1
            if calls == 1:
                raise RuntimeError("simulated")
            return "ok"

    result = manager.create_team("Review an API", lambda: FailingProvider())
    assert result["status"] == "completed"
    assert result["successful_agents"] == 2
    assert any(row["status"] == "error" for row in result["specialist_results"])
