"""Deterministic heuristic review for proposed unified diffs.

This is a triage aid, not a proof of correctness or security.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from aurix.tools.patches import _proposal_path, _validate_patch
from aurix.tools.provenance import append_audit_event, verify_proposal_integrity

_RULES: tuple[tuple[str, str, str, re.Pattern[str]], ...] = (
    ("dynamic-code", "high", "Added code may evaluate or execute dynamically",
     re.compile(r"\b(eval|exec)\s*\(")),
    ("shell-execution", "high", "Added code may invoke a shell or subprocess",
     re.compile(r"\b(subprocess\.(run|Popen|call|check_call|check_output)|os\.system|shell\s*=\s*True)\b")),
    ("deserialization", "high", "Added code may use unsafe deserialization",
     re.compile(r"\bpickle\.(loads|load)\s*\(|\byaml\.load\s*\(")),
    ("tls-validation", "medium", "Added code may disable TLS certificate verification",
     re.compile(r"\bverify\s*=\s*False\b|CERT_NONE")),
    ("secret-literal", "high", "Added code may contain a hard-coded credential",
     re.compile(r"(?i)(api[_-]?key|secret|password|token)\s*=\s*['\"][^'\"]{8,}['\"]")),
    ("broad-permissions", "medium", "Added code may set broad filesystem permissions",
     re.compile(r"chmod\s*\(.*0?777|\b0o777\b")),
    ("sql-concatenation", "medium", "Added code may build SQL using string concatenation/interpolation",
     re.compile(r"(?i)(select|insert|update|delete)\s+.{0,80}(\+\s*\w+|%s|\{\w+\})")),
)


def review_proposal(workspace: Path | str, proposal_id: str) -> dict[str, Any]:
    """Return a bounded static review of newly added diff lines."""
    root = Path(workspace).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Workspace must be a directory")
    proposal = _proposal_path(root, proposal_id)
    integrity = verify_proposal_integrity(proposal, proposal_id)
    patch = proposal.read_text(encoding="utf-8")
    targets = _validate_patch(root, patch)
    findings: list[dict[str, Any]] = []
    current_file = ""
    added_count = 0
    for line_number, line in enumerate(patch.splitlines(), start=1):
        if line.startswith("+++ "):
            current_file = line[4:].split("\t", 1)[0].removeprefix("b/")
            continue
        if not line.startswith("+") or line.startswith("+++"):
            continue
        added_count += 1
        added = line[1:]
        for rule_id, severity, summary, pattern in _RULES:
            if pattern.search(added):
                findings.append({
                    "rule": rule_id,
                    "severity": severity,
                    "file": current_file,
                    "patch_line": line_number,
                    "summary": summary,
                    "sample": added.strip()[:240],
                })
    risk = "high" if any(x["severity"] == "high" for x in findings) else (
        "medium" if findings else "low")
    append_audit_event(root, "proposal_reviewed", proposal_id, {"risk_level": risk, "finding_count": len(findings), "sha256": integrity["sha256"]})
    return {
        "proposal_id": proposal_id,
        "integrity": integrity,
        "status": "review_required",
        "risk_level": risk,
        "targets": targets,
        "added_lines_scanned": added_count,
        "finding_count": len(findings),
        "findings": findings[:100],
        "limitations": [
            "Heuristic scan covers added diff lines only and can miss vulnerabilities.",
            "A low risk level does not mean the patch is safe or correct.",
            "Human review and appropriate tests remain required.",
        ],
        "apply_permitted_by_review": False,
    }
