"""Verify a reviewed patch in a disposable Git worktree.

This keeps the user's primary checkout unchanged, but test code is still not
sandboxed from the operating system. Only use this for trusted repositories.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Literal

from aurix.tools.execution import IsolationMode, run_test_suite
from aurix.tools.patches import _git, _proposal_path, _validate_patch
from aurix.tools.provenance import append_audit_event

VerifySuite = Literal["pytest", "ruff"]


def verify_proposal(
    workspace: Path | str,
    proposal_id: str,
    *,
    confirm: bool = False,
    suite: VerifySuite = "pytest",
    timeout_seconds: int = 120,
    compare_baseline: bool = True,
    isolation: IsolationMode = "trusted",
    sandbox_image: str | None = None,
) -> dict[str, object]:
    """Apply a proposal to a temporary detached worktree and run a fixed suite.

    The main checkout is not modified. This is isolation from the primary
    checkout, not an OS-level sandbox: tests may still access available OS
    resources and the network.
    """
    if not confirm:
        raise PermissionError("Explicit confirmation is required to verify a patch")
    if suite not in {"pytest", "ruff"}:
        raise ValueError("Unsupported verification suite; choose 'pytest' or 'ruff'")

    root = Path(workspace).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Workspace must be a directory")
    proposal = _proposal_path(root, proposal_id)
    patch = proposal.read_text(encoding="utf-8")
    targets = _validate_patch(root, patch)

    top = _git(root, ["rev-parse", "--show-toplevel"])
    if top.returncode != 0 or Path(top.stdout.strip()).resolve() != root:
        raise ValueError("Workspace must be the Git repository root")
    status = _git(root, ["status", "--porcelain", "--untracked-files=no"])
    if status.returncode != 0:
        raise RuntimeError(status.stderr.strip() or "Could not inspect Git status")
    if status.stdout.strip():
        raise PermissionError("Git worktree has tracked changes; commit or stash them before verification")

    if not isinstance(compare_baseline, bool):
        raise ValueError("compare_baseline must be a boolean")

    with tempfile.TemporaryDirectory(prefix="aurix-verify-") as temp_parent:
        worktree = Path(temp_parent) / "checkout"
        added = _git(root, ["worktree", "add", "--detach", str(worktree), "HEAD"])
        if added.returncode != 0:
            raise RuntimeError(f"Could not create disposable Git worktree: {added.stderr.strip()[:500]}")
        try:
            baseline_result = None
            if compare_baseline:
                baseline_result = run_test_suite(
                    worktree, suite, confirm=True, timeout_seconds=timeout_seconds,
                    isolation=isolation, sandbox_image=sandbox_image,
                )
            checked = _git(worktree, ["apply", "--check", "--whitespace=error", "-"], patch=patch)
            if checked.returncode != 0:
                raise ValueError(f"Patch preflight failed in disposable worktree: {checked.stderr.strip()[:500]}")
            applied = _git(worktree, ["apply", "--whitespace=error", "-"], patch=patch)
            if applied.returncode != 0:
                raise RuntimeError(f"Could not apply patch in disposable worktree: {applied.stderr.strip()[:500]}")
            test_result = run_test_suite(
                worktree, suite, confirm=True, timeout_seconds=timeout_seconds,
                isolation=isolation, sandbox_image=sandbox_image,
            )
            if baseline_result is None:
                regression_status = "not_compared"
            elif baseline_result["passed"] and test_result["passed"]:
                regression_status = "clean"
            elif baseline_result["passed"] and not test_result["passed"]:
                regression_status = "introduced_failure"
            elif not baseline_result["passed"] and test_result["passed"]:
                regression_status = "improved"
            else:
                regression_status = "preexisting_failure_persists"
            result = {
                "proposal_id": proposal_id,
                "status": "verified_pass" if test_result["passed"] else "verified_fail",
                "suite": suite,
                "targets": targets,
                "primary_workspace_modified": False,
                "baseline_result": baseline_result,
                "test_result": test_result,
                "regression_status": regression_status,
                "isolation": isolation,
                "security_note": (
                    "Tests ran in Docker isolation; review the image and daemon trust boundary."
                    if isolation == "docker" else
                    "Tests ran in a disposable Git worktree, not an OS sandbox. "
                    "Only verify patches from repositories you trust."
                ),
            }
            append_audit_event(root, "proposal_verified", proposal_id, {
                "suite": suite, "status": result["status"],
                "regression_status": regression_status, "isolation": isolation,
            })
            return result
        finally:
            removed = _git(root, ["worktree", "remove", "--force", str(worktree)])
            if removed.returncode != 0:
                _git(root, ["worktree", "prune"])
                shutil.rmtree(worktree, ignore_errors=True)
