"""Explicit, local run reports with path and symlink protections."""
from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def write_run_report(workspace: str | Path, destination: str | Path, *, task: str, result: Any, provider: str) -> dict[str, Any]:
    """Write a report only when explicitly requested; destination must be inside workspace.

    Reports include the user's task and trace metadata, but never prompts, completions, or tool-result bodies.
    Existing symlinks are refused to prevent writes escaping the workspace.
    """
    root = Path(workspace).expanduser().resolve()
    raw = Path(destination).expanduser()
    if raw.is_absolute():
        raise ValueError("Report destination must be a relative path inside the workspace")
    if not task.strip():
        raise ValueError("Task must not be empty")
    if len(task) > 20_000:
        raise ValueError("Task exceeds the 20000-character report limit")
    if any(part in {"..", ".git"} for part in raw.parts) or not raw.parts:
        raise PermissionError("Report destination contains a prohibited path component")
    if any(part == ".aurix" for part in raw.parts):
        raise PermissionError("Report destination may not write into AURIX internal metadata")
    target = root / raw
    cursor = root
    for part in raw.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise PermissionError("Symlink components are not allowed in report destinations")
    resolved_parent = target.parent.resolve()
    if not resolved_parent.is_relative_to(root):
        raise PermissionError("Report destination must remain inside the workspace")
    if target.exists() and not target.is_file():
        raise ValueError("Report destination must be a regular file")
    report = {
        "schema_version": 1,
        "run_id": uuid.uuid4().hex,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "task": task.strip(),
        "workspace": ".",
        "provider": provider,
        "result": {"status": result.status, "message_chars": len(result.message), "steps": result.steps},
        "trace": result.trace,
        "safety": {
            "autonomous_file_edits": False,
            "shell_execution_by_model": False,
            "contains_raw_prompts_or_completions": False,
            "note": "Trace contains metadata only; inspect proposals and test output separately.",
        },
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    # Recheck after creating directories to guard against a symlink introduced during setup.
    cursor = root
    for part in raw.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise PermissionError("Symlink components are not allowed in report destinations")
    fd, temp_name = tempfile.mkstemp(prefix=".aurix-report-", suffix=".tmp", dir=target.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(report, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(temp_name, target)
    except BaseException:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise
    return {"path": target.relative_to(root).as_posix(), "run_id": report["run_id"], "status": "written", "schema_version": 1}
