import json

import pytest

from aurix.orchestrator import TaskResult
from aurix.reports import write_run_report


def test_write_run_report_contains_metadata_not_raw_tool_results(tmp_path):
    result = TaskResult("completed", "Inspected files.", 1, [{"step": 1, "tool": "list_files", "tool_result_chars": 42}])
    saved = write_run_report(tmp_path, "reports/run.json", task="Inspect source", result=result, provider="FakeProvider")
    data = json.loads((tmp_path / "reports/run.json").read_text(encoding="utf-8"))
    assert saved["status"] == "written"
    assert data["schema_version"] == 1
    assert data["task"] == "Inspect source"
    assert data["result"]["status"] == "completed"
    assert "message" not in data["result"]
    assert data["safety"]["contains_raw_prompts_or_completions"] is False
    assert "actual tool-result body" not in json.dumps(data)


def test_report_rejects_absolute_and_traversal_paths(tmp_path):
    result = TaskResult("completed", "ok", 1, [])
    with pytest.raises(ValueError):
        write_run_report(tmp_path, tmp_path / "outside.json", task="x", result=result, provider="P")
    with pytest.raises(PermissionError):
        write_run_report(tmp_path, "../outside.json", task="x", result=result, provider="P")


def test_report_rejects_symlink_destination(tmp_path):
    result = TaskResult("completed", "ok", 1, [])
    outside = tmp_path.parent / (tmp_path.name + "-outside.json")
    outside.write_text("keep", encoding="utf-8")
    (tmp_path / "report.json").symlink_to(outside)
    with pytest.raises(PermissionError):
        write_run_report(tmp_path, "report.json", task="x", result=result, provider="P")
    assert outside.read_text(encoding="utf-8") == "keep"


def test_report_rejects_internal_metadata_path(tmp_path):
    result = TaskResult("completed", "ok", 1, [])
    with pytest.raises(PermissionError):
        write_run_report(tmp_path, ".aurix/runs.jsonl", task="x", result=result, provider="P")
